#ifndef SWAP_H
#define SWAP_H

unsigned long SwapBBBB(unsigned long i);
unsigned int SwapBB(unsigned int i);
unsigned long SwapWW(unsigned long i);

#endif

