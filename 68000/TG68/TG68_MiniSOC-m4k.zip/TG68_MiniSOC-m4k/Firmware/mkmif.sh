#!/bin/sh
srec_cat.exe TG68TestFirmware.S68 -o TG68TestFirmware.mif -mif 16
