#ifndef _SYS_FILE_H
#define _SYS_FILE_H

/* LOCK_ definitions */
#include <fcntl.h>

__extern int flock(int, int);

#endif /* _SYS_FILE_H */
