#include "ctypefunc.h"
CTYPEFUNC(tolower)
