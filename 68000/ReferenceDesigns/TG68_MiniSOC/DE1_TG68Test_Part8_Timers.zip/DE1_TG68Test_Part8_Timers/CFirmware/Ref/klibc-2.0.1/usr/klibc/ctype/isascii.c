#include "ctypefunc.h"
CTYPEFUNC(isascii)
