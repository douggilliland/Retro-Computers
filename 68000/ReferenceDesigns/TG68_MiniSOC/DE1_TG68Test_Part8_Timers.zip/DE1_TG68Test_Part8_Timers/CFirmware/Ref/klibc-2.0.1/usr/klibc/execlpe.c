/*
 * execlpe.c
 */

#define NAME execlpe
#define EXEC_P 1
#define EXEC_E 1
#include "exec_l.c"
