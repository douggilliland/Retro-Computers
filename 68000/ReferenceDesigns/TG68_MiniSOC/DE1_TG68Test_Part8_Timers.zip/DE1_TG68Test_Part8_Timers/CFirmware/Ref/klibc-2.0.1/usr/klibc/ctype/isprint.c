#include "ctypefunc.h"
CTYPEFUNC(isprint)
