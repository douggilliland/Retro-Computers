  "%s",WARNING,
  "instruction not supported on selected architecture",ERROR,
  "constant integer expression required",ERROR,
  "trailing garbage in operand",WARNING,
  "illegal operand type",ERROR,
  "missing closing parenthesis in load/store addressing mode",ERROR, /* 05 */
  "relocation does not allow hi/lo modifier",ERROR,
  "multiple relocation attributes",ERROR,
  "multiple hi/lo modifiers",ERROR,
  "data size %d not supported",ERROR,
  "data has illegal type",ERROR,                                     /* 10 */
  "relocation attribute not supported by operand",ERROR,
  "operand out of range: %ld (allowed: %ld to %ld)",ERROR,
  "not a valid register (0-31)",ERROR,
  "missing base register in load/store addressing mode",ERROR,
  "missing mandatory operand",ERROR,                                 /* 15 */
  "ignoring fake operand",WARNING,
