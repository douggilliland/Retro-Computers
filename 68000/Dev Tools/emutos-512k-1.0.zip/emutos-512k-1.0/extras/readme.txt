Resource files (.def/.rsc) present in this folder:

Cursors
-------
emucurs     the same as the builtin EmuTOS cursor set, provided as an example
emucurs1    an alternative set, courtesy of Christian Quante
emucurs2    an alternative set, courtesy of Pavel Salac & Christian Quante

Icons
-----
emuicon0    the original EmuTOS icon set, used in versions before 0.9.11
emuicon1    an alternative set, courtesy of Christian Quante
emuicon2    an alternative set, courtesy of Pavel Salac
