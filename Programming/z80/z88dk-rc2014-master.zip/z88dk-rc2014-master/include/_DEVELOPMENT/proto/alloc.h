include(__link__.m4)

#ifndef _ALLOC_H
#define _ALLOC_H

#include <alloc/balloc.h>
#include <alloc/malloc.h>
#include <alloc/obstack.h>

#endif
