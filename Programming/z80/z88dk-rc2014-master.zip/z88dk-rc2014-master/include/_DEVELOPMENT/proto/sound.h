include(__link__.m4)

#ifndef _SOUND_H
#define _SOUND_H

#include <sound/bit.h>

#endif
