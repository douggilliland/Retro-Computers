include(__link__.m4)

#ifndef _CTYPE_H
#define _CTYPE_H

__DPROTO(`b,c,d,e',`b,c,d,e',int,,isalnum,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isalpha,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isascii,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isbdigit,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isblank,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,iscntrl,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isdigit,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isgraph,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,islower,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isodigit,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isprint,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,ispunct,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isspace,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isupper,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,isxdigit,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,toascii,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,tolower,int)
__DPROTO(`b,c,d,e',`b,c,d,e',int,,toupper,int)

#endif
