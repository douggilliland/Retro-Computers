include(__link__.m4)

// "spectrum.h" is deprecated in favour of "zx.h"

#include <arch/zx.h>

