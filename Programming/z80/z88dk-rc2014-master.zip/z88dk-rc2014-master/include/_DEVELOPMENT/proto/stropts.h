include(__link__.m4)

#ifndef _STROPTS_H
#define _STROPTS_H

#include <sys/ioctl.h>

#endif
