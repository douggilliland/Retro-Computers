include(__link__.m4)

#include <string.h>
