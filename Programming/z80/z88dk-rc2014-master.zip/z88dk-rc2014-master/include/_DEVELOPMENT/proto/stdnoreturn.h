include(__link__.m4)

#ifndef _STDNORETURN_H
#define _STDNORETURN_H

#define noreturn   _Noreturn
#define _Noreturn

#endif
