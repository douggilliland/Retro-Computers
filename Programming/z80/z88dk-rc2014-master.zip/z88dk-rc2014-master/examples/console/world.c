/*
 *	Hello World
 */


#include <stdio.h>


main()
{
	printf("Hello world!\n");
}
