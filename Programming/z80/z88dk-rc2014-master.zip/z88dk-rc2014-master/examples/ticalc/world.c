/*     Hello World     */

#include <stdio.h>
/* Description string for Ti calcs */
#pragma string name Hello World
/* Icon for Ti calcs ('waving' hand) */
#pragma data icon 0x18,0x3C,0x3C,0xBC,0x7C,0x7C,0x3C,0x38;

main()
{
	printf("Hello World");
}
