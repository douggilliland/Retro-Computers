
#include <zxvgs.h>

main()
{
 loadany("ARGH!.SCR",0x4000,0x1B00);
}
