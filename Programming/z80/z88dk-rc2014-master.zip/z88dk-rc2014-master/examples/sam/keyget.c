#include <stdio.h>

main() {
  unsigned char a;
  while (1) {
    a = getk();
    /* fputs("a",stdout); */
    printf("%u\n", a);
  }

}
