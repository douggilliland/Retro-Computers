dragon.bas

An adaptation of Dragon Island by Walt Hutchinson, from the September/October 1977 newsletter of the Homebrew Computer Club.

You have to kill a dragon crawling in 10 interconnected caves, before the sun sets down (at 8 o'clock). In each turn you will throw your spean into a cave, if you miss you will have to fetch it back. Before you fetch, the dragon can crawl to an adjacent cave or lurk. As a clue, the dragon will snort if you throw your spear in a cave next to him.

[Converted by Daniel Quadros https://github.com/dquadros]
