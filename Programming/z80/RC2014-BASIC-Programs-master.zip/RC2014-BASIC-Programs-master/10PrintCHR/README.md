The prettiest single line program ever!

Looks beautiful when run via PiGFX on a Pi Zero Terminal Module, but any terminal that interprets CHR$(203) and CHR$(204) as opposite angled characters will work.

Lifted shamelessly from http://10print.org/
