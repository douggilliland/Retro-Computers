Simple Mastermind program

The RC2014 things of a 4 didgit non-repeating code.  You guess what that code is and it scores you to let you know if you have any of the numbers correct and if any of them are in the correct place.  Try working out what the secret code is in as few moves as possible.

This has been modified from a book on ZX81 programs
