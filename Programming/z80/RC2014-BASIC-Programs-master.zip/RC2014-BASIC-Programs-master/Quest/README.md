quest.bas

From the July 1979 issue of Byte magazine, a light adventure game. Back in the day I adapted this game to COBOL, as I didn't have access to a microcomputer... This version was pasted from a pdf I found in the internet tubes, so it had a few OCR errors. I hope I have fixed them all. I also made some small changes to make it run in RC2014 BASIC.

Note: Program expects input in uppercase.

[Converted by Daniel Quadros  https://github.com/dquadros]
