# Wanderer

For copyright, see ``credits``

In the directory ``original``, the original version + the update for version 2.2 as .lbr files can be found.

## This version

I provide version 2.2 as stated in the file ``-READ.ME``, so 61 levels are provided.

``WANDERER.DOC`` provides the manual.

I patched ``WANDERER.COM`` according to ``QTERM.PAT`` to output VT100 ANSI escape sequences that work on my RC2014 VGA VT100 terminal module.

