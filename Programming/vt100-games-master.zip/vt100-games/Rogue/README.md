# Rogue

ROGUE was written Nov 1984 thru Feb 1985 by David Goodenough.

I made the changes for VT100 escape sequences according to ``QTERM.PAT``.

The original files can be found in the file ``rogue17cpm.zip``.

``ROGUE.COM`` is the executable file and ``ROGUE.DOC`` contains the help for all commands.

