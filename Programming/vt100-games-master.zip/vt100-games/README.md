# VT100 games for CP/M

In this repository, I want to collect some games for CP/M which work when using
a VT100 compatible terminal (i.e. VT100 ANSI escape sequences).

These games use VT100 either per default or were adopted to using them.

Whenever possible, I will provide working binaries (i.e. .COM files) and also the
sources or original files that I found online.

## Backgammon

by David C. Oshel; C/asm sources available; I've adopted the code to VT100.

See this repository: https://git.imzadi.de/acn/backgammon-vt100

## Games in this repository

* [2048](2048/)
* [Ladder](Ladder/)
* [Rogue](Rogue/)
* [Wanderer](Wanderer/)

## More Games on the Interwebs

* [Gorilla.bas](https://github.com/sblendorio/gorilla-cpm): GORILLA.BAS port to CP/M in Turbo Modula-2. Supported terminals: VT52, VT100, ANSI, ADM-31, KayPro, C128, Memotech monochrome, CPC / Zenith Z19
* [Hangman](https://github.com/sblendorio/hangman-cpm): C implementation for CP/M of the classic "hangman" included in "bsdgames" popular package for UNIX

