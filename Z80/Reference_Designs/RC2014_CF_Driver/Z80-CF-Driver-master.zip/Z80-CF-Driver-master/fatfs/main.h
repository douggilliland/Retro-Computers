#pragma once

void main();
