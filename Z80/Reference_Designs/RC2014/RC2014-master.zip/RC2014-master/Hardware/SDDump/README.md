Early firmware for SD Memory Dump Module

Todo list
* Clean up code
* File management
* Error handling
