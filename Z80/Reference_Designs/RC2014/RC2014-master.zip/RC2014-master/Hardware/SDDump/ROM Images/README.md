A collection of ROM images that can be loaded on to SD card and run on and RC2014

If using the SDDump Plus firmware, rename the files to one of the following filenames to get it to load from the appropriate setting on the selector dial;

ROM_SW.BIN

ROM_W.BIN

ROM_NW.BIN

DUMP_N.BIN

DUMP_NE.BIN

DUMP_E.BIN

DUMP_SE.BIN

Quest - Needs either MS BASIC ROM, or a RAM only RC2014

Dragon - Needs either MS BASIC ROM, or a RAM only RC2014

Eliza - Needs 64k RAM only RC2014

Chess - Needs 64k RAM only RC2014

Star Trek - Needs 64k RAM only RC2014
