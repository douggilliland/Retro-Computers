# RC2014::Hardware::SDDumpPlus

This is an updated version of the SDDump utility by Spencer Owen. The
changes from here include:

* Multiple ROM load/save routines based on potentiometer position
* Green LED indicates position

Future:

* SD Shell via FTDI connector
