MS BASIC for RC2014 with SIO/2 Dual Serial Module.  Note that the console is on Port A

32k and 56k vairiants

INTSIO.HEX is the same for both versions, and should be burned from 0x0000 to 0x028F.  Then either BAS32K.HEX or BAS56k.HEX should be burned from 0x0290
