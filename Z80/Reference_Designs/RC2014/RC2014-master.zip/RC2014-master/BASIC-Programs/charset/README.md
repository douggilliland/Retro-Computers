Prints charset.
