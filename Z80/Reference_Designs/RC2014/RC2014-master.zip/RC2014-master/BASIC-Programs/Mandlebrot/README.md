Simple Mandlebrot program

Ascii version uses different characters to represent the density of the mandlebrot image.

Colour version uses escape characters to change colour to represent the density of the mandlebrot image.  Works great with the Pi Zero Terminal Module.

Play around with the variables to change the appearance
