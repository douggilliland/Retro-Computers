# RC2014-BASIC-Programs
A collection of BASIC programs that run on RC2014, using Microsoft BASIC.

Both MBASIC 4.7 as modified to suit the Classic RC2014 and MBASIC 5.21 / 5.29 for CP/M are suitable to use these programs.

More to follow soon...

## C and Assembly file upload for new users

Just built a Classic or Mini RC2014, and don't have an EEPROM burner?
Do you still want to do Assembly or C language programming and run these programs on your RC2014?

[<big>`hexload`</big>](https://github.com/RC2014Z80/RC2014/tree/master/BASIC-Programs/hexload) is the way you can upload and run either assembly or C compiled code on your RC2014.

