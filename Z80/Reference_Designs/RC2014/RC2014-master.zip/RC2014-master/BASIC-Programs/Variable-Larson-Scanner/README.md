Larson Scanner 
aka Knight Rider or Cylon scanner

Uses Digital I/O module and scans repeatedly, with the speed being based on the last button pushed on the module.
