Disassembler program written in BASIC by Bart Bozon
