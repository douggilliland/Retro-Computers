These files are modified versions of the ones created by Grant Searle that allows the RC2014 to run CP/M via a 68B50 (or 63B50) ACIA instead of a Z80 SIO/2

Credit goes to Mitch Lalovie for this
