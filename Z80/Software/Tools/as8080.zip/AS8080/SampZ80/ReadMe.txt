WARNING- the source code in these examples is not intended to assemble properly. It was used to test the Z80 assembler.

These are files used to test the z80 assembler, AS8080 

There are errors, purposely, to see what happens.

There is, also, correct source, to see what happens. 

None of these files are intended to be useful, except as a test of the assembler.

Some files require DRI macro files, such as Z80.LIB or COMPARE.LIB or MAKEDATE.LIB, which are not included here. 

All example source is to be considered Public Domain.