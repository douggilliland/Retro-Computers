#include <stdio.h>

void main() {
  printf("Hello, world(1)\n");
  fputs("Hello, world(2)\n",stdout);
}
