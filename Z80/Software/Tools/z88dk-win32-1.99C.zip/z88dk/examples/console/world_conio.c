/*
 *	Hello World
 */


#include <conio.h>


main()
{
	cprintf("Hello world! %d\n",12);
        while(!kbhit()){
        };
        getch();
}
