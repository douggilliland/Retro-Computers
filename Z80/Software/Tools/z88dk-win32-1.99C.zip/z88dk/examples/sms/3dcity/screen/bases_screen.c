#include "title_screen.h"

extern unsigned int screen_bases_screen_count;
extern unsigned int screen_bases_screen_timer;

void screen_bases_screen_init()
{
	screen_bases_screen_count = 0;
	screen_bases_screen_timer = 0;
}
