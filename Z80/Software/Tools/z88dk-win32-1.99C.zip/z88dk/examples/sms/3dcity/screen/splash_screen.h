#ifndef _SPLASH_SCREEN_H_
#define _SPLASH_SCREEN_H_

void screen_splash_screen_init();
void screen_splash_screen_load();
void screen_splash_screen_update(int *screen_type, int curr_joypad1, int prev_joypad1);

#endif//_SPLASH_SCREEN_H_
