#ifndef _TITLE_SCREEN_H_
#define _TITLE_SCREEN_H_

void screen_title_screen_init();
void screen_title_screen_load();
void screen_title_screen_update(int *screen_type, int curr_joypad1, int prev_joypad1);

#endif//_TITLE_SCREEN_H_
