This directory contains scripts that generate C code and the corresponding input files, to 
be used during development.

The output files are stored at .., so that the scripts are not necessary on the build farm.

To generate the scripts, call "make -f dev/Makefile" from ..
