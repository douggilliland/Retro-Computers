The m4 source code is not maintained in the z88dk repository.

Instead refer to:
https://www.gnu.org/software/m4/manual/m4-1.4.14/m4.html
