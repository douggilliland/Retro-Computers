#define PREFIX "/usr/local/share/z88dk"
#define UNIX 1
#define EXEC_PREFIX ""
#define Z88DK_VERSION "13913-9abd768-20190119"
