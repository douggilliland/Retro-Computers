These are RomWBW 2.5.1 boot files. 
- the .com files can be used to just load and boot a new RomWBW boot image
- the .sys files are for writing boot tracks. Note you need a 2.5.2 ROM installed, or it will not work!
