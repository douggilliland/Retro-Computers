/*

unistd.h - device_posix.c expects open,close etc. from here

*/

#include <io.h>
