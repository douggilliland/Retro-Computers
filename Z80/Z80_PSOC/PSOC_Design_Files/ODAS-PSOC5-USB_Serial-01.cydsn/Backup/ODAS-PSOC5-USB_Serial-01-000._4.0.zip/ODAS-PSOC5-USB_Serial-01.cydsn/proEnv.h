#if !defined(PROENV_H)
#define PROENV_H
#undef DEBUG_ON_PC
#ifdef DEBUG_ON_PC
#include "mytypes.h"
#endif /* DEBUG_ON_PC */
#endif  /* PROENV_H */
