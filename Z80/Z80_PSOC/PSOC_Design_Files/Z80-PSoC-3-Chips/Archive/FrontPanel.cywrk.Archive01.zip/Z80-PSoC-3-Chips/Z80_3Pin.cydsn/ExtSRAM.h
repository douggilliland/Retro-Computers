/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <project.h>

void SetExtSRAMAddr(uint32);
void WriteExtSRAM(uint32, uint8);
uint32 TestSRAM(void);
uint8 ReadExtSRAM(uint32);

/* [] END OF FILE */
