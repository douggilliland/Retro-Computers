/* ========================================
 *
 * PSoC:  PSoC CY8C5888LTI-5LP
 * Kit:   CY8CKIT-059
 * PS-2 PS/2 Keyboard decoder gets ASCII values
 * Jon Titus, Herriman, UT 2018
 * 03-12-2018 at 2007H MDST
 * Released as open-source code.
 * No restrictions on use.
 * Please acknowledge author in any derivative code!
 *
 * ========================================
*/

#include "project.h"

    uint16 SPI_data;            //Data from SPI port
    uint8 Keyboard_Data;        //Extracted key code for a pressed key
    uint8 SPI_Flag_Bits;        //Flag bits from the SPI port    
    uint8 KeyRelease_Flag;      //Flag indicates the release of a key
    uint8 Shift_Flag;           //Shift indication
    uint8 Old_Data;             //Previous keyboard data
    uint8 New_Data;             //Newest keyboard data
    uint8 Display_Data;         //ASCII value, or equivalent code for pressed key

//Function to handle flags when a shift-key code gets found in keyboard SPI data
void Shift_Detect(void)            
    {
        if (KeyRelease_Flag == 0x01)       //L or R Shift detected, test KeyRelease_Flag
        {
            Shift_Flag = 0x00;             //Key released preceded  this Shift, so clear shift
            KeyRelease_Flag = 0x00;        //Clear key-release flag, too
        }
        else
            Shift_Flag = 0x01;             //No previous Shift detected before now, so set Shift_Key flag now
    }
    
//----- Main program starts here -----

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //Upper-Case ASCII codes by keyboard-code index, 16 elements per row
    uint8 LC_Array[] =
       {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0B,0x60,0x0,
        0x0,0x0,0x0,0x0,0x0,0x71,0x31,0x0,0x0,0x0,0x7A,0x73,0x61,0x77,0x32,0x0,
        0x0,0x63,0x78,0x64,0x65,0x34,0x33,0x0,0x0,0x20,0x76,0x66,0x74,0x72,0x35,0x0,
        0x0,0x6E,0x62,0x68,0x67,0x79,0x36,0x0,0x0,0x0,0x6D,0x6A,0x75,0x37,0x38,0x0,
        0x0,0x2C,0x6B,0x69,0x6F,0x30,0x39,0x0,0x0,0x2E,0x2F,0x6C,0x3B,0x70,0x2D,0x0,
        0x0,0x0,0x27,0x0,0x5B,0x3D,0x0,0x0,0x0,0x0,0x0A,0x5D,0x0,0x5C,0x0,0x0,
        0x0,0x0,0x0,0x0,0x0,0x0,0x8,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
        0x0,0x0,0x0,0x0,0x0,0x0,0x1B,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
    
    //Upper-Case ASCII codes by keyboard-code index
    uint8 UC_Array[] =
       {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0B,0x7E,0x0,
        0x0,0x0,0x0,0x0,0x0,0x51,0x21,0x0,0x0,0x0,0x5A,0x53,0x41,0x57,0x40,0x0,
        0x0,0x43,0x58,0x44,0x45,0x24,0x23,0x0,0x0,0x20,0x56,0x46,0x54,0x52,0x25,0x0,
        0x0,0x4E,0x42,0x48,0x47,0x59,0x5E,0x0,0x0,0x0,0x4D,0x4A,0x55,0x26,0x2A,0x0,
        0x0,0x3C,0x4B,0x49,0x4F,0x29,0x28,0x0,0x0,0x3E,0x3F,0x4C,0x3A,0x50,0x5F,0x0,
        0x0,0x0,0x22,0x0,0x7B,0x2B,0x0,0x0,0x0,0x0,0x0A,0x7D,0x0,0x7C,0x0,0x0,
        0x0,0x0,0x0,0x0,0x0,0x0,0x8,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
        0x0,0x0,0x0,0x0,0x0,0x0,0x1B,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
    
    
    LED1_Write(0u);             //Turn off LED used for tests
    UART_1_Start();             //Start UART
    UART_1_ClearTxBuffer();     //Clear UART output buffer
    SPIS_1_Start();             //Start 11-bit SPI function
    SPIS_1_ClearRxBuffer();     //Clear the SPI output register
    //LED1_Write(1);            //Command to turn on LED during testing
    
    for(;;)     //Run this loop forever
    {
        if (0 < (SPIS_1_ReadRxStatus() & SPIS_1_STS_RX_FIFO_NOT_EMPTY))     //Wait for SPI data
        {    
            SPI_Flag_Bits = SPIS_1_ReadRxStatus();      //"Dummy" read to clear flag bits
            SPI_data = SPIS_1_ReadRxData();             //Get SPI data, 11 bits
            Keyboard_Data = (SPI_data & 0x01FE) >>1;    //Mask out all but data and Start bit
                                                        //shift right to remove Start bit
            switch (Keyboard_Data)
            {
                case 0xF0:                  //Key-release code 0xF0 detected
                KeyRelease_Flag = 0x01;     //set KeyRelease_Flag
                break;
                
                case 0x12:          //Left SHIFT key detected
                Shift_Detect();
                break;
                
                case 0x59:          //Right SHIFT key detected
                Shift_Detect();
                break;
                
                //When no "case" applies, program jumps (breaks) to here 
                default:                                    //Detect upper- or lower-case condition, get ASCII code
                Old_Data = New_Data;                        //Save previous data so we can check it
                New_Data = Keyboard_Data;                   //when key released.  Save newest UART input
                if (KeyRelease_Flag == 0x00)                //If no key-release detected yet,
                {                                           //check for a Shift key depressed
                    if (Shift_Flag == 0x01)                 //Shift detected, use UpperCase ASCII value
                    {
                        Display_Data = UC_Array[Keyboard_Data]; //Get upper-case ASCII value from array
                    }
                    else                                        //No shift detected, use LowerCase ASCII value
                    {
                        Display_Data = LC_Array[Keyboard_Data]; //Get lower-case ASCII value from array
                    }
                    UART_1_WriteTxData(Display_Data);       //Send ASCII data to UART for testing
                                                            //or use Display_Data as you choose
                }
                else                                        //"End" byte detected, so compare newest key byte
                {                                           //with the previous key's byte
                    if (Old_Data == New_Data)               //If they are equal, clear "End" flag
                        KeyRelease_Flag = 0x00;
                    else                                    //If old and new data don't agree,
                        //Error
                        KeyRelease_Flag = 0x00;
                        // Handle error here
                        LED1_Write(1);                      //Turn on LED upon error
                }
            }                    
        }              
    }
}

/* [] END OF FILE */
