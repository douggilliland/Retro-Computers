/*******************************************************************************
* File Name: LED1_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "LED1.h"

/* Check for removal by optimization */
#if !defined(LED1_Sync_ctrl_reg__REMOVED)

static LED1_BACKUP_STRUCT  LED1_backup = {0u};

    
/*******************************************************************************
* Function Name: LED1_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LED1_SaveConfig(void) 
{
    LED1_backup.controlState = LED1_Control;
}


/*******************************************************************************
* Function Name: LED1_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void LED1_RestoreConfig(void) 
{
     LED1_Control = LED1_backup.controlState;
}


/*******************************************************************************
* Function Name: LED1_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LED1_Sleep(void) 
{
    LED1_SaveConfig();
}


/*******************************************************************************
* Function Name: LED1_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LED1_Wakeup(void)  
{
    LED1_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
