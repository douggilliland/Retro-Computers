/*	outrel.c	relative output routines for generic assembler
                        by bill beech, february 1990

DESCRIPTION
    This file outputs a relocatable file image.  The format is
    described in file Intel 8085 OMF V4.doc.  It is a simplification of
    the Intel 8086 OMF specifically for 8-bit processors.  This was
    derrived from the Intel PLM80 and ASM80 output files using
    reverse engineering.

MODIFICATIONS
    01 Jan 90 -- Original - Supported Microsoft OMF
    30 May 10 -- Modified for an 8-bit OMF (Intel 8085 OMF)
    29 Jun 11 -- Modified for token-based assembler

*/

#define DEBUG   0

#include "asm.h"
#include "reloc.h"

/*      external globals */

extern  unsigned pc;
extern	int	pass;
extern	int	curseg, newseg;
extern  FILE	*rout, *dout;

/*	prototypes */

void inc_pc(int cnt);
unsigned int get_pc(void);
void set_pc(unsigned int pc);
char r_tflag(void);
void r_wrdout(unsigned word);
void r_bytout(unsigned char byte);
void r_data(void);
void r_brkout(int cnt);
void r_endrcd(int flag, unsigned short start);
void r_preamble(char *str);

//Intel OMF V4 functions
void modhdr(char *modnam, unsigned short codlen, unsigned short datlen, 
            unsigned short stklen, unsigned short memlen);
void modend(unsigned char flag, unsigned short segidx, unsigned short stadr);
void eofeof();
void extdef(char *name);
void pubdef(char *name, unsigned short segidx, unsigned segoff);
void data(unsigned short segidx, unsigned short segoff, unsigned char *buf, int bufp);
void fixup1(void);
void fixup2(void);
void fixup3(void);

//helper functions
void putstr(char *str);
void putidx(unsigned short idx);
void putwrd(unsigned short word);
void putbyt(unsigned char byte);
void putrcd(unsigned char *buf, int len);
int segment(void);

/*      locally defined globals */

#define	OBUF_SIZE	1030            //output buffer size
unsigned char obuf[OBUF_SIZE];          //output buffer
int ptr;
#define	BUF_SIZE	512             //segment buffer size
unsigned char   cbuf[BUF_SIZE],         //segment buffers
                dbuf[BUF_SIZE],
                sbuf[BUF_SIZE],
                mbuf[BUF_SIZE];
int             cp, dp, sp, mp;         //segment buffer indices
unsigned int    cpc = 0,                //current segment load offsets
                dpc = 0,
                spc = 0,
                mpc = 0;
unsigned int    cpc1 = 0,               //total segment lengths
                dpc1 = 0,
                spc1 = 0,
                mpc1 = 0;
unsigned int    apc2, cpc2, dpc2, spc2, mpc2; //segment specific PC's
int	f1c = 0, f2c = 0, f3c = 0;      //fixup indices
int	aseg, cseg, dseg, sseg, mseg;   //segment flags
int	rflag = 0;                      //relocatable flag
static unsigned short f1tab[BUF_SIZE][2], f2tab[BUF_SIZE], f3tab[BUF_SIZE][2];

/*      program code */

void inc_pc(int cnt)
{
    if (dout && DEBUG)  fprintf(dout, "\t+++inc_pc: curseg=%d cnt=%d\n",
        curseg, cnt);
    if (curseg == ASEG)
        apc2 += cnt;
    else if (curseg == CSEG)
        cpc2 += cnt;
    else if (curseg == DSEG)
        dpc2 += cnt;
    else if (curseg == SSEG)
        spc2 += cnt;
    else if (curseg == MSEG)
        mpc2 += cnt;
    if (dout && DEBUG)  fprintf(dout, "\t---inc_pc: apc2=%04X cpc2=%04X dpc2=%04X spc2=%04X mpc2=%04X\n",
        apc2, cpc2, dpc2, spc2, mpc2);
}
  
unsigned int get_pc(void)
{
    int val;

    if (dout && DEBUG)  fprintf(dout, "\t+++get_pc: curseg=%d\n",
        curseg);
    if (curseg == ASEG)
        val = apc2;
    else if (curseg == CSEG)
        val = cpc2;
    else if (curseg == DSEG)
        val = dpc2;
    else if (curseg == SSEG)
        val = spc2;
    else if (curseg == MSEG)
        val = mpc2;
    if (dout && DEBUG)  fprintf(dout, "\t---get_pc: val=%04X\n",
        val);
    return val & 0xffff;
}

void set_pc(unsigned int pc)
{
    if (dout && DEBUG)  fprintf(dout, "\t+++set_pc: pc=%04X\n",
        pc);
    if (curseg == ASEG)
        apc2 = pc;
    else if (curseg == CSEG)
        cpc2 = pc;
    else if (curseg == DSEG)
        dpc2 = pc;
    else if (curseg == SSEG)
        spc2 = pc;
    else if (curseg == MSEG)
        mpc2 = pc;
}

char r_tflag()
    {
    if (rflag & EXTERN)
        return 'X';
    else if (rflag & RELOCATE) {
        if (rflag & CODE)
            return 'c';
        else if (rflag & DATA)
            return 'd';
        else if (rflag & STACK)
            return 's';
        else if (rflag & MEMORY)
            return 'm';
    } else
        return ' ';
    }

void r_wrdout(unsigned word)
    {
    if (dout && DEBUG)  fprintf(dout,"\t+++r_wrdout; curseg=%d word=%04X rflag=%04X - ", curseg, word, rflag);
    if (rflag & EXTERN) {
        if (dout && DEBUG)  fprintf(dout,"Extern\n");
        if (cp > (BUF_SIZE-2) || dp > (BUF_SIZE-2) || sp > (BUF_SIZE-2) || mp > (BUF_SIZE-2)) 
            /* can't split words across DATA records */
            r_data(); 
        f1tab[f1c][0] = word;
        if (curseg == CSEG)
            f1tab[f1c++][1] = cp;
        else if (curseg == DSEG)
            f1tab[f1c++][1] = dp;
        else if (curseg == SSEG)
            f1tab[f1c++][1] = sp;
        else if (curseg == MSEG)
            f1tab[f1c++][1] = mp;
        r_bytout(0);			/* put zeros into data record */
        r_bytout(0);
    } else if (rflag & RELOCATE) {
        if (dout && DEBUG)  fprintf(dout,"Relocate - ");
        if (cp > (BUF_SIZE-2) || dp > (BUF_SIZE-2) || sp > (BUF_SIZE-2) || mp > (BUF_SIZE-2)) 
            r_data();                   /* can't split words across DATA records */
        if ((rflag & 0x03) == curseg) {
            if (dout && DEBUG)  fprintf(dout,"Intersegment\n");
            if (curseg == CSEG)
                f2tab[f2c++] = cp;
            else if (curseg == DSEG)
                f2tab[f2c++] = dp;
            else if (curseg == SSEG)
                f2tab[f2c++] = sp;
            else if (curseg == MSEG)
                f2tab[f2c++] = mp;
            r_bytout(word & 0xff);
            r_bytout(word >> 8);
        } else {
            if (dout && DEBUG)  fprintf(dout,"Intrasegment\n");
            f3tab[f3c][0] = rflag & 0x03;
            if (curseg == CSEG)
                f3tab[f3c++][1] = cp;
            else if (curseg == DSEG)
                f3tab[f3c++][1] = dp;
            else if (curseg == SSEG)
                f3tab[f3c++][1] = sp;
            else if (curseg == MSEG)
                f3tab[f3c++][1] = mp;
            r_bytout(word & 0xff);
            r_bytout(word >> 8);
        }
    } else {
        if (dout && DEBUG)  fprintf(dout,"Just data\n");
        r_bytout(word & 0xff);
        r_bytout(word >> 8);
    }
} /* end of wrdout */

void r_bytout(unsigned char byte)
  {
    if (dout && DEBUG)  fprintf(dout,"\t+++r_bytout byte=%02X cp=%04X dp=%04X sp=%04X mp=%04X\n", 
        byte, cp, dp, sp, mp);
    if (curseg == CSEG) {
        if (cp >= BUF_SIZE)             //buffer full?
            r_data();                   //dump it
        cbuf[cp++] = byte;              //store next byte
    } else if (curseg == DSEG) {
        if (dp >= BUF_SIZE)             //buffer full?
            r_data();                   //dump it
        dbuf[dp++] = byte;              //store next byte
    } else if (curseg == SSEG) {
        if (sp >= BUF_SIZE)             //buffer full?
            r_data();                   //dump it
        sbuf[sp++] = byte;              //store next byte
    } else if (curseg == MSEG) {
        if (mp >= BUF_SIZE)             //buffer full?
            r_data();                   //dump it
        mbuf[mp++] = byte;              //store next byte
    }
} /* end of r_bytout */

void r_data(void)
{
    if (dout && DEBUG)  fprintf(dout, "\t+++r_data: curseg=%d cp=%04X dp=%04X sp=%04X mp=%04X\n",
        curseg, cp, dp, sp, mp);
    if (dout && DEBUG)  fprintf(dout, "\t   r_data: cpc=%04X dpc=%04X spc=%04X mpc=%04X\n",
        cpc, dpc, spc, mpc);
    if ((curseg == CSEG) && cp) {
        data(CSEG, cpc, cbuf, cp);		/* output CODE segment */
        cpc += cp;
        cpc1 += cp;
        cp = 0;
    } else if ((curseg == DSEG) && dp) {
        data(DSEG, dpc, dbuf, dp);		/* output DATA segment */
        dpc += dp;
        dpc1 += dp;
        dp = 0;
    } else if ((curseg == SSEG) && sp) {
        data(SSEG, spc, sbuf, sp);		/* output STACK segment */
        spc += sp;
        spc1 += sp;
        sp = 0;
    } else if ((curseg == MSEG) && mp) {
        data(MSEG, mpc, mbuf, mp);		/* output MEMORY segment */
        mpc += mp;
        mpc1 += mp;
        mp = 0;
    }
    if (dout && DEBUG)  fprintf(dout, "\t---r_data: cpc1=%04X dpc1=%04X spc1=%04X mpc1=%04X\n",
        cpc1, dpc1, spc1, mpc1);
}
  
void r_brkout(int cnt)
{
    if (dout && DEBUG)  fprintf(dout,"\t+++r_brkout: cnt=%d\n", cnt);
    r_data();			        /* output the rest of previous segment */
    if (newseg) {
        curseg = newseg;
        newseg = 0;
    }
    while (cnt) {
        r_bytout(0);
        --cnt;
    }
} /* end of brkout */

void r_endrcd(int flag, unsigned short start)
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++r_endrcd: cpc1=%04X, dpc1=%04X, spc1=%04X, mpc1=%04X\n",
                cpc1, dpc1, spc1, mpc1);
        r_data();
        modend(0, 1, start);		/* force cseg */
        eofeof();
    }
}

/*	output the preamble necessary for link */

void r_preamble(char *str)
{
    if (dout && DEBUG)
        fprintf(dout,"\t+++r_preamble %s\n", str);
    modhdr(str, cpc1, dpc1, spc1, mpc1);
    f1c = f2c = f3c = 0;
    cpc = dpc = spc = mpc = 0;
}

/*      Intel 8085 OMF V4 routines */

/*	output a 8085 MODHDR record */

void modhdr(char *modnam, unsigned short codlen, unsigned short datlen, 
            unsigned short stklen, unsigned short memlen)
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++modhdr: modnam=%s, codlen=%04X, datlen=%04X, stklen=%04X, memlen=%04X\n",
                modnam, codlen, datlen, stklen, memlen);
        obuf[0] = MODHDR;
        ptr = 3;
        putstr(modnam);     /* module name */
        putwrd(pass);       /* unknown word flag */
        putidx(CSEG);       /* code segment length */
        putwrd(codlen);
        putbyt(0x03);
        putidx(DSEG);       /* data segment length */
        putwrd(datlen);
        putbyt(0x03);
        putidx(SSEG);       /* stack segment length */
        putwrd(stklen);
        putbyt(0x03);
        putidx(MSEG);       /* memory segment length */
        putwrd(memlen);
        putbyt(0x03);
        putrcd(obuf, ++ptr);/* output MODHDR record */
    }
}

/*	output a 8085 MODEND record */

void modend(unsigned char flag, unsigned short segidx, unsigned short stadr)
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++modend: flag=%02X, segidx=%04X, stadr=%04X\n", flag, segidx, stadr);
        obuf[0] = MODEND;
        ptr = 3;
        putbyt(flag);       /* start address? */
        putidx(segidx);     /* start segment ID */
        putwrd(stadr);      /* start segment offset */
        putrcd(obuf, ++ptr);/* output MODEND record */
    }
} /* end of modend */

/*      output an 8085 EOFEOF record */

void eofeof()
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++modeof:\n");
        obuf[0] = MODEOF;
        ptr = 3;
        putrcd(obuf, ++ptr);/* output MODEOF record */
    }
} /* end of modend */

/*	output a 8085 EXTDEF record */

void extdef(char *extnam)
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++extdef: extnam=%s\n", extnam);
        obuf[0] = EXTDEF;
        ptr = 3;
        putstr(extnam);
        putidx(0);
        putrcd(obuf, ++ptr);/* output EXTDEF record */
    }
}

/*	output a 8085 PUBDEF record */

void pubdef(char *name, unsigned short segidx, unsigned segoff)
{
    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++pubdef: name=%s, segidx=%d, segoff=%04X\n", 
                name, segidx, segoff);
        obuf[0] = PUBDEF;
        ptr = 3;
        putidx(segidx);
        putwrd(segoff);
        putstr(name);
        putbyt(0);
        putrcd(obuf, ++ptr);/* output PUBDEF record */
    }
}

/*	output a DATA record */

void data(unsigned short segidx, unsigned short segoff, unsigned char *buf, int bufp)
{
    int i;

    if (pass == 2) {
        if (dout && DEBUG)
            fprintf(dout,"\t+++data: segidx=%d, segoff=%04X, bufp=%d\n", 
                segidx, segoff, bufp);
        obuf[0] = MODDAT;
        ptr = 3;
        putidx(segidx);
        putwrd(segoff);
        for (i=0; i<bufp; i++)
            putbyt(buf[i]);
        putrcd(obuf, ++ptr);/* output DATA record */
        if (f1c)
            fixup1();
        if (f2c)
            fixup2();
        if (f3c)
            fixup3();
    }
}

/*	output a FIXUP1 record - External name fixup */

void fixup1(void)
{
    int i;

    if (dout && DEBUG)
        fprintf(dout,"\t+++fixup1: f1c=%d\n", f1c);
    obuf[0] = FIXUP1;
    ptr = 3;
    putbyt(0x03);                       //unknown flag
    for (i=0; i<f1c; i++) {
        putwrd(f1tab[i][0]);            //target segment
        putwrd(f1tab[i][1]);            //target offset
    }
    putrcd(obuf, ++ptr);/* output FIXUP1 record */
    f1c = 0;
}

/*	output a FIXUP2 record - Relative in segment */

void fixup2(void)
{
    int i;

    if (dout && DEBUG)
        fprintf(dout,"\t+++fixup2: f2c=%d\n", f2c);
    obuf[0] = FIXUP2;
    ptr = 3;
    putbyt(0x03);                       //unknown flag
    for (i=0; i<f2c; i++) {
        putwrd(f2tab[i]);               //target offsets
    }
    putrcd(obuf, ++ptr);/* output FIXUP2 record */
    f2c = 0;
}

/*	output a FIXUP3 record - Relative to different segment */

void fixup3(void)
{
    int i, seg, flag;

    if (dout && DEBUG)
        fprintf(dout,"\t+++fixup3: f3c=%d\n", f3c);
    for (seg=0; seg<5; seg++) {
        flag = 1;                       //put out header
        for (i=0; i<f3c; i++) {
            if (f3tab[i][0] == seg) {     //got entry in this segment
                if (flag) {             //new header
                    obuf[0] = FIXUP3;
                    ptr = 3;
                    putbyt(f3tab[i][0]); //target segment index
                    putbyt(0x03);       //unknown flag
                    flag = 0;           //header done for this seg
                }
                putwrd(f3tab[i][1]);    //target offset
            }
        }
        if (flag == 0) putrcd(obuf, ++ptr); /* output FIXUP3 record for this seg*/
    }
    f3c = 0;
}

/*      OMF helper routines */

/*	output a string count and string */

void putstr(char *str)
{
    int i, len;

    len = strlen(str);
    putbyt(len);
    for (i=0; i<len; i++)
        putbyt(str[i]);
}
/*	output an index little endian */

void putidx(unsigned short idx)
{
    putbyt(idx);    // for now
 //   if (idx < 80)
 //       putbyt(idx);
 //   else
 //       putwrd(idx);
}

/*	output a word little endian */

void putwrd(unsigned short word)
    {
    putbyt(word & 0xff);
    putbyt(word >> 8);
    }
/*	output a byte */

void putbyt(unsigned char byte)
    {
    obuf[ptr++] = byte;
    }
/*	output the complete OMF record */

void putrcd(unsigned char *buf, int len)
    {
    int i;
    unsigned char chksum = 0;

    if (dout && DEBUG)
        fprintf(dout,"\t+++putrcd: len=%d\n", len);
    buf[1] = (len - 3) & 0xff;
    buf[2] = (len - 3) >> 8;
    for (i=0; i<len-1; i++) {
        fputc(buf[i], rout);
        chksum -= buf[i];
        }
    fputc(chksum, rout);
    } /* end of putrcd */

int segment(void)
{
    return curseg;
}
/* end of relout.c */

