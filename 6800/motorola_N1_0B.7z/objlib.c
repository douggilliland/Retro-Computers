/* 	objlib.c	(c) by bill beech, 2010

DESCRIPTION
	Common routines for manipulating OBJ files.

MODIFICATION HISTORY
	04 Mar 10 -- new project
*/

#include	<stdio.h>
#include	<ctype.h>
#include	<string.h>
#include	<stdlib.h>
#include	"reloc.h"

#define		RECLEN	1024
#define		SYMLEN	16

void		fatal(char *fmt, char *msg1);
void		dumpbuf(unsigned char *buf, int len, int off);
unsigned char	getbyt(FILE *fp);
unsigned short	getwrd(FILE *fp);
unsigned short	getidx(FILE *fp);
int		skprcd(FILE *fp);
int		getstr(FILE *fp);
unsigned char	chksum;
int		bytcnt;
char		str[RECLEN];

void fatal(char *fmt, char *msg1)
{
  fprintf(stderr,"DUMPOBJ: ");
  fprintf(stderr, fmt, msg1);
  exit(1);
} /* end of fatal */

/* dumpbuf	dump the data buffer in hex and ASCII
*/

void dumpbuf(unsigned char *buf, int len, int off)
{
    int i, j;
    unsigned char c;

    j = 0;
    while (len > 0) {
	printf("    %04X: ", off);
	if (len > 16)
	    for (i=0; i<16; i++) {
	        printf("%02X ", buf[j+i]);
		if (i == 7) printf(" ");
	    } 
	else
	    for (i=0; i<len; i++) { 
	        printf("%02X ", buf[j+i]);
		if (i == 7) printf(" ");
	    }
	    for (i=len; i<16; i++) {
	        printf("   ");
		if (i == 7) printf(" ");
	    }
	printf ("  ");
	if (len > 16)
	    for (i=0; i<16; i++) {
	        c = buf[j+i];
		if (isprint(c))
	            printf("%c", c);
		else
	            printf(".");
	    }
	else
	    for (i=0; i<len; i++) {
	        c = buf[j+i];
		if (isprint(c))
	            printf("%c", c);
		else
	            printf(".");
	    }
	printf("\n");
	j += 16;
	len -= 16;
	off += 16;
    }
} /* end of dumpbuf */

unsigned char getbyt(FILE *fp)
{
    unsigned char byte;

    byte = fgetc(fp);
    chksum += byte;
    bytcnt++;
    return byte;
} /* end of getchr */

unsigned short getwrd(FILE *fp)
{
    return (getbyt(fp) | (getbyt(fp) << 8));
} /* end of getwrd */

unsigned short getidx(FILE *fp)
{
    unsigned short val;

    val = getbyt(fp);
    if (val & 0x80) 
        val = (val & 0x7f) * 0x100 + getbyt(fp);
    return val;
} /* end of getidx */

int getstr(FILE *fp)
{
    int i, slen;

    slen = getbyt(fp);
    for (i=0; i<slen; i++)
        str[i] = getbyt(fp);
    str[i] = '\0';
    return slen;
} /* end of getstr */

int skprcd(FILE *fp)
{
    int i;
    unsigned short len;

    len = getwrd(fp);
    for (i=0; i<len; i++)
        getbyt(fp);
    return len;
} /* end of skprcd */

/* end of objlib.c */

