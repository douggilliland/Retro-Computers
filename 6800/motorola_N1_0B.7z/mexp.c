/*      expression.c  a generic 8-bit Motorola microprocessor assembler expression analyzer
        by bill beech

6.0A    27 Jun 11 - original
6.0C    28 Jul 11 - modified for motorola format source files
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define DEBUG   1

/*      external globals */

extern  FILE    *lout;
extern  FILE    *dout;
extern  int     opcode, opflag, error, byte, word, pc, operand_type, value;
extern  char    *cptr;
extern  int     error;
extern  int     rflag;
extern  SYM     *find_sym(char *);
extern  int     pass;
extern  char    *gettoken(void);
extern  int     linenum;
extern  char    getchr(int off);
extern  char    getUchr(int off);

/*	prototypes */

int     expression(void);
unsigned short level1(void);
unsigned short level2(void);
unsigned short level3(void);
unsigned short level4(void);
unsigned short level5(void);
unsigned short level6(void);
unsigned short level7(void);
unsigned short terminal(void);

/*      locally defined globals */

int     dirflag;

/*      program code */

/* expression  evaluate bitwise AND and OR */

int expression(void)
{
    unsigned short left, right, value;

    if (dout && DEBUG) fprintf(dout, "\t+++Enter expression() with first token=%s\n", printtoken(gettoken()));
    if (tokencmp("\n")) { //called with no data
//        error |= VALUE;
        return 0;
    }
    dirflag = 0;                        /* clear direct page flag */
    left = value = level1();
    while (tokencmp("|") || tokencmp("&")) {
        if (tokencmp("|")) {
            getnexttoken();
            right = level1();  
            value |= right;  
        } else if (tokencmp("&")) {
            getnexttoken();
            right = level1();
            value &= right;
        }
        if (dout && DEBUG) fprintf(dout, "\t   expression: left=%04X right=%04X\n", left, right);
    }
    if (dout && DEBUG) fprintf(dout, "\t---Exit expression() with value=%04X error=%08X token=%s rflag=%08X\n", 
        value, error, printtoken(gettoken()), rflag);
    return value;
}

/* level1       evaluate bitwise NOT operator
*/

unsigned short level1(void)
{
    unsigned short left, right, value;

    if (dout && DEBUG) fprintf(dout, "\t+++l1: token=%s\n", printtoken(gettoken()));
    left = value = level2();
    while (tokencmp("!")) {
        if (tokencmp("!")) {
            getnexttoken();
            right = ~level2();
            value &= right;
        }
        if (dout && DEBUG) fprintf(dout, "\t   l1: left=%04X right=%04X\n", left, right);
    }
    if (dout && DEBUG) fprintf(dout, "\t---l1: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level2       evaluate comarison operators
*/

unsigned short level2(void)
{
    unsigned short value;

    if (dout && DEBUG) fprintf(dout, "\t+++l2: token=%s\n", printtoken(gettoken()));
    value = level3();
    while (tokencmp("=") || tokencmp("<") || tokencmp(">") ||
        tokencmp("<=") || tokencmp(">=") || tokencmp("<>")) {
        if (tokencmp("=")) {
            getnexttoken();
            if (value == level3())
                value = 0xffff;
            else
                value = 0;
        } else if (tokencmp("<")) {
            getnexttoken();
            if (value < level3())
                value = 0xffff;
            else
               value = 0;
        } else if (tokencmp(">")) {
            getnexttoken();
            if (value > level3())
                value = 0xffff;
            else
                value = 0;
        } else if (tokencmp("<=")) {
            getnexttoken();
            if (value <= level3())
                value = 0xffff;
            else
                value = 0;
        } else if (tokencmp(">=")) {
            getnexttoken();
            if (value >= level3())
                value = 0xffff;
            else
                value = 0;
        } else if (tokencmp("<>")) {
            getnexttoken();
            if (value != level3())
                value = 0xffff;
            else
                value = 0;
        }
    }
    if (dout && DEBUG) fprintf(dout, "\t---l2: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level3       evaluate add and subtract operators
*/

unsigned short level3(void)
{
    unsigned short value, left, right;

    if (dout && DEBUG) fprintf(dout, "\t+++l3: token=%s\n", printtoken(gettoken()));
    left = value = level4();
    while (tokencmp("+") || tokencmp("-")) {
        if (tokencmp("+")) {
            getnexttoken();
            right = level4();
            value += right;
        } else if (tokencmp("-")) {
            getnexttoken();
            right = level4();
            value -= right;
        }
        if (dout && DEBUG) fprintf(dout, "\t   l3: left=%04X right=%04X\n", left, right);
    }
    if (dout && DEBUG) fprintf(dout, "\t---l3: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level4       evaluate multiply and divide operators
*/

unsigned short level4(void)
{
    unsigned short value, left, right;

    if (dout && DEBUG) fprintf(dout, "\t+++l4: token=%s\n", printtoken(gettoken()));
    left = value = level5();
    while (tokencmp("*") || tokencmp("/")) {
        if (tokencmp("*")) {
            getnexttoken();
            right = level5();
            value *= right;
        } else if (tokencmp("/")) {
            getnexttoken();
            right = level5();
            value /= right;
        }
        if (dout && DEBUG) fprintf(dout, "\t   l4: left=%04X right=%04X\n", left, right);
    }
    if (dout && DEBUG) fprintf(dout, "\t---l4: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level5       evaluate shift operators
*/

unsigned short level5(void)
{
    unsigned short value, left, right;

    if (dout && DEBUG) fprintf(dout, "\t+++l5: token=%s\n", printtoken(gettoken()));
    left = value = level6();
    while (tokencmp("<<") || tokencmp(">>")) {
        if (tokencmp("<<")) {
            getnexttoken();
            right = level6();
            value <<= right;
        } else if (tokencmp(">>")) {
            getnexttoken();
            right = level6();
            value >>= right;
        }
        if (dout && DEBUG) fprintf(dout, "\t   l5: left=%04X right=%04X\n", left, right);
    }
    if (dout && DEBUG) fprintf(dout, "\t---l5: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level6       evaluate unary + and - operators
*/

unsigned short level6(void)
{
    unsigned short value;

    if (dout && DEBUG) fprintf(dout, "\t+++l6: token=%s\n", printtoken(gettoken()));
    if (tokencmp("+")) {
        getnexttoken();
        value = level7();
    } else if (tokencmp("-")) {
        getnexttoken();
        value -= level7();
    } else 
        value = level7();
    if (dout && DEBUG) fprintf(dout, "\t---l6: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/* level6       evaluate ( & ) operators
*/

unsigned short level7(void)
{
    unsigned short value;

    if (dout && DEBUG) fprintf(dout, "\t+++l7: token=%s\n", printtoken(gettoken()));
    if (tokencmp("(")) {
        getnexttoken();
        value = expression();
        if (dout && DEBUG) fprintf(dout, "\t---l7-1: value=%04X - token=%s\n", value, printtoken(gettoken()));
        if (isnottoken(")"))
            error |= VALUE;
        else {
           getnexttoken();
        }
    } else
        value = terminal();
    if (dout && DEBUG) fprintf(dout, "\t---l7: value=%04X error=%08X token=%s\n", value, error, printtoken(gettoken()));
    return value;
}

/*      evaluate terminal values */

unsigned short terminal(void)
{
    unsigned short value;
    char *token;
    int i = 0, digit;

    if (dout && DEBUG) fprintf(dout, "\t+++term: token=%s\n", printtoken(gettoken()));
    value = 0;
    token = (char *) gettoken();
    if (is_symf(*token)) {
        if (dout && DEBUG) fprintf(dout, "\t   term: is symbol=%s\n", token);
        if (find_sym(token)) {          /* found it */
            set_flag(token, USED, 1);
            rflag |= (get_flag(token) & (DIRECT | UNDEFINED | RELOCATE | EXTERN | MEMORY | STACK | DATA | CODE));
            value = get_addr(token);
            error |= (UNDEFINED & rflag);
            if (rflag & DIRECT)
                dirflag = 1;
            add_xref(token, linenum);
        } else {                        /* new symbol */
            enter_sym(token);
            set_flag(token, USED | UNDEFINED, 1);
            value = 0xffff;
            add_xref(token, linenum);
        }
        if (dout && DEBUG) fprintf(dout, "\t   term: is symbol=%s value=%04X rflag=%08X\n", 
            printtoken(gettoken()), value, rflag);
    } else if (tokencmp("%")) {         /* evaluate binary number */
        if (dout && DEBUG) fprintf(dout, "\t   term: binary numeric constant\n");
        getnexttoken();                 /* step past '%' */
        while (getchr(i) == '0' || getchr(i) == '1') {
            digit = getchr(i) - '0';
            value = (value << 1) + digit;
            if (dout && DEBUG) fprintf(dout, "\t   binary: value=%04X, i=%d\n", value, i);
            i++;
        }
        if (dout && DEBUG) fprintf(dout, "\t---binary: value=%04X error=%08X\n", value, error);
    } else if (tokencmp("@")) {         /* evaluate octal number */
        if (dout && DEBUG) fprintf(dout, "\t   term: octal numeric constant\n");
        getnexttoken();                 /* step past '@' */
        while (isdigit(getchr(i)) && getchr(i) != '8' && getchr(i) != '9') {
            digit = getchr(i) - '0';
            value = (value << 3) + digit;
            if (dout && DEBUG) fprintf(dout, "\t   octal: value=%04X, i=%d\n", value, i);
            i++;
        }
        if (dout && DEBUG) fprintf(dout, "\t---octal: value=%04X error=%08X\n", value, error);
    } else if (tokencmp("$")) {         /* evaluate hexadecimal number */
        if (dout && DEBUG) fprintf(dout, "\t   term: hexadecimal numeric constant\n");
        getnexttoken();                 /* step past '$' */
        while (isxdigit(getUchr(i))) {
            digit = getUchr(i) - '0';
            if (digit > 9)
                digit -= 7;
            value = (value << 4) + digit;
            if (dout && DEBUG) fprintf(dout, "\t   hexadecimal: value=%04X, i=%d\n", value, i);
            i++;
        }
        if (dout && DEBUG) fprintf(dout, "\t---hexadecimal: value=%04X error=%08X\n", value, error);
    } else if (isdigit(*token)) {       /* evaluate decimal number */
        if (dout && DEBUG) fprintf(dout, "\t   term: decimal numeric constant\n");
        while (isdigit(getchr(i))) {
            value = value * 10 + getchr(i) - '0';
            if (dout && DEBUG) fprintf(dout, "\t   decimal: value=%04X, i=%d\n", value, i);
            i++;
        }
        if (dout && DEBUG) fprintf(dout, "\t---decimal: value=%04X error=%08X\n", value, error);
    } else if (tokencmp("*")) {         /* evaluate pc */
        if (dout && DEBUG) fprintf(dout, "\t   term: is '*'\n");
        value = get_pc();
        rflag |= RELOCATE;
    } else if (*token == '\'') {        /* character literal */
        if (dout && DEBUG) fprintf(dout, "\t   term: is char constant\n");
        value = getchr(1) & 0xff;
    } else {
        error |= VALUE;
        if (dout && DEBUG) fprintf(dout, "\t   term: not evaluated\n");
    }
    getnexttoken();                     /* step past TERMINAL */
    if (dout && DEBUG) fprintf(dout, "\t---term: value=%04X token=%s\n", value, printtoken(gettoken()));
    return value;
}

/* end of expression.c */
