/*	assem.c	a generic 8-bit microprocessor assembler 
		by bill beech

6.0A    24 Jun 11 - original
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	0

/*      external globals */

extern  char	*cptr;
extern  char    *gettoken(void);
extern  char    *getnexttoken(void);
extern  char    *printtoken(char *ptr);
extern  FILE	*dout, *lout;
extern  int     pass;
extern  char    txtbuf[];
extern  int     errcnt;
extern  int     ppc;
extern  int     level;
extern  int     ifdepth;
extern  int     rflag;
extern  char    label[];
extern  int     linenum;
extern  int     apc2, cpc2, dpc2, spc2, mpc2; //actual segment PC's
extern  FILE    *in[];
extern  int     line, linenum, page;

/*	prototypes */

void    assem(void);
void    emit(void);

/*      locally defined globals */

int     opcode, opflag, error, byte, byte1, extoff, word, pc, operand_type, value;
int     condflag;
char	label[SYMLEN+1];
int     curseg, newseg;

/*      program code */

void assem(void)
{
    char *str;

    line = 100;
    linenum = 1;
    page = 1;
    pc = 0;                             /* initial value */
    cpc2 = dpc2 = spc2 = mpc2 = apc2 = 0; /* reset relocatable PCs */
    errcnt = 0;                         /* clear error count */
    condflag = 1;                       /* allow assembly */
    ifdepth = 0;                        /* reset if nesting */
    level = 0;                          /* reset file nesting */
    in[level] = NULL;                   /* force initial file read */
    rflag = 0;                          /* reset relocatable flag */
    curseg = ASEG;                      /* reset segment to ASEG */
    newseg = 0;                         /* reset new segment */
    tokeninit();                        /* initialize token parser */
    h_init();                           /* initialize hex output */
    while (!tokencmp("")) {             /* while not EOF */
        if (dout && DEBUG) 
            fprintf(dout, "\t+++Assem: Top of loop  condflag=%d token=%s\n", 
                condflag, printtoken((char *) gettoken()));
        ppc = get_pc();
        if (dout && DEBUG) fflush(dout);
        if (tokencmp("\n"))             /* blank line? */
            goto endofline;
        if (tokencmp("*"))              /* comment line */
            goto endofline;
        if (!tokencmp(" ")) {           /* LABEL */
            str = gettoken();           /* get LABEL */
            strcpy(label, str);
            if (dout && DEBUG) 
                fprintf(dout, "\t   Assem: 1 label=%s\n", printtoken(label)); 
            if (dout && DEBUG) fflush(dout);
            if (pass == 1) {            /* pass 1 */
                if (str && condflag) {
                    if (dout && DEBUG) fprintf(dout, "\t   Assem: enter_sym\n"); 
                    if (dout && DEBUG) fflush(dout);
                    enter_sym(label);
                    if (dout && DEBUG) fprintf(dout, "\t   Assem: set_ln\n"); 
                    if (dout && DEBUG) fflush(dout);
                    set_ln(label, linenum);
                    if (dout && DEBUG) fprintf(dout, "\t   Assem: lset_flag\n"); 
                    if (dout && DEBUG) fflush(dout);
                    set_flag(label, curseg, 1);
                    if (dout && DEBUG) fprintf(dout, "\t   Assem: label entered\n"); 
                    if (dout && DEBUG) fflush(dout);
                    set_addr(label, ppc);
                }
            } else {                    /* pass 2 */
                error |= get_flag(str) & MULTIDEF;
            }
            if (dout && DEBUG) 
                fprintf(dout, "\t   Assem: 2 label=%s\n", str);
            if (dout && DEBUG) fflush(dout);
            getnexttoken();             /* step past LABEL */
            if (tokencmp(":"))          /* COLON? */
                getnexttoken();         /* step past COLON */
        } else
            getnexttoken();             /* step past WS */
        if (tokencmp("\n"))             /* empty line? */
            goto endofline;
        str = gettoken();               /* get OPCODE */
        if (dout && DEBUG) 
            fprintf(dout, "\t   Assem: opcode=%s\n", str);
        if (condflag == 0) {            /* conditional assembly off */
            dec_cond();                 /* do conditional mnemonics */
            goto endofline;             /* and nothing else */
        } else if (dec_cond())          /* conditional mnemonics */
            goto endofline;
        else if (dec_mne())             /* processor mnemonics */
            goto endofline;
        else if (dec_pseudo())          /* pseudo ops */
            goto endofline;
        else
            error |= ILLOP;
endofline:
        if (dout && DEBUG) 
            fprintf(dout, "\t   Assem: endofline: token=%s\n", printtoken(gettoken()));
        while(!tokencmp("\n") && !tokencmp("")) /* eat rest of line */
            getnexttoken();
        if (tokencmp("\n")) {           /* EOL */
            if (dout && DEBUG) 
                fprintf(dout, "\t   Assem: EOL\n");
            if (condflag == 0)          /* conditional assembly off */
                operand_type = 35;      
            emit();                     /* output code for current line */
            getnexttoken();             /* step past EOL */
            if (dout && DEBUG) fprintf(dout, "\t---Assem: Bottom token=%s\n", printtoken(gettoken()));
//            if (dout && DEBUG) dumpts(dout);
            if (dout && DEBUG) fflush(dout);
            if (error)
                errcnt++;
            error = 0;
            opcode = 0;
            operand_type = 0;
            rflag = 0;
            str = NULL;
        }
    }
}

void emit(void)
{
    if (dout && DEBUG) fprintf(dout, "\t+++Emit: pc=%04X ", pc);
    if (dout && DEBUG) fprintf(dout, "opcode=%02X ", opcode);
    if (dout && DEBUG) fprintf(dout, "error=%08X ", error);
    if (dout && DEBUG) fprintf(dout, "condflag=%04X ", condflag);
    if (dout && DEBUG) fprintf(dout, "curseg=%04X ", curseg);
    if (dout && DEBUG) fprintf(dout, "line=%s\n", txtbuf);
    if (dout && DEBUG) fflush(dout);
    if (lout) list();
    if (dout && DEBUG) fprintf(dout, "\t---Emit: token=%s\n", printtoken(gettoken()));
}

/* end of assem.c */
