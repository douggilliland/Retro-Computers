/*	m6800.c		operand routines for the 6800
                        by bill beech, 2008

DESCRIPTION
    This file assembles Motorola 6800 mnemonics.

MODIFICATIONS
    01 Jan 08 -- Original
    01 Aug 11 -- Modified for token-based assembler
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	0

#define	OPCNUM	172		        /* number of valid mnemonics */

/*      external globals */

extern  FILE    *dout;
extern  int     opcode, opflag, error, byte, word, pc, operand_type;
extern  int     cpc2, dpc2, spc2, mpc2; //actual segment PC's
extern  int     dirflag;

/*	prototypes */

int     dec_mne(void);
int     getopcodex(void);
void    getoperandx(void);
int     getacc_6800(void);
int     getidx_6800(void);

typedef struct {
        char operand[OPCLEN+1];
        unsigned char opcode;
        unsigned int opflag;
}	OPTAB;

static OPTAB optab[OPCNUM] = {
{ "ABA", 0x1B, 0x0011 },
{ "ADC", 0x89, 0x0052 },
{ "ADD", 0x8B, 0x0052 },
{ "AND", 0x84, 0x0052 },
{ "ASL", 0x48, 0x0041 },
{ "ASR", 0x47, 0x0041 },
{ "BCC", 0x24, 0x0022 },
{ "BCS", 0x25, 0x0022 },
{ "BEQ", 0x27, 0x0022 },
{ "BGE", 0x2C, 0x0022 },
{ "BGT", 0x2E, 0x0022 },
{ "BHI", 0x22, 0x0022 },
{ "BIT", 0x85, 0x0052 },
{ "BLE", 0x2F, 0x0022 },
{ "BLS", 0x23, 0x0022 },
{ "BLT", 0x2D, 0x0022 },
{ "BMI", 0x2B, 0x0022 },
{ "BNE", 0x26, 0x0022 },
{ "BPL", 0x2A, 0x0022 },
{ "BRA", 0x20, 0x0022 },
{ "BSR", 0x8D, 0x0022 },
{ "BVC", 0x28, 0x0022 },
{ "BVS", 0x29, 0x0022 },
{ "CBA", 0x11, 0x0011 },
{ "CLC", 0x0C, 0x0011 },
{ "CLI", 0x0E, 0x0011 },
{ "CLR", 0x4F, 0x0041 },
{ "CLV", 0x0A, 0x0011 },
{ "CMP", 0x81, 0x0052 },
{ "COM", 0x43, 0x0041 },
{ "CPX", 0x8C, 0x0072 },
{ "DAA", 0x19, 0x0011 },
{ "DEC", 0x4A, 0x0041 },
{ "DES", 0x34, 0x0011 },
{ "DEX", 0x09, 0x0011 },
{ "EOR", 0x88, 0x0052 },
{ "INC", 0x4C, 0x0041 },
{ "INS", 0x31, 0x0011 },
{ "INX", 0x08, 0x0011 },
{ "JMP", 0x4E, 0x0062 },
{ "JSR", 0x8D, 0x0062 },
{ "LDA", 0x86, 0x0052 },
{ "LDS", 0x8E, 0x0072 },
{ "LDX", 0xCE, 0x0072 },
{ "LSR", 0x44, 0x0041 },
{ "NEG", 0x40, 0x0041 },
{ "NOP", 0x01, 0x0011 },
{ "ORA", 0x8A, 0x0052 },
{ "PSH", 0x36, 0x0031 },
{ "PUL", 0x32, 0x0031 },
{ "ROL", 0x49, 0x0041 },
{ "ROR", 0x46, 0x0041 },
{ "RTI", 0x3B, 0x0011 },
{ "RTS", 0x39, 0x0011 },
{ "SBA", 0x10, 0x0011 },
{ "SBC", 0x82, 0x0052 },
{ "SEC", 0x0D, 0x0011 },
{ "SEI", 0x0F, 0x0011 },
{ "SEV", 0x0B, 0x0011 },
{ "STA", 0x87, 0x0052 },
{ "STS", 0x8F, 0x0072 },
{ "STX", 0xCF, 0x0072 },
{ "SUB", 0x80, 0x0052 },
{ "SWI", 0x3F, 0x0011 },
{ "TAB", 0x16, 0x0011 },
{ "TAP", 0x06, 0x0011 },
{ "TBA", 0x17, 0x0011 },
{ "TPA", 0x07, 0x0011 },
{ "TST", 0x4D, 0x0041 },
{ "TSX", 0x30, 0x0011 },
{ "TXS", 0x35, 0x0011 },
{ "WAI", 0x3E, 0x0011 }
};

/*      program code */

int dec_mne(void)
{
    int index;

    if (dout && DEBUG) fprintf(dout, "\t+++Enter dec_mne() with token=%s\n", printtoken(gettoken()));
    index = getopcodex();
    if (index) {
        opcode = optab[index-1].opcode;
        opflag = optab[index-1].opflag;
        getoperandx();                  /* handle operand */
        if (dout && DEBUG) fprintf(dout, "\t   opcode=%02X ", opcode);
        if (dout && DEBUG) fprintf(dout, "error=%08X ", error);
        if (dout && DEBUG) fprintf(dout, "opflag=%04X ", opflag);
        if (dout && DEBUG) fprintf(dout, "operand_type=%04X\n", operand_type);
        inc_pc(opflag & 0x0003);        /* step PC */
    }
    if (dout && DEBUG) fprintf(dout, "\t---Exit dec_mne() with index=%d\n", index);
    return index;
}

/* getopcodex	get the opcode from the input line */

int getopcodex(void)
{
    int i;
    char *opc;

    opc = (char *) getUtoken();          /* get opcode mnemonic */
    if (dout && DEBUG)  fprintf(dout, "\t+++getopcode_6800: opc=%s token=%s\n", 
        opc, printtoken(gettoken()));
    for (i=0; i<OPCNUM; i++)
        if (strncmp(optab[i].operand, opc, OPCLEN) == 0) { /* match? */
            getnexttoken();             /* step past OPCODE */                 
            return i+1;
        }
    return 0;
} /* end of getopcodex */

/* getoperandx	decode the operand for this instruction (6800)
*/

void getoperandx(void)
    {
    int r1, r2, exp;

    if (dout && DEBUG) fprintf(dout, "\t+++getoperand_6800: opcode=%02X opflag=%04X token=%s\n", 
        opcode, opflag, printtoken(gettoken()));
    switch(opflag & 0x00F0) {
        case 0x0010:	                /* inherent addressing mode  */
            if (dout && DEBUG) fprintf(dout, "\t   case 0x10:\n");
            operand_type = 1;
            break;
        case 0x0020:	                /* relative addressing mode */
            exp = expression();
            word = (exp - (get_pc() + 2));
//            if (word & 0xFF00)
//                error |= BYTEOFL;
            byte = word & 0xFF;
            operand_type = 2;
            if (dout && DEBUG) fprintf(dout, "\t   case 0x20: exp=%04X word=%04X, pc=%04X byte=%02X\n",
                exp, word, get_pc(), byte);
            break;
        case 0x0030:	                /* 1-byte with register */
            r1 = getacc_6800();
            if (dout && DEBUG) fprintf(dout, "\t   case 0x30: r1=%d, error=%d\n", r1, error);
            if (r1 == 1)
                opcode++;
            if (r1 > 1)
                error |= REGISTER;
            operand_type = 1;
            break;
        case 0x0040:	                /* reg A, reg B, indexed, or extended addressing mode */
            r1 = getacc_6800();
            if (dout && DEBUG) fprintf(dout, "\t   case 0x40: r1=%d, error=%d\n", r1, error);
            switch (r1) {
                case 0:			/* register A */
                    operand_type = 1;
                    break;
                case 1:			/* register B */
                    opcode += 0x10;
                    operand_type = 1;
                    break;
                case 2:			/* indexed or extended */
                    r2 = getidx_6800();
                    if (dout && DEBUG) fprintf(dout, "\t   case 0x40-IDX/EXT: r2=%d, error=%d opflag=%04X\n",
                        r2, error, opflag);
                    switch (r2) {
                        case 0:		/* extended */
                            opcode += 0x30;
                            opflag += 2;
                            operand_type = 3;
                            break;
                        case 1:         /* index only */
                            byte = 0;
                            opcode += 0x20;
                            opflag++;
                            operand_type = 2;
                            break;
                        case 2:         /* offset & index */
                            byte = word & 0xff;
                            if (word > 255)
                                error |=BYTEOFL;
                            opcode += 0x20;
                            opflag++;
                            operand_type = 2;
                            break;
                    }
                    if (dout && DEBUG) fprintf(dout, "\t   case 0x40-IDX/EXT: opflag=%04X, error=%d\n", opflag, error);
                break;
            }
            break;
        case 0x0050:	/* reg A or B and immediate/direct/indexex or extended addressing mode */
            r1 = getacc_6800();
            if (dout && DEBUG) fprintf(dout, "\t   case 0x50: r1=%d, error=%d\n", r1, error);
            switch (r1) {
                case 0:			/* reg A */
                    break;
                case 1:			/* reg B */
                    opcode += 0x40;
                    break;
                case 2:			/* no register */
                    error |= REGISTER;
                    break;
            }
            if (tokencmp("#")) {	/* immediate */
                getnexttoken();         /* step past '#' */
                word = expression();
                byte = word & 0xff;
                if (word > 255)
                    error |= BYTEOFL;
                operand_type = 2;
                if (dout && DEBUG) fprintf(dout, "\t   case 0x50-IMM: word=%04X, opcode=%02X, error=%d\n", word, opcode, error);
            } else {
                r2 = getidx_6800();
                switch(r2) {
                    case 0:		/* not indexed */
                        if (dirflag) {  /* direct */
                            byte = word & 0xff;
                            opcode += 0x10;
                            operand_type = 2;
                        } else {	/* extended */
                            opcode += 0x30;
                            opflag++;
                            operand_type = 3;
                        }
                        break;
                    case 1:
                        byte = 0;
                        opcode += 0x20;
                        operand_type = 2;
                        break;
                    case 2:
                        byte = word & 0xff;
                        if (word > 255)
                            error |=BYTEOFL;
                        opcode += 0x20;
                        operand_type = 2;
                        break;
                }
            if (dout && DEBUG) fprintf(dout, "\t   case 0x50-exit: r2=%d, word=%04X, opcode=%02X, error=%d dirflag=%d\n",
                r2, word, opcode, error, dirflag);
            }
            break;
        case 0x0060:	                /* JMP or JSR */
            r1 = getidx_6800();
            if (dout && DEBUG) fprintf(dout, "\t   case 0x60: r1=%d, error=%d\n", r1, error);
            switch (r1) {
                case 0:
                    opcode += 0x30;
                    operand_type = 3;
                    opflag++;
                    break;
                case 1:
                    byte = 0;
                    opcode += 0x20;
                    operand_type = 2;
                    break;
                case 2:
                    byte = word & 0xff;
                    if (word > 255)
                        error |=BYTEOFL;
                    opcode += 0x20;
                    operand_type = 2;
                    break;
            }
            break;
        case 0x0070:	                /* immediate (2 byte), direct, indexed or extended */
            if (tokencmp("#")) {        /* immediate */
                getnexttoken();
                word = expression();
                opflag++;
                operand_type = 3;
                if (dout && DEBUG) fprintf(dout, "\t   case 0x70-IMM: word=%04X, error=%d\n", word, error);
            } else {
                r1 = getidx_6800();
                if (dout && DEBUG) fprintf(dout, "\t   case 0x70-Oth: r1=%d, error=%d\n", r1, error);
                switch (r1) {
                    case 0:
                        if (dirflag) {  /* direct */
                            byte = word & 0xff;
                            opcode += 0x10;
                            operand_type = 2;
                        } else {        /* extended */
                            opcode += 0x30;
                            opflag++;
                            operand_type = 3;
                        }
                        break;
                    case 1:
                        byte = 0;
                        opcode += 0x20;
                        operand_type = 2;
                        break;
                    case 2:
                        byte = word & 0xff;
                        if (word > 255)
                            error |=BYTEOFL;
                        opcode += 0x20;
                        operand_type = 2;
                        break;
                }
                if (dout && DEBUG) fprintf(dout, "\t   case 0x70-Oth-exit: r1=%d error=%d dirflag=%d\n", r1, error, dirflag);
            }
            break;
        default:
            break;
        }
//    inc_pc(opflag & 0x000F);
    if (dout && DEBUG) fprintf(dout, "\t--- getoperandx: pc=%04X opflag=%04X, error=%08X\n", get_pc(), opflag, error);
    } /* end of getoperandx */

int getacc_6800(void)
{
        int val;

    if (dout && DEBUG) fprintf(dout, "\t+++getacc_6800: token=%s\n", printtoken(gettoken()));
    if (tokencmp("A")) {
        getnexttoken();                 /* step past A */
        val = 0;
    } else if (tokencmp("B")) {
        getnexttoken();                 /* step past B */
        val = 1;
    } else
        val = 2;
    if (dout && DEBUG) fprintf(dout, "\t---getacc_6800: val=%d\n", val);
    return val;
} /* end of getacc_6800 */

int getidx_6800(void)
{
    int val;

    if (dout && DEBUG) fprintf(dout, "\t+++getidx_6800: token=%s\n", printtoken(gettoken()));
    if (nexttokencmp(",")) {             /* index & offset */
        word = expression();            /* get offset */
        getnexttoken();                 /* step past COMMA */
        if (isnottoken("X"))
            error |= REGISTER;
        getnexttoken();                 /* step past X */
        val = 2;
    } else if (tokencmp("X")) {         /* index only */
        getnexttoken();                 /* step past "X" */
        val = 1;
    } else {                            /* offset only */
        word = expression();            /* get offset */
        val = 0;
    }
    if (dout && DEBUG) fprintf(dout, "\t---getidx_6800: val=%d\n", val);
    return val;
} /* end of getidx_6800 */

/* end of o6800.c */
