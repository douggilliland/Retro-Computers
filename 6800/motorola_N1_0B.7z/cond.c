/*	cond.c	conditional assembly decoder for a generic 8-bit microprocessor assembler
		by bill beech

6.0A    27 Jun 11 - original
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	1

/*      external globals */

extern  FILE	*dout;
extern  int	operand_type;
extern	int	condflag;

/*	prototypes */

int dec_cond(void);
int getccode(void);
void do_cond(int opnum);
void do_else(void);
void do_endif(void);
void do_if(void);
void do_ifn(void);


/*      locally defined globals */

//static  char    cont = 0;
//int     extern_cnt = 0;
int	ifnest[IFLEVEL], ifdepth = 0;

#define CCNUM          6             /* number of valid conditional mnemonics */

static  char    ctab[CCNUM][OPCLEN+1]={ /* pseudocode table for intel
    "      ","      ","      ","      ","      ","      ","      ","      ",
*/
    "IF",    "ELSE",  "ENDIF", "IFN"
};

/*      program code */

int dec_cond(void)
{
    int index;

    if (dout && DEBUG) fprintf(dout, "\t+++Enter dec_cond()\n");
    index = getccode();
    if (index) {
        do_cond(index);                 /* handle operand */
        if (dout && DEBUG) fprintf(dout, "\t   index=%02X\n", index);
        if (dout && DEBUG) fprintf(dout, "\t   operand_type=%04X\n", operand_type);
    }
    if (dout && DEBUG) fprintf(dout, "\t---Exit dec_cond() with condflag=%d\n", condflag);
    return index;
}

/* getccode    get the conditional from the input line
*/

int getccode(void)
{
    int i;
    char *opc;

    opc = (char *) getUtoken();         /* get opcode mnemonic */
    if (dout && DEBUG) fprintf(dout, "\t---getpcode: opc=%s\n", printtoken(gettoken()));
    for (i=0; i<CCNUM; i++)
        if (strncmp(ctab[i], opc, OPCLEN) == 0) { /* match? */
            getnexttoken();             /* step past OPCODE */                 
            return i+1;
        }
    return 0;		                /* error, pcode not found */
} /* end of getipcode */

/* do_pseudo	decode and handle the intel pseudo operation codes
*/

void do_cond(int opnum)
{
    if (dout && DEBUG) fprintf(dout, "\t+++icond: opnum=%d\n", opnum);
    switch (opnum) {
        case 1:                         /* if */
            do_if();
            break;
        case 2:                         /* else */
            do_else();
            break;
        case 3:                         /* endif */
            do_endif();
            break;
        case 4:                         /* ifn */
            do_ifn();
            break;
        }
} /* end of do_ipseudo */

void do_if(void)
{
    int i;

    if (dout && DEBUG) fprintf(dout, "\t+++do_if: token=%s\n", printtoken(gettoken()));
    ifnest[ifdepth++] = expression();
    if (ifdepth > IFLEVEL)
        fatal("IF statements nested too deeply","");
    condflag = 1;
    for (i=0; i<ifdepth; i++) {
        condflag &= ifnest[i];
    }
    if (dout && DEBUG) fprintf(dout, "\t---do_if: ifnest[%d]=%d, condflag=%d\n", i, ifnest[i], condflag);
} /* end of do_if */

void do_else(void)
{
    int i;

    if (dout && DEBUG) fprintf(dout, "\t+++do_else: token=%s\n", printtoken(gettoken()));
    if (ifnest[ifdepth-1])
        ifnest[ifdepth-1] = 0;
    else
        ifnest[ifdepth-1] = 1;
    condflag = 1;
    for (i=0; i<ifdepth; i++) {
        condflag &= ifnest[i];
    }
    if (dout && DEBUG) fprintf(dout, "\t---do_else: ifnest[%d]=%d, condflag=%d\n", i, ifnest[i], condflag);
} /* end of do_else */

void do_endif(void)
{
    int i;

    if (dout && DEBUG) fprintf(dout, "\t+++do_endif: token=%s\n", printtoken(gettoken()));
    ifdepth--;
    condflag = 1;
    for (i=0; i<ifdepth; i++) {
        condflag &= ifnest[i];
    }
    if (dout && DEBUG) fprintf(dout, "\t---do_endif: ifnest[%d]=%d, condflag=%d\n", i, ifnest[i], condflag);
} /* end of do_endif */

void do_ifn(void)
{
    int i;

    if (dout && DEBUG) fprintf(dout, "\t+++do_ifn: token=%s\n", printtoken(gettoken()));
    ifnest[ifdepth++] = expression();
    if (ifdepth > IFLEVEL)
        fatal("IF statements nested too deeply","");
    condflag = 1;
    for (i=0; i<ifdepth; i++) {
        condflag |= !ifnest[i];
    }
    if (dout && DEBUG) fprintf(dout, "\t---do_ifn: ifnest[%d]=%d, condflag=%d\n", i, ifnest[i], condflag);
} /* end of do_ifn */

/* end of ipseudo.c */
