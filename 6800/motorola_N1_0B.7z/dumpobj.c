/* 	dumpobj.c	(c) by bill beech, 2010

DESCRIPTION
        decodes a Intel ISIS-II OMF (*.obj/*.lib/*) to the screen.
        Actually and Intel V4 OMF for 8085

MODIFICATION HISTORY
        20 May 09 -- new project
        29 May 09 -- restored the microsoft COFF format
        28 May 10 -- modified for Intel 8085 V4 OMF
*/

#include	<stdio.h>
#include	<ctype.h>
#include	<string.h>
#include	<stdlib.h>
#include	"reloc.h"

#define		RECLEN	65535
#define		SYMLEN	16

typedef	struct	sym	{
        struct	sym	*next;
        char	type;
        char	symbol[SYMLEN+1];
        int	mod;
        int	val1;
        int	val2;
        int	val3;
        int	val4;
//	int	val5;
//	int	val6;
        }	SYM;

SYM	*sym_head = NULL;

void            print_segment(int SegmentID);
void		enter_sym(char type, char *sym, int mod, int val1, int val2, int val3, int val4);
void		dump_sym(void);
char		*get_sym(char type, int idx);
char		*get_sym1(char type, int mod, int idx);
unsigned char	chksum;
int		bytcnt;
char		str[RECLEN];

int main(int argc, char **argv)
{
    char from[128]; 
    int i, j, k, rtyp, len, len1, slen, flag = 1, cks, typ, cls;
    int segcnt, extcnt, filoff, lnoff;
    int segatr, seglen, segidx, clsidx, ovlidx;
    int bgidx, bsidx, bframe, puboff, typidx;
    int	extcnt1;
    int	enuoff;
    int locat, offset1, fixdat, frame, target2, offset2;
    int	segoff;
    int modcnt, modcnt1;
    FILE *fp1;
    unsigned char buf[RECLEN];
    int vrbflag = 0;
    int val1, val2, val3, val4;
    char *buf1;

    printf("Dumpobj Version 1.0e\nby Bill Beech\n");
    argv++;
    while (--argc) {		        /* parse options */
        if (**argv == '-') {
            switch(toupper(*(*argv+1))) {
            case 'V':	                /* verbose output */
                vrbflag = 1;
                argv++;
                break;
            default:		        /* undefined option */
                fatal("Unknown Option","");
                break;
            }
        } else
            break;
    }
    if (argc != 1)
        fatal("No file specified\n","");
    strcpy(from,*argv);
    if ((fp1 = fopen(from,"rb")) == NULL)
         fatal("Unable to open %s\n", from);
    extcnt1 = chksum = filoff = extcnt = 0;
    segcnt = lnoff = modcnt1 = 1;
    while (flag) {
        if (chksum)
            printf("Checksum error at offset %04X in module\n", filoff-1);
        bytcnt = 0;		        /* reset byte counter */
        chksum = rtyp = getbyt(fp1);    /* get a tag */
    //	printf("Record Type=%02X\n", rtyp);
    //	printf("Offset=%d\n", filoff);
        len1 = len = getwrd(fp1);       /* get record length */
        switch (rtyp) {
            case MODHDR:	        /* MODHDR - 0x02 */
                val1 = getstr(fp1) + 3; /* no trailing null */
                enter_sym('M', str, 1, 0, 1, modcnt1++, 0);
                printf("%06X MODHDR %s\t", filoff, str);
                val2 = getbyt(fp1);     /* abs or rel? */
                if (bytcnt < len) {
                    printf("    Relocatable Object Format File\n");
                    printf("Unk Flag = %02X\n", getbyt(fp1));
                    for (i=0; i<4; i++) { /* dump the unknown stuff */
                        val2 = getbyt(fp1);
                        printf("    Segment: ");
                        print_segment(val2);
                        val2 = getwrd(fp1);
                        printf("\tLength: %04X\t", val2);
                        val2 = getbyt(fp1);
                        printf("Unk Flag: %02X\n", val2);
                    }
                } else {
                    printf("    Absolute Object Format File\n");
                    printf("    Segment: ");
                    print_segment(val2);
                    val2 = getbyt(fp1);
                    printf("\tUnk Flag: %02X\n", val2);
                }
                break;
            case MODEND:	        /* MODEND - 0x04 */
                val1 = getbyt(fp1);     /* flag */
                printf("%06X MODEND flag=%02X  ", filoff, val1);
                if (val1) {             /* start address */
                    val2 = getbyt(fp1); /* start segment ID */
                    printf("Start Segment: ");
                    print_segment(val2);
                    val3 = getwrd(fp1); /* start address */
                    printf(" Start Address: %04X\n", val3);
               } else {
                    getbyt(fp1);        /* eat segment ID */
                    getwrd(fp1);        /* eat start address */
                    printf("\n", val3);
                }
                printf("----------------------------------\n", val3);
                break;
            case MODDAT:	        /* MODDAT - 0x06 */
                val1 = getbyt(fp1);     // should be an index - segment
                val2 = getwrd(fp1);     /* segment offset */
                printf("%06X MODDAT  Segment: ", filoff);
                print_segment(val1);
                printf(": Offset: %04X\n", val2);
                for (i=0; i<len-4; i++)
                    buf[i] = getbyt(fp1);
//	        dumpbuf(buf, len-4, val2);
                dumpbuf(buf, len-4, 0);
                break;
            case LINNUM:	        /* LINNUM - 0x08 */
                printf("%06X LINNUM\n", filoff);
                val1 = getbyt(fp1);     /* segment value */
                while (bytcnt < len) {
                    val2 = getwrd(fp1); /* address offset */
                    val3 = getwrd(fp1); /* get value */
                    printf("    Segment: ");
                    print_segment(val1);
                    printf("  Offset: %04X  Line #: %d\n", val2, val3);
                }
                break;
            case MODEOF:	        /* EOF - 0x0E */
                printf("%06X EOF\n", filoff);
                flag = 0;
                break;
            case DEBUGA:	        /* DEBUGA - 0x12 */
                printf("%06X DEBUG\n", filoff);
                val1 = getbyt(fp1);     /* segment value */
                while (bytcnt < len) {
                    val2 = getwrd(fp1); /* address offset */
                    getstr(fp1);        /* label */
                    getbyt(fp1);        /* eat trailing null */
                    printf("    Segment: ");
                    print_segment(val1);
                    printf("  Offset: %04X  Label: %s\n", val2, str);
                }
                break;
            case PUBDEF:	        /* PUBDEF - 0x16 */
                printf("%06X PUBDEF\n	Entry	Name	Segment	Offset\n", filoff);
                i = 1;
                val1=getbyt(fp1);       /* get segment id */
                while (bytcnt < len) {
                    val2=getwrd(fp1);   /* segment offset */
                    getstr(fp1);        /* get public name */
                    getbyt(fp1);        /* eat trailing null */
                    printf("	%d	%s	", i++, str);
                    print_segment(val1);
                    printf("	%04X\n", val2);
                    enter_sym('P', str, 1, val1, val2, modcnt1-1, 0);
                }
                break;
            case EXTDEF:	        /* EXTDEF - 0x18 */
                printf("%06X EXTDEF\n	Entry   Extn #	Name\n", filoff);
                i = 1;
                while (bytcnt < len) {
                    getstr(fp1);        /* get public name */
                    getbyt(fp1);        /* eat trailing null */
                    enter_sym('X', str, 1, 0, extcnt1, modcnt1-1, 0);
                    printf("	%d       %d	%s\n", i++, extcnt1++, str);
                }
                break;
            case FIXUP1:	        /* FIXUP1 - 0x20 - External Reference */
                i = 1;
                val1 = getbyt(fp1);     /* unknown flag */
                printf("%06X FIXUP1 Unk Flag: %02X  External Reference\n	Entry	Extn #	Target\n", filoff, val1);
                while (bytcnt <= len) {
                    val2 = getwrd(fp1);	/* get external entry number */
                    val3 = getwrd(fp1);	/* get target fixup address */
                    printf("	%d	%04X	%04X\n", i++, val2, val3);
                }
                break;
            case FIXUP2:	        /* FIXUP2 - 0x22 - Inter-Segment relative */
                i = 0;
                val1 = getbyt(fp1);     /* unknown flag */
                printf("%06X FIXUP2 Unk Flag: %02X InterSegment relative\nIndex	Target\n", filoff, val1);
                printf("%03d", i);
                while (bytcnt <= len) {
                    val2 = getwrd(fp1); /* get target fixup address */
                    printf("	%04X", val2);
                    i++;
                    if (i % 8 == 0)
                        printf("\n%03d", i);
                }
                printf("\n");
                break;
            case FIXUP3:	        /* FIXUP3 - 0x24 - Intra-Segment relative */
                i = 0;
                val1 = getbyt(fp1);     /* target segment ID*/
                val2 = getbyt(fp1);     /* unknown flag */
                printf("%06X FIXUP3 Target Segment: ", filoff);
                print_segment(val1);
                printf("    Unk Flag: %02X  IntraSegment relative\nIndex	Target\n", val2);
                printf("%03d", i);
                while (bytcnt <= len) {
                    val3 = getwrd(fp1); /* get target fixup addresss */
                    printf("	%04X", val3);
                    i++;
                    if (i % 8 == 0)
                        printf("\n%03d", i);
                }
                printf("\n");
                break;
            case LIBHDR:	        /* LIBHDR - 0x2C */
                modcnt = getwrd(fp1);
                val1 = (getwrd(fp1) * 128) + getwrd(fp1);
                printf("%06X LIBHDR module count=%d  LIBNAM offset=%04X\n", 
                    filoff, modcnt, val1);
                break;
            case LIBNAM:	        /* LIBNAM - 0x28 */
                printf("%06X LIBNAM\n	Entry	Name\n", filoff);
                i = 1;
                while (i <= modcnt) {
                    getstr(fp1);
                    printf("	%d	%s\n", i++, str);
                }
                break;
            case LIBLOC:	        /* LIBLOC - 0x26 */
                printf("%06X LIBLOC\n	Entry	Block	Byte    Library Offset\n", filoff);
                i = 1;
                while (i <= modcnt) {
                    val1 = getwrd(fp1);
                    val2 = getwrd(fp1);
                    printf("\t%d\t%d\t%d\t%04X\n", i++, val1, val2, (val1 * 128) + val2);
                }
                break;
            case LIBDIC:	        /* LIBDIC - 0x2A*/
                printf("%06X LIBDIC\n	Entry	Public Names\n", filoff);
                i = 1;
                while (i <= modcnt) {
                    printf("	%d	", i++);
                    while(getstr(fp1))
                        printf("%s ", str);
                    printf("\n");
                }
                break;
            case 0x1A:                  /* CPM EOF */
                printf("%06X CPM EOF\n", filoff);
                flag = 0;
                break;
            default:
                printf("%06X	%02X - Unknown Record Type\n", filoff, rtyp);
                for (i=0; i<len-1; i++) /* dump the bad record */
                    buf[i] = getbyt(fp1);
                dumpbuf(buf, len-1);
    //	    flag = 0;
            }
        cks = getbyt(fp1);
//	filoff += (len + 3);
        filoff += bytcnt;
    }
    fclose(fp1);
    dump_sym();
    return 0;
}

void print_segment(int SegmentID)
{
    switch(SegmentID) {
        case 0:
            printf("Abs");
            break;
        case 1:
            printf("Code");
            break;
        case 2:
            printf("Data");
            break;
        case 3:
            printf("Stack");
            break;
        case 4:
            printf("Memory");
            break;
        default:
            printf("%d", SegmentID);
            break;
        }
}

/* enter_sym	enter a new symbol into symbol list
*/

void enter_sym(char type, char *sym, int mod, int val1, int val2, int val3, int val4)
{
    SYM *ptr, *pptr = NULL, *nptr;
    int i;

//    printf("type=%c, sym=%s, mod=%d, val1=%04X, val2=%04X, val3=%04X, val4=%04X\n",
//	type, sym, mod, val1, val2, val3, val4);
    if ((nptr = (SYM *) malloc(sizeof(SYM))) == NULL)
        fatal("Unable to allocate memory for symbol","");
    nptr->next = NULL;		    /* initialize this entry */
    nptr->type = type;
    strcpy(nptr->symbol, sym);
    nptr->mod = mod;
    nptr->val1 = val1;
    nptr->val2 = val2;
    nptr->val3 = val3;
    nptr->val4 = val4;
    if (sym_head == NULL) {
        sym_head = nptr;	    /* link in first symbol */
    } else {
        ptr = sym_head;		    /* start at top of linked list */
        i = strcmp(ptr->symbol, nptr->symbol);
        if (i > 0) {		    /* if less then top of list, put on top */
            nptr->next = ptr;
            sym_head = nptr;
        } else { 
            pptr = sym_head;
            while (ptr) {           /* step through list */
                i = strcmp(ptr->symbol, nptr->symbol);
                if (i > 0)
                    break;
                pptr = ptr;
                ptr = ptr->next;
             }
             nptr->next = pptr->next;
             pptr->next = nptr;
        }
    }
} /* end of enter_sym */

/* dump_sym	dump the symbol table
*/

void dump_sym(void)
{
    int i;
    SYM *ptr;

    printf("Symbol Table:\n");
    printf("%16s %c %16s %4s %4s %4s %4s\n", "Symbol", 'T', "Module", "Val1", "Val2", "Val3", "Val4");
    printf("-------------------------------------------------------\n");
    ptr = sym_head;		    /* start at top */
    while(ptr) {
        printf("%16s %c %16s %04X %04X %04X %04X\n", ptr->symbol, ptr->type, get_sym('M', ptr->val3), 
                ptr->val1, ptr->val2, ptr->val3, ptr->val4);
        ptr = ptr->next;	    /* try next one */
    }
    printf("-------------------------------------------------------\n");
} /* end of dump_sym */
/* get_sym	get the value of the symbol
*/

char *get_sym(char type, int idx)
{
    SYM *ptr;

//    printf("get_sym: idx=%d - ", idx);
    ptr = sym_head;		    /* start at top */
    while(ptr) {
        if (ptr->type == type && ptr->val3 == idx) {
 //           printf("Return %s\n", ptr->symbol);
            return ptr->symbol;
            }
        ptr = ptr->next;	    /* try next one */
    }
//    printf("Return (NULL)\n");
    return NULL;
} /* end of get_sym */

char *get_sym1(char type, int mod, int idx)
{
    SYM *ptr;

//    printf("get_sym: idx=%d - ", idx);
    ptr = sym_head;		    /* start at top */
    while(ptr) {
        if (ptr->type == type && ptr->mod == mod && ptr->val2 == idx) {
 //           printf("Return %s\n", ptr->symbol);
            return ptr->symbol;
        }
        ptr = ptr->next;	    /* try next one */
    }
//    printf("Return (NULL)\n");
    return NULL;
} /* end of get_sym1 */

/* end of do.c */

