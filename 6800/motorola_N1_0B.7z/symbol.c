/*  symbol.c    a generic 8-bit Motorola microprocessor assembler symbol table handler
                by bill beech

DESCRIPTION
        symbol table routines for the generic assembler.

MODIFICATION HISTORY
        1990 -- new project
        06 Mar 10 -- Generalized functions for assembler/linker use
*/

#include "asm.h"

#define DEBUG 0

/* local typedefs and structures */

/*      external globals */

extern  char    *cptr;
extern  int     pass;
extern  unsigned pc;
extern  int     linemax;
extern  char    title[40];
extern  int     line;
extern  int     page;
extern  FILE    *dout, *lout;
extern  int     linenum;
extern  int     aseg;
extern  int     curseg;

/* prototypes */

int is_symf(char c);
int is_sym(char c);
void parse_sym(char *symbol);
void enter_sym(char *sym);
void set_addr(char *sym, unsigned addr);
void set_flag(char *sym, unsigned flag, int mode);
void set_seg(char *sym, unsigned seg);
void set_val2(char *sym, unsigned val);
void set_val3(char *sym, unsigned val);
unsigned get_flag(char *sym);
unsigned get_addr(char *sym);
unsigned get_seg(char *sym);
unsigned get_val2(char *sym);
unsigned get_val3(char *sym);
SYM *find_sym(char *sym);
void dict_sym(void);
void dump_sym(FILE *fp);
char disp(int c);
char disps(int c);
char dispm(int c);
void dump_xref(FILE *fp);

/*      locally defined globals */

SYM *sym_head = NULL;
SYM *sym_next = NULL;

/*      program code */

/* is_symf      determine if character is legal for first char of symbol
*/

int is_symf(char c)
{
    return (isalpha(c) || c == '_' || c == '?' || c == '.');
} /* end of issym */

/* is_sym       determine if character is legal for rest of symbol
*/

int is_sym(char c)
{
    return (isalnum(c) || c == '_' || c == '.' || c == '?');
} /* end of issym */

/* parse_sym    parse a symbol from the current pointer
*/

void parse_sym(char* symbol)
{
    char *ptr;

    ptr = symbol;
    while (is_sym(*cptr)) {             /* valid symbol char? */
        *(ptr++) = *(cptr++);
        if ((ptr - symbol) >= SYMLEN) { /* discard extra char */
            while (is_sym(*cptr))
                cptr++;
            break;
        }
    }
    *ptr = '\0';
    if (dout && DEBUG) fprintf(dout, "parse_sym: symbol=%s\n", symbol);
} /* end of parse_sym */

/* enter_sym    enter a new symbol into symbol list
*/

void enter_sym(char *sym)
{
    SYM *ptr, *pptr = NULL, *nptr;
    int i;

    if (dout && DEBUG) fprintf(dout, "\t+++enter_sym: sym=%s\n", sym);
    if (pass == 1) {   /* pass 1 */
        if (dout && DEBUG) fprintf(dout, "\t   enter_sym: pass==1\n");
        if ((ptr = find_sym(sym)) != NULL) { /* found label */
            if (ptr->flag & USED || ptr->flag & PUBLIC) {
                if (curseg) {          /* relocatable address relative to curseg */
                    ptr->flag = RELOCATE;
                    ptr->addr = get_pc();
                } else {                /* absolute address */
                    ptr->flag = ABSOLUTE;
                    ptr->addr = get_pc();
                }
                if ((ptr->addr & 0xFF00) == 0)
                    ptr->flag |= DIRECT;
                else
                    ptr->flag &= ~DIRECT;
                ptr->seg = curseg;
                ptr->val2 = 0;
                ptr->val3 = 0;
            } else {
                ptr->flag |= MULTIDEF;
            }
        } else {                        /* pass 1 and label not found */  
            if ((nptr = (SYM *) malloc(sizeof(SYM))) == NULL)
                fatal("Unable to allocate memory for symbol","");
            nptr->next = NULL;          /* initialize this entry */
            strcpy(nptr->symbol,sym);
            if (curseg) {               /* relocatable address relative to curseg */
                nptr->flag = RELOCATE;
                nptr->addr = get_pc();
            } else {                    /* absolute address */
                nptr->flag = ABSOLUTE;
                nptr->addr = get_pc();
            }
            if ((nptr->addr & 0xFF00) == 0)
                nptr->flag |= DIRECT;
            else
                nptr->flag &= ~DIRECT;
            nptr->seg = curseg;
            nptr->val2 = 0;
            nptr->val3 = 0;
            nptr->reflnk = NULL;
            if (sym_head == NULL) {
                sym_head = sym_next = nptr; /* link in first symbol */
            } else {
                ptr = sym_head;         /* start at top of linked list */
                i = strcmp(ptr->symbol, nptr->symbol);
                if (i > 0) {            /* if less then top of list, put on top */
                    nptr->next = ptr;
                    sym_head = nptr;
                } else { 
                    pptr = sym_head;
                    while (ptr) {       /* step through list */
                        i = strcmp(ptr->symbol, nptr->symbol);
                        if (i > 0)
                            break;
                        pptr = ptr;
                        ptr = ptr->next;
                    }
                    nptr->next = pptr->next;
                    pptr->next = nptr;
                }
            }
        }
    }
    if (dout && DEBUG) fprintf(dout, "\t---enter_sym: exit\n");
    if (dout && DEBUG) fflush(dout);
} /* end of enter_sym */

/* add_xref enter symbol reference line number to list
*/

void add_xref(char *sym, int num)
{
    SYM *ptr;
    XREF *xptr, *xptr1, *nptr;

    if (dout && DEBUG) 
        fprintf(dout,"add_xref: sym=%s, num=%d\n", sym, num);
    if ((pass == 2) && ((ptr = find_sym(sym)) != NULL)) {
        if ((nptr = (XREF *) malloc(sizeof(XREF))) == NULL)
            fatal("Unable to allocate memory for xref","");
        nptr->linnum = num;
        nptr->next = NULL;
        if (ptr->reflnk) {
            xptr = ptr->reflnk;
            while (xptr) {
                xptr1 = xptr;
                xptr = xptr->next;
            }
            xptr1->next = nptr;
        } else 
            ptr->reflnk = nptr;
    }
} /* end of set_addr */

/* set_ln enter symbol definition line number
*/

void set_ln(char *sym, int num)
{
    SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_ln: sym=%s, num=%d\n", sym, num);
    if ((ptr = find_sym(sym)) != NULL) {
        ptr->defnum = num;
    }
    if (dout && DEBUG) fflush(dout);
} /* end of set_addr */

/* set_addr enter an address value for a symbol
*/

void set_addr(char *sym, unsigned addr)
{
    SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_addr: sym=%s, addr=%08X\n", sym, addr);
    if ((ptr = find_sym(sym)) != NULL) {
        ptr->addr = addr;
        ptr->flag &= ~UNDEFINED;
        if ((ptr->addr & 0xFF00) == 0)
            ptr->flag |= DIRECT;
        else
            ptr->flag &= ~DIRECT;
    }
} /* end of set_addr */

/* set_flag set flag bits for a symbol
*/

void set_flag(char *sym, unsigned flag, int mode)
{
    SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_flag: sym=%s, flag=%08X, mode=%d\n", sym, flag, mode);
    if ((ptr = find_sym(sym)) != NULL) {
        switch (mode) {
        case 0:
            ptr->flag = flag;
            break;
        case 1:
            ptr->flag |= flag;
            break;
        case 2:
            ptr->flag &= flag;
            break;
        default:
            break;
        }
    }
    if (dout && DEBUG) fflush(dout);
} /* end of set_flag */

/* set_seg set segment for a symbol
*/

void set_seg(char *sym, unsigned seg)
{
     SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_seg: sym=%s, val=%08X\n", sym, seg);
    if ((ptr = find_sym(sym)) != NULL) {
        ptr->seg = seg;
    }
} /* end of set_seg */

/* set_val2 enter a value for val2 for a symbol
*/

void set_val2(char *sym, unsigned val)
{
     SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_val2: sym=%s, val=%08X\n", sym, val);
    if ((ptr = find_sym(sym)) != NULL) {
        ptr->val2 = val;
    }
} /* end of set_val2 */

/* set_val3 enter a value for val3 for a symbol
*/

void set_val3(char *sym, unsigned val)
{
     SYM *ptr;

    if (dout && DEBUG) fprintf(dout,"set_val3: sym=%s, val=%08X\n", sym, val);
    if ((ptr = find_sym(sym)) != NULL) {
        ptr->val3 = val;
    }
} /* end of set_val3 */

/* get_flag return flags for this symbol
*/

unsigned get_flag(char *sym)
{
    SYM *ptr;
    unsigned ret;

    if ((ptr = find_sym(sym)) != NULL) {
        ret = ptr->flag;
    }
    if (dout && DEBUG) fprintf(dout,"get_flag: sym=%s, flag=%08X\n", sym, ret);
    return ret;
} /* end of get_flag */

/* get_addr get the value of the symbol
*/

unsigned get_addr(char *sym)
{
    SYM *ptr;
    unsigned ret;

    if ((ptr = find_sym(sym)) != NULL)
        ret = ptr->addr;
    else
        ret = 0;
    if (dout && DEBUG) fprintf(dout,"get_addr: sym=%s, addr=%08X\n", sym, ret);
    return ret;
} /* end of get_addr */

/* get_seg get the value of the symbol segment
*/

unsigned get_seg(char *sym)
{
    SYM *ptr;
    unsigned ret;

    if ((ptr = find_sym(sym)) != NULL)
        ret = ptr->seg;
    else
        ret = 0;
    if (dout && DEBUG) fprintf(dout,"get_seg: sym=%s, segidx=%d\n", sym, ret);
    return ret;
} /* end of get_seg */

/* get_val2 get the value of the symbol val2
*/

unsigned get_val2(char *sym)
{
    SYM *ptr;
    unsigned ret;

    if ((ptr = find_sym(sym)) != NULL)
        ret = ptr->val2;
    else
        ret = 0;
    if (dout && DEBUG) fprintf(dout,"get_val2: sym=%s, val2=%08X\n", sym, ret);
    return ret;
} /* end of get_val2 */

/* get_val3 get the value of the symbol val3
*/

unsigned get_val3(char *sym)
{
    SYM *ptr;
    unsigned ret;

    if ((ptr = find_sym(sym)) != NULL)
        ret = ptr->val3;
    else
        ret = 0;
    if (dout && DEBUG) fprintf(dout,"get_val3: sym=%s, val3=%08X\n", sym, ret);
    return ret;
} /* end of get_val3 */

/* find_sym find a pointer to a symbol 
*/

SYM *find_sym(char *sym)
{
    SYM *ptr;

    ptr = sym_head;   /* start at top */
    while (ptr != NULL) {
        if (strcmp(ptr->symbol, sym) == 0)
            return ptr;
        else
            ptr = ptr->next;  /* try next one */
    }
    return NULL;
} /* end of find_sym */

/* dictionary  dump symbol dictionary to rel file
*/
 
void dict_sym(void)
{
    int new_cnt = 1;
    SYM *ptr;
    char disps();
    extern int extern_cnt;

    ptr = sym_head;   // start at top 
    while (ptr != NULL) {
//        if (ptr->flag & PUBLIC)
//            pubdef(ptr->symbol, 0, ptr->seg, ptr->addr);
        ptr = ptr->next;   // try next one 
    }
    ptr = sym_head;   // start at top 
    while (ptr != NULL) {
        if ((ptr->flag & EXTERN) && (ptr->flag & USED)) {
            ptr->addr = new_cnt++;
//            extdef(ptr->symbol);
        }
        ptr = ptr->next;   // try next one
    }
} // end of dict_sym

// dump_sym dump the symbol table

void dump_sym(FILE *fp)
{
    int i = 0;
    SYM *ptr;
    char disp();
    char disps();
    char dispm();

    if(fp == NULL)
        return;
    ptr = sym_head;   // start at top
    line = 100;
    while (ptr != NULL) {
        if (line > linemax && linemax) {
            fprintf(fp,"NJ7P Assembler");
            fprintf(fp,"\t%50s\tPage %-3d\n",title,page);
                fprintf(fp,"%16s %s %s %s %16s %s %s %s\n\n", 
                    "Symbol", "Addr", "Seg", "Flg", "Symbol", "Addr", "Seg", "Flg");
            page++;
            line = 5;
        }
            fprintf(fp,"%16s %04X  %c  %c%c  ", ptr->symbol, ptr->addr, disps(ptr->seg), disp(ptr->flag), dispm(ptr->flag));
        i++;
        if (i >= 2) {
            i = 0;
            fprintf(fp,"\n");
            line++;
        }
        ptr = ptr->next;   // try next one
    }
    fprintf(fp,"\n");
} // end of dump_sym

char disp(int c)
{
    if (c & SEGMENT)
        return 'S';
    if (c & PUBLIC)
        return 'P';
    if (c & EXTERN)
        return 'X';
    if (c & RELOCATE)
        return 'R';
    if (c & ABSOLUTE)
        return 'A';
    return ' ';
}

char disps(int c)
{
    if (c == ASEG)
        return 'A';
    if (c == CSEG)
        return 'C';
    if (c == DSEG)
        return 'D';
    if (c == MSEG)
        return 'M';
    if (c == SSEG)
        return 'S';
    return ' ';
}

char dispm(int c)
{
    if (c & MULTIDEF)
        return 'M';
    if (c & UNDEFINED)
        return 'U';
    if (c & DIRECT)
        return 'D';
    if (c & USED)
        return '*';
    return ' ';
}

void dump_xref(FILE *fp)
{
    int i = 0;
    SYM *ptr;
    XREF *xptr;

    if(fp == NULL)
        return;
    ptr = sym_head;   // start at top
    line = 100;
    while (ptr != NULL) {
        if (line > linemax && linemax) {
            fprintf(fp,"NJ7P Assembler");
            fprintf(fp,"\t%50s\tPage %-3d\n",title,page);
            fprintf(fp,"Definition\t\tReferences\n\n");
            page++;
            line = 5;
        }
        fprintf(fp,"%16s %05d\t", ptr->symbol, ptr->defnum);
        xptr = ptr->reflnk;             //reference number links
        while (xptr) {                  //while more references
            fprintf(fp, "%05d\t", xptr->linnum);
            xptr = xptr->next;
            i++;
            if (i >= 7) {               //7 per line
                i = 0;
                line++;
                fprintf(fp,"\n\t\t\t");
            }
        }
        fprintf(fp,"\n");
        i = 0;
        line++;
        ptr = ptr->next;            // try next symbol
    }
    fprintf(fp,"\n");
} // end of dump_xref

/* end of symbol.c */

