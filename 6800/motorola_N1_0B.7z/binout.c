/*	binout.c	output routines for .bin files for generic assembler
			by bill beech

DESCRIPTION
    This file outputs a binary file image.

MODIFICATIONS
    01 Jan 09 -- Original
    29 Jun 11 -- Modified for token-based assembler

*/

#include "asm.h"

#define DEBUG   1

/*      external globals */

extern  unsigned apc2;
extern	int	pass;
extern  FILE	*bout;
extern  FILE	*dout;
extern	unsigned opc;

/*	prototypes */

void b_wrdout(unsigned word);
void b_bytout(unsigned char byte);
void b_brkout(int cnt);
void b_endrcd(void);
void b_putrcd(void);

/*      program code */

void b_wrdout(unsigned word)
{
    if (dout && DEBUG) fprintf(dout,"\t+++b_wrdout: word=%04X\n", word);
    b_bytout(word >> 8);
    b_bytout(word);
}

void b_bytout(unsigned char byte)
{
    if (dout && DEBUG) fprintf(dout,"\t+++b_bytout: byte=%02X\n", byte);
    if (pass == 2) fputc(byte, bout);
    opc++;
} /* end of b_bytout */

void b_brkout(int cnt)
{
    unsigned i;

    if (dout && DEBUG) fprintf(dout,"\t+++b_brkout: cnt=%d apc2=%04X opc=%04x\n", cnt, apc2, opc);
    if (apc2 == opc)
        return;
    if (pass == 2) {
        if (dout && DEBUG) fprintf(dout,"\t   b_brkout: Step cnt=%d\n", cnt);
        for (i=0; i<cnt; i++)
            b_bytout(0);
    } 
//    if (opc && opc < apc2) {
//        if (dout && DEBUG) fprintf(dout,"\t+++b_brkout: step apc2-opc=%d\n", apc2 - opc);
 //       for (i=0; i<apc2-opc; i++)
//            b_bytout(0);
//    } else if (opc && opc > apc2) {
//        if (dout && DEBUG) fprintf(dout,"\t+++b_brkout: Seek apc2\n");
//        fseek(bout, apc2, SEEK_SET);
//    }
    opc = apc2;
} /* end of b_brkout */

void b_endrcd(void)
{
    if (dout && DEBUG) fprintf(dout,"\t+++b_endrcd: nop\n");
} /* end of b_endrcd */

void b_putrcd(void)
{
    if (dout && DEBUG) fprintf(dout,"\t+++b_putrcd: nop\n");
} /* end of b_putrcd */

/* end of binout.c */
