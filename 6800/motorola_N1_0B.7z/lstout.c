/*	lstout.c	list file output routines for generic assembler
			by bill beech

DESCRIPTION
        This file outputs the listing and selects the output routines for 
        relocatable, binary and hexadecimal file output.

MODIFICATIONS
        27 Jun 11 - Original
        21 Feb 12 - Output error lines on console during assembly

*/

#include "asm.h"

#define	DEBUG	0

/*  external globals */

extern  char	    *cptr;
extern  int	    pass;
extern  unsigned    pc;
extern	int	    rflag;
extern	int	    vflag;
extern  FILE	    *lout, *dout, *bout, *hout, *rout;
extern	int	    operand_type;
extern	int	    byte, byte1, word, extoff;
extern  char	    txtbuf[];
extern	int	    opcode;
extern  char	    fn[LEVEL][FNLEN+1];
extern  int	    level;

/*  prototypes */

void    list(void);
void    errout(char *err);
void    preamble(char *str);
char    tflag(void);
void    bytout(unsigned char byte);
void    brkout(int cnt);
void    wrdout(unsigned word);
void    endrcd(int flag, unsigned short start);

/*  locally defined globals */

int	        line = 100;
int	        error, errloc;
int	        linenum = 1;
int	        linemax = LINEMAX;
int	        page = 1;
int	        errcnt = 0;
unsigned        ppc = 0;
unsigned char	prebyte1, prebyte, postbyte;
unsigned char	string[STRMAX];
int	        strptr;
unsigned short	dwlist[DWMAX];
int	        dwptr;
char	        title[40];

/*  program code */

/* list		output listing
		output is controlled by the operand_type variable:

	0	ln buf                  no operand
	1	ln pc op buf		one byte operation
	2	ln pc op byte buf	two byte operation
	3	ln pc op word buf	three byte operation
	4	ln word buf		word operand only
	5	ln pc word buf		word operand and pc
	6	ln pc buf		pc only	
	7	ln pc byte buf		byte operand and pc
	8	ln pc byte    		byte operand and pc, no buf
	9	ln pc word    		word operand and pc, no buf
	10	ln word buf		word operand no object
	11	ln pc word buf		word operand and pc no obj
	12	ln pc op byte byte buf	three byte operation
	13	ln pc op byte byte buf	three byte operation
	14	ln pc op word buf	three byte operation (big endian)
	21	ln pc pr op buf		one byte operation + prebyte
	22	ln pc pr op byte buf	two byte operation + prebyte
	23	ln pc pr op word buf	three byte operation + prebyte
	30	ln pc pr pr1 byte op buf two byte operation + 2 prebyte
	31	ln pc pr op byte byte buf three byte operation + prebyte
	33	ln pc by by by by buf	output list of byte values
	34	ln pc word word   buf	output list of word values
	35	ln pc '~' buf		output '~' only 
	36	ln pc op pb buf		one byte operation + postbyte + byte
	37	ln pc op pb byte buf	one byte operation + postbyte + byte
	38	ln pc op pb word buf	one byte operation + postbyte + word
	42	ln pc op po byte buf	operation + postbyte + byte
	43	ln pc op po word buf	operation + postbyte + word
        44      ln                      line number only
        45                              page break
	80	ln buf                  no operand
	81	ln                      blank line
        82      opened file
        83      closed file
        84      continued in file
	95	--------------		word to object only
	97	--------------		byte to object only
	99	--------------		supress line printing
*/

void list(void)
{
    char errorc = ' ', buf[128];
    int i;

    if (dout && DEBUG)
        fprintf(dout, "\t+++list: rflag=%08X operand_type=%d error=%08X errloc=%d\n",
            rflag, operand_type, error, errloc);
    if (lout) {
        if (line && line >= linemax) {
            if (linemax) {
                if (pass == 2) fprintf(lout,"\fNJ7P Assembler");
                if (pass == 2) fprintf(lout,"\t%50s\tPage %-3d\n",title,page);
                if (pass == 2) fprintf(lout," Line  Addr Object Code\tSource Code\n\n");
                page++;
                line = 3;
            }
        }
        word &= 0xffff;
        if (error & TRUNCATE)
            errorc = 'T';
        if (error & DELIM)
            errorc = 'D';
        if (error & TRASH)
            errorc = 'G';
        if (error & COMMA)
            errorc = 'C';
        if (error & OPERAND)
            errorc = 'X';
        if (error & LENGTH)
            errorc = 'L';
        if (error & BYTEOFL)
            errorc = 'O';
        if (error & VALUE)
            errorc = 'V';
        if (error & ILLOP)
            errorc = 'I';
        if (error & ADDRESS)
            errorc = 'A';
        if (error & REGISTER)
            errorc = 'R';
        if (error & UNDEFINED)
            errorc = 'U';
        if (error & MULTIDEF)
            errorc = 'M';
        if (error & SEGMENT)
            errorc = 'S';
 //       if (error & FIRST)
 //           errorc = 'F';
 //       if (error & TOOMANY)
//            errorc = '2';
//        if (error & STR2LNG)
//            errorc = '1';
        switch (operand_type) {
            case 0:			/* no code generated */
                if (pass == 2) fprintf(lout,"%c%05d\t\t\t%s\n",
                    errorc,linenum,txtbuf);
                if (pass == 2 && error) printf("%c%05d\t\t\t%s\n",
                    errorc,linenum,txtbuf);
                break;
            case 1:			/* opcode only */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X\t\t%s\n",
                    errorc,linenum,ppc,opcode,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X\t\t%s\n",
                    errorc,linenum,ppc,opcode,txtbuf);
                bytout(opcode);
                break;
            case 2:			/* opcode and byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte,txtbuf);
                bytout(opcode);
                bytout(byte);
                break;
            case 3:			/* opcode and word operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,word,tflag(),txtbuf);
                bytout(opcode);
                wrdout(word);
                break;
            case 4:			/* word operand, no pc */
                if (pass == 2) fprintf(lout,"%c%05d      %04X\t%s\n",
                    errorc,linenum,word,txtbuf);
                if (pass == 2 && error) printf("%c%05d      %04X\t%s\n",
                    errorc,linenum,word,txtbuf);
                break;
            case 5:			/* word operand with pc */
                if (pass == 2) fprintf(lout,"%c%05d %04X %04X%c\t%s\n",
                    errorc,linenum,ppc,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %04X%c\t%s\n",
                    errorc,linenum,ppc,word,tflag(),txtbuf);
                wrdout(word);
                break;
            case 6:			/* pc only */
                if (pass == 2) fprintf(lout,"%c%05d %04X\t\t%s\n",
                    errorc,linenum,ppc,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X\t\t%s\n",
                    errorc,linenum,ppc,txtbuf);
                break;
            case 7:			/* byte operand with pc */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X\t\t%s\n",
                    errorc,linenum,ppc,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X\t\t%s\n",
                    errorc,linenum,ppc,byte,txtbuf);
                bytout(byte);
                break;
            case 8:			/* byte operand with pc, no buf */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X\n",
                    errorc,linenum,ppc,byte);
                if (pass == 2 && error) printf("%c%05d %04X %02X\n",
                    errorc,linenum,ppc,byte);
                bytout(byte);
                break;
            case 9:			/* word operand with pc, no buf */
                if (pass == 2) fprintf(lout,"%c%05d %04X %04X%c\n",
                    errorc,linenum,ppc,word, tflag());
                if (pass == 2 && error) printf("%c%05d %04X %04X%c\n",
                    errorc,linenum,ppc,word, tflag());
                wrdout(word);
                break;
            case 10:			/* word operand, no object */
                if (pass == 2) fprintf(lout,"%c%05d      %04X%c\t%s\n",
                    errorc,linenum,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d      %04X%c\t%s\n",
                    errorc,linenum,word,tflag(),txtbuf);
                break;
            case 11:			/* word operand with pc, no obj */
                if (pass == 2) fprintf(lout,"%c%05d %04X %04X\t%s\n",
                    errorc,linenum,ppc,word,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %04X\t%s\n",
                    errorc,linenum,ppc,word,txtbuf);
                break;
            case 12:			/* opcode and two byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte1,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte1,byte,txtbuf);
                bytout(opcode);
                bytout(byte1);
                bytout(byte);
                break;
            case 13:			/* opcode and two byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte,byte1,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,byte,byte1,txtbuf);
                bytout(opcode);
                bytout(byte);
                bytout(byte1);
                break;
            case 14:			/* opcode and word operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,word,tflag(),txtbuf);
                bytout(opcode);
                bytout(word>>8);
                bytout(word&0xff);
                break;
            case 21:			/* prebyte and opcode only */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,txtbuf);
                if (error) if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,txtbuf);
                bytout(prebyte);
                bytout(opcode);
                break;
            case 22:			/* prebyte, opcode and byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,byte,txtbuf);
                bytout(prebyte);
                bytout(opcode);
                bytout(byte);
                break;
            case 23:			/* prebyte, opcode and word operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,word,tflag(),txtbuf);
                bytout(prebyte);
                bytout(opcode);
                wrdout(word);
                break;
            case 30:			/* prebyte, opcode and byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,prebyte1,byte,opcode,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,prebyte1,byte,opcode,txtbuf);
                bytout(prebyte);
                bytout(prebyte1);
                bytout(byte);
                bytout(opcode);
                break;
            case 31:			/* prebyte, opcode and 2 byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,byte,byte1,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,prebyte,opcode,byte,byte1,txtbuf);
                bytout(prebyte);
                bytout(opcode);
                bytout(byte);
                bytout(byte1);
                break;
            case 33:			/* list of bytes */
                if (pass == 2) fprintf(lout,"%c%05d %04X ", errorc,linenum,ppc);
                if (pass == 2 && error) printf("%c%05d %04X ", errorc,linenum,ppc);
                switch (strptr) {
                    case 1:
                        if (pass == 2) fprintf(lout,"%02X\t\t", string[0]);
                        if (pass == 2 && error) printf("%02X\t\t", string[0]);
                        break;
                    case 2:
                        if (pass == 2) fprintf(lout,"%02X %02X\t", string[0], string[1]);
                        if (pass == 2 && error) printf("%02X %02X\t", string[0], string[1]);
                        break;
                    case 3:
                        if (pass == 2) fprintf(lout,"%02X %02X %02X\t", 
                            string[0], string[1], string[2]);
                        if (pass == 2 && error) printf("%02X %02X %02X\t", 
                            string[0], string[1], string[2]);
                        break;
                    default:
                        if (pass == 2) fprintf(lout,"%02X %02X %02X %02X\t",
                            string[0], string[1], string[2], string[3]);
                        if (pass == 2 && error) printf("%02X %02X %02X %02X\t",
                            string[0], string[1], string[2], string[3]);
                        break;
                }
                if (pass == 2) fprintf(lout,"%s", txtbuf);
                if (pass == 2 && error) printf("%s", txtbuf);
//                if (pass == 2) fprintf(lout, "\n %05d ", ++linenum);
                for (i=0; i<strptr; i++) {
                    bytout(string[i]);
//                    if (pass == 2) fprintf(lout, "%02X ", string[i]);
                }
                if (pass == 2) fprintf(lout,"\n");
                if (pass == 2 && error) printf("\n");
                break;
            case 34:			/* list of words */
                if (pass == 2) fprintf(lout,"%c%05d %04X ", errorc,linenum,ppc);
                if (pass == 2 && error) printf("%c%05d %04X ", errorc,linenum,ppc);
                switch (dwptr) {
                    case 1:
                        if (pass == 2) fprintf(lout,"%04X%c\t", dwlist[0],tflag());
                        if (pass == 2 && error) printf("%04X%c\t", dwlist[0],tflag());
                        break;
                    default:
                        if (pass == 2) fprintf(lout,"%04X%c %04X%c\t", 
                            dwlist[0], tflag(), dwlist[1], tflag());
                        if (pass == 2 && error) printf("%04X%c %04X%c\t", 
                            dwlist[0], tflag(), dwlist[1], tflag());
                        break;
                }
                if (pass == 2) fprintf(lout,"%s", txtbuf);
                if (pass == 2 && error) printf("%s", txtbuf);
                for (i=0; i<dwptr; i++)
                    wrdout(dwlist[i]);
                if (pass == 2) fprintf(lout,"\n");
                if (pass == 2 && error) printf("\n");
                break;
            case 35:			/* pc + '~' only */
                if (pass == 2) fprintf(lout,"%c%05d %04X~\t\t%s\n",
                    errorc,linenum,ppc,txtbuf);
                break;
            case 36:			/* opcode and postbyte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,txtbuf);
                bytout(opcode);
                bytout(postbyte);
                break;
            case 37:			/* opcode, postbyte and byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,byte,txtbuf);
                bytout(opcode);
                bytout(postbyte);
                bytout(byte);
                break;
            case 38:			/* opcode, postbyte and word operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,word,tflag(),txtbuf);
                bytout(opcode);
                bytout(postbyte);
                wrdout(word);
                break;
            case 42:			/* opcode, postbyte and byte operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,byte,txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %02X\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,byte,txtbuf);
                bytout(prebyte);
                bytout(opcode);
                bytout(byte);
                break;
            case 43:			/* opcode, postbyte and word operand */
                if (pass == 2) fprintf(lout,"%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,word,tflag(),txtbuf);
                if (pass == 2 && error) printf("%c%05d %04X %02X %02X %04X%c\t%s\n",
                    errorc,linenum,ppc,opcode,postbyte,word,tflag(),txtbuf);
                bytout(prebyte);
                bytout(opcode);
                wrdout(word);
                break;
            case 44:                    /* print "byte" blank lines */
                for (i=0; i<byte; i++)
                    if (pass == 2) fprintf(lout," %05d\n", linenum++);
                break;
            case 45:                    /* print "byte" blank lines */
                if (pass == 2) line = linemax;
                break;
            case 80:			/* no code generated */
                if (pass == 2) fprintf(lout," %05d\t\t\t%s\n",
                    linenum,txtbuf);
                break;
            case 81:			/* no code or text generated */
                if (pass == 2) fprintf(lout," %05d\n",
                    linenum);
                break;
            case 82:			/* opened file */
                if (dout && DEBUG) fprintf(dout,"\t   List: Opened fn[%d]=%s\n", level, fn[level]);
                if (pass == 2) fprintf(lout," Opened file %s\n", fn[level]);
                break;
            case 83:			/* Closed file */
                if (dout && DEBUG) fprintf(dout,"\t   List: Closed fn[%d]=%s\n", level, fn[level]);
                if (pass == 2) fprintf(lout," Closed file %s\n", fn[level]);
                break;
            case 84:			/* Continued in file */
                if (dout && DEBUG) fprintf(dout,"\t   List: Continued in fn[%d]=%s\n", level, fn[level]);
                if (pass == 2) fprintf(lout," Continued in file %s\n", fn[level]);
                break;
            case 95:			/* word to object only */
                wrdout(word);
                break;
            case 97:			/* byte to object only */
                bytout(byte);
                break;
            default:
                break;
            }
        if (operand_type < 85)
            line++;
        if (pass == 2 && error) {
            if (error & SEGMENT)
                errout("Segment");
            if (error & MULTIDEF)
                errout("Multidefined Label");
            if (error & UNDEFINED)
                errout("Undefined Label");
            if (error & REGISTER)
                errout("Invalid register");
            if (error & ADDRESS)
                errout("Address out of range");
            if (error & ILLOP)
                errout("Illegal Mnemonic");
            if (error & VALUE)
                errout("Operand value");
            if (error & BYTEOFL)
                errout("Byte overflow");
            if (error & LENGTH)
                errout("List length");
            if (error & OPERAND)
                errout("Operand syntax");
            if (error & COMMA)
                errout("Missing comma");
            if (error & TRASH)
                errout("Trash after operand");
//            if (error & FIRST)
//                errout("Opcode must be first in source file");
//            if (error & TOOMANY)
//                errout("Too many items in list");
//            if (error & STR2LNG)
//                errout("String too long");
        }
    }
} /* end of list */

void errout(char *err)
{
    fprintf(lout,"  *** %s", err);
    if (vflag) fprintf(lout,"  errloc=%d", errloc);
    fprintf(lout,"\n");
    printf("  *** %s", err);
    if (vflag) printf("  errloc=%d", errloc);
    printf("\n");
    line++;
}

void preamble(char *str)
{
    if (pass == 2)
        r_preamble(str);
}

char tflag(void)
{
    char r_tflag();

    if (rout)
        return (r_tflag());
    return (' ');
}

void wrdout(unsigned word)
{
    if (pass == 2) {
        if (bout)
            b_wrdout(word);
        else if (hout)
            h_wrdout(word);
        else if (rout)
            r_wrdout(word);
    }
}

void bytout(unsigned char byte)
{
    if (pass == 2) {
        if (bout)
            b_bytout(byte);
        else if (hout)
            h_bytout(byte);
        else if (rout)
            r_bytout(byte);
    }
}

void brkout(int cnt)
{
    if (pass == 2) {
        if (bout)
            b_brkout(cnt);
        else if (hout)
            h_brkout(cnt);
        else if (rout)
            r_brkout(cnt);
    }
}

void endrcd(int flag, unsigned short start)
{
    if (pass == 2) {
        if (bout)
            b_endrcd();
        else if (hout)
            h_endrcd(start);
        else if (rout)
            r_endrcd(flag, start);
    }
}

/* end of lstout.c */
