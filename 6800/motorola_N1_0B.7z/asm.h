/*	asm.h	a generic 8-bit Motorola microprocessor assembler
		by bill beech, february 1990

*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

#define	VERSION		"Version N1.0B"
#define	SOURCE		".asm"
#define	SYMBOL		".sym"
#define	LIST		".lst"
#define	HEX		".hex"
#define	BIN		".bin"
#define REL		".obj"
#define XREF1		".xrf"
#define DBG             ".dbg"
#define	INTEL		1
#define	LEVEL		3		/* number of levels of nesting */
#define	IFLEVEL		8		/* number of levels of nesting ifs*/
#define	SYMLEN		16		/* symbol length */
#define	LINEMAX		67		/* maximum lines per page (default)*/
#define OPCLEN		7
#define	STRMAX		128		/* maximum string length */
#define	DWMAX		20		/* maximum dw list length */
#define	FNLEN		128		/* length of a path and file name */
#define	OBJLEN	        15
#define LINLEN          128             /* maximum line length */

/*	symbol flag bit definitions */

#define DIRECT          0x00000400      /* symbol is in direct page */
#define ABSOLUTE        0x00000200      /* symbol is absolute */
#define	PUBLIC		0x00000100	/* symbol is public/relocatable */
#define	EXTERN		0x00000080	/* symbol is external */
#define	RELOCATE	0x00000040	/* symbol is relocatable */
#define	USED		0x00000020	/* symbol has been used */
#define	SET		0x00000010	/* set symbol */
#define	MEMORY		0x00000008	/* symbol is in memory seg */
#define	STACK		0x00000004	/* symbol is in stack seg */
#define	DATA		0x00000002	/* symbol is in data seg */
#define	CODE		0x00000001	/* symbol is in code seg */

/*      errors */

#define SEGMENT         0x80000000      /* segment error */
#define	MULTIDEF	0x40000000      /* multidefinition error */
#define UNDEFINED	0x20000000	/* undefined error */
#define REGISTER	0x10000000	/* register error */
#define ADDRESS		0x08000000	/* address out of range */
#define ILLOP		0x04000000	/* illegal mnemonic */
#define VALUE		0x02000000	/* bad operand */
#define BYTEOFL		0x01000000	/* byte overflow */
#define LENGTH		0x00800000	/* list too long */
#define	OPERAND		0x00400000	/* operand error */
#define	COMMA		0x00200000	/* missing comma */
#define	TRASH		0x00100000	/* trash on end of line */
#define	DELIM		0x00080000	/* bad delimiter */
#define TRUNCATE        0x00040000      /* truncation error */
#define	FIRST		0x00020000	/* opcode must first in file */
#define	TOOMANY		0x00010000	/* too many items in list */
#define	STR2LNG		0x00008000	/* string too long */

/*	typedefs */

typedef	struct	xref	{
	struct	xref	*next;
	int     linnum;                 /* line number  */
	}	XREF;

typedef	struct	sym	{
	struct	sym	*next;
	char	symbol[SYMLEN+1];       /* symbol name */
	unsigned addr;                  /* actual symbol value */
	unsigned flag;                  /* symbol type and error flags */
	unsigned seg;                   /* segment containing symbol */
	unsigned val2;
	unsigned val3;
        XREF     *reflnk;               /* crossreference linked list */
        int      defnum;                /* line number of definition */
	}	SYM;

#define ASEG    0
#define CSEG    1
#define DSEG    2
#define SSEG    3
#define MSEG    4

/* end of asm.h */
