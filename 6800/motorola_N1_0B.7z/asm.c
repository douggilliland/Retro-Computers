/*	    asm.c	a generic 8-bit Motorola microprocessor assembler
		        by bill beech, 1990

	    Definitions based on:

	    Macros have not been implemented.

            Relocatable format is Intel 8-bit OMF .OBJ format

            Based on RASM Ver. 5.0D.

            25 May 14 - Reworked to simple single processor assemblers.
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	0

/*      external globals */

extern  int	errcnt;
extern  int     level;

/*	prototypes */

/*      locally defined globals */

int	rflag;
char	fn[LEVEL][FNLEN];
FILE	*in[LEVEL];
FILE	*bout = NULL;
FILE	*dout = NULL;               /* debug file */
FILE	*hout = NULL;
FILE	*lout = NULL;
FILE	*rout = NULL;
FILE	*sout = NULL;
FILE	*xout = NULL;
int     curlin[LEVEL];
int	pass;
int     vflag = 0;
int     prebyte;

/*      program code */

main(int argc, char **argv)
{
    int i;
    int token;

    setup(argc, argv);                  /* parse options */
    printf("%s: %s\n", argv[0], VERSION); /* signon */
    printf("Copyright (c) 1984-2014 By Bill Beech, NJ7P\n");
    printf("Provided under the GNU GPL Version 2\n");
    for (pass = 1; pass < 3; pass++) {	/* two-pass assembler */
        printf("Pass %d\n", pass);
        if (pass == 2 && rout)          /* output relocatable preamble */
            preamble(*argv);
        assem();                        //assemble file
    }
    if (bout)			        /* close binary output file */  
        fclose(bout);
    if (hout)			        /* close hexadecimal output file */  
        fclose(hout);
    if (rout)			        /* close relocatable output file */  
        fclose(rout);
    printf("End of Assembly\n");        /* output error statistics */
    if (errcnt)
        printf("%d", errcnt);
    else
        printf("No");
    printf(" error%s found\n", (errcnt != 1) ? "s" : "");
    if (lout) {
        fprintf(lout,"\n\nEnd of Assembly\n");
        if (errcnt)
            fprintf(lout,"%d", errcnt);
        else
            fprintf(lout,"No");
        fprintf(lout," error%s found\n", (errcnt != 1) ? "s" : "");
        dump_sym(lout);
        if (xout) dump_xref(xout);
        fclose(lout);			/* close listing output file */	
    } 
    if (dout && DEBUG) {
        fprintf(dout,"\n\nEnd of Assembly\n");
        if (errcnt)
            fprintf(dout,"%d", errcnt);
        else
            fprintf(dout,"No");
        fprintf(dout," error%s found\n", (errcnt != 1) ? "s" : "");
        dump_sym(dout);
        fclose(dout);			/* close listing output file */	
    } 
}/* end of main */

/* end of asm.c */
