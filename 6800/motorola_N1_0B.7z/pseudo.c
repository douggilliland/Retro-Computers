/*	ipseudo.c	motorola pseudops decoder for a generic 8-bit microprocessor assembler
                by bill beech

6.0A    27 Jun 11 - original
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	1

/*      external globals */

extern  FILE    *dout;
extern  FILE	*dout, *bout, *hout, *rout;
extern  SYM	*find_sym(char *);
extern  char	*cptr;
extern  int     pass;
//extern  unsigned pc;
extern  int	operand_type;
extern  unsigned char	string[STRMAX];
extern  int	strptr;
extern  unsigned short	dwlist[DWMAX];
extern  int	dwptr;
extern	int	rflag;
extern  int	error;
extern  char	title[40];
extern  unsigned short byte, word;
extern	char	label[SYMLEN+1];
extern  char	fn[LEVEL][FNLEN];
extern  FILE	*in[LEVEL];
extern  int     curlin[LEVEL];
extern  int	level;
extern  int	linenum;
extern  int	linemax;
extern	int	condflag;
extern  int     curseg, newseg;
extern  int     apc2, cpc2, dpc2, spc2, mpc2; //actual segment PC's

/*	prototypes */

int dec_pseudo(void);
int getpcode(void);
void do_pseudo(int opnum);
void not_impl(void);
void do_aseg(void);
void do_cseg(void);
void do_dseg(void);
void do_sseg(void);
void do_mseg(void);
void do_comment(void);
void do_fcb(void);
void do_fcc(void);
void do_fdb(void);
void do_rmb(void);
void do_end(void);
void do_equate(void);
void do_extern(void);
void do_extern1(void);
void do_include(void);
void do_origin(void);
void do_page(void);
void do_public(void);
void do_public1(void);
void do_set(void);
void do_space(void);
void do_title(void);
void do_define(void);
void do_option(void);
void do_name(void);
void do_mon(void);

/*      locally defined globals */

//static  char    cont = 0;
int     extern_cnt = 0;
//int	ifnest[IFLEVEL], ifdepth = 0;

#define PCNUM          24             /* number of valid Motorola pseudo mnemonics */

static  char    ptab[PCNUM][OPCLEN+1]={ /* pseudocode table for motorola
    "      ","      ","      ","      ","      ","      ","      ","      ",
*/
    "CMT",   "FCB",   "FCC",   "FDB",   "END",   "EQU",   "EXT",   "LIB",
    "ORG",   "PAG",   "PUB",   "SET",   "SPC",   "TTL",   "RMB",   "DEF",
    "OPT",   "NAM",   "MON",   "ASEG",  "CSEG",  "DSEG",  "SSEG",  "MSEG"
};

/*      program code */

int dec_pseudo(void)
{
    int index;

    if (dout && DEBUG) fprintf(dout, "\t+++Enter dec_mpseudo()\n");
    index = getpcode();
    if (index) {
        do_pseudo(index);               /* handle operand */
        if (dout && DEBUG) fprintf(dout, "\t   index=%02X\n", index);
        if (dout && DEBUG) fprintf(dout, "\t   operand_type=%04X\n", operand_type);
    }
    if (dout && DEBUG) fprintf(dout, "\t---Exit dec_mpseudo() with index=%d\n", index);
    return index;
}

/* getpcode    get the pseudocode from the input line
*/

int getpcode(void)
{
    int i;
    char *opc;

    opc = (char *) getUtoken();         /* get opcode mnemonic */
//    if (dout && DEBUG) fprintf(dout, "\t---getpcode: opc=%s\n", opc);
    for (i=0; i<PCNUM; i++)
        if (strncmp(ptab[i], opc, OPCLEN) == 0) { /* match? */
            getnexttoken();             /* step past OPCODE */
            return i+1;
        }
    return 0;		                /* error, pcode not found */
} /* end of getipcode */

/* do_pseudo	decode and handle the intel pseudo operation codes
*/

void do_pseudo(int opnum)
{
    if (dout && DEBUG) fprintf(dout, "\t+++do_pseudo: opnum=%d\n", opnum);
    switch (opnum) {
        case 1:			        /* comment */
            do_comment();
            break;
        case 2:			        /* fcb */
            do_fcb();
            break;
        case 3:				/* fcc */
            do_fcc();
            break;
        case 4:		                /* fdb */
            do_fdb();
            break;
        case 5:		                /* end */
            do_end();
            break;
        case 6:		                /* equ */
            do_equate();
            break;
        case 7:		                /* external */
            do_extern();
            break;
        case 8:		                /* include */
            do_include();
            break;
        case 9:		                /* origin */
            do_origin();
            break;
        case 10:		        /* page */
            do_page();
            break;
        case 11:		        /* public */
            do_public();
            break;
        case 12:		        /* set */
            do_set();
            break;
        case 13:		        /* space */
            do_space();
            break;
        case 14:		        /* title */
            do_title();
            break;
        case 15:		        /* rmb */
            do_rmb();
            break;
        case 16:                        /* define */
            do_define();
            break;
        case 17:                        /* option */
            do_option();
            break;
        case 18:                        /* name */
            do_title();
            break;
        case 19:                        /* mon */
            do_mon();
            break;
        case 20:                        /* aseg */
            do_aseg();
            break;
        case 21:                        /* cseg */
            do_cseg();
            break;
        case 22:                        /* dseg */
            do_dseg();
            break;
        case 23:                        /* sseg */
            do_sseg();
            break;
        case 24:                        /* mseg */
            do_mseg();
            break;
        }
    if (dout && DEBUG) fprintf(dout, "\t---do_pseudo:\n");
} /* end of do_ipseudo */

void not_impl(void)
{
    if (dout && DEBUG) fprintf(dout, "Pseudo operation not implemented\n");
}

void do_aseg(void)
{
    if (rout == NULL) {
        curseg = ASEG;
    } else 
        error |= SEGMENT;
} /* end of do_aseg */

void do_cseg(void)
{
    if (rout) {
        newseg = CSEG;
        brkout(0);
    } else 
        error |= SEGMENT;
} /* end of do_cseg */

void do_dseg(void)
{
    if (rout) {
        newseg = DSEG;
        brkout(0);
    } else 
        error |= SEGMENT;
} /* end of do_dseg */

void do_sseg(void)
{
    if (rout) {
        newseg = SSEG;
        brkout(0);
    } else 
        error |= SEGMENT;
} /* end of do_sseg */

void do_mseg(void)
{
    if (rout) {
        newseg = MSEG;
        brkout(0);
    } else 
        error |= SEGMENT;
} /* end of do_mseg */

void do_comment(void)
{
    int typ, cls;
    char str[128];

    if (pass == 1) {
//        whitespacec();
        typ = expression();
//        whitespacec();
        cls = expression();
//        whitespacec();
        strcpy(str, cptr);
        str[strlen(str) - 1] = '\0';	/* eat end of line */
//	coment(typ, cls, str);
        }
}

void do_fcb(void)
{
    int flag = 1;
    short value;

if (dout && DEBUG) fprintf(dout, "\t---do_fcb: token=%s\n", printtoken(gettoken()));
    strptr = 0;
    while(flag) {
        if (strptr >= STRMAX) {	        /* string too long */
            error |= LENGTH;
            return;
        }
        if (tokencmp(","))
            value = 0;		        /* null entry is 0 - no error */
        else
            value = expression();       /* copy bytes */
        if (dout && DEBUG) fprintf(dout, "\t---do_fcb-1: value=%04X token=%s\n", 
            value, printtoken(gettoken()));
        if (value & 0xff00)
            error |= BYTEOFL;
        string[strptr++] = value & 0xff; /* copy bytes */
        inc_pc(1);
        if (tokencmp(","))		/* done? */
            getnexttoken();             /* step past COMMA */
        else
            flag = 0;			/* yes */
    }
    operand_type = 33;
} /* end of do_fcb */

void do_fcc(void)
{
    char delim, *token;
    int i = 0, value = 0;
    int flag = 1, digit;

    strptr = 0;
    if (dout && DEBUG) fprintf(dout, "\t+++do_fcc: token=%s\n", printtoken(gettoken()));
    token = (char *) gettoken();
    while(flag) {                       /* loop for COMMA separated values */                      
        if (strptr >= STRMAX) {         /* string too long */
            error |= LENGTH;
            return;
        }
        if (dout && DEBUG) fprintf(dout, "\t   top of loop: token=%s\n", token);
        if (*token == '$') {            /* hex digit */        
            getnexttoken();             /* step past '$' */
            token = (char *) gettoken();
            if (dout && DEBUG) fprintf(dout, "\t+++HEX: token=%s\n", token);
            while (isxdigit(*token)) {
                digit = toupper(*(token++)) - '0';
                if (digit > 9)
                    digit -= 7;
                value = (value << 4) + digit;
            }
            if (dout && DEBUG) fprintf(dout, "\t   HEX: value=%02X\n", value);
            string[strptr++] = value;     /* move to next character */
            inc_pc(1);
            getnexttoken();             /* step past number */
            token = (char *) gettoken();
            if (dout && DEBUG) fprintf(dout, "\t---HEX: token=%s\n", token);
        } else if (ispunct(*token)) {   /* /TEST/ form */ 
            delim = *token;             /* save delimiter */
            if (dout && DEBUG) fprintf(dout, "\t+++/TEST/: delim=%c\n", delim);
            token++;                    /* step past DELIM */
            if (dout && DEBUG) fprintf(dout, "\t   /TEST/: string=%s\n", token);
            while (*token != delim) {
                if (dout && DEBUG) fprintf(dout, "\t   /TEST/: *token=%02X delim=%02X\n", *token, delim);
                string[strptr++] = *(token++); /* copy characters */
                inc_pc(1);
                if (strptr >= STRMAX) { /* string too long */
                    error |= LENGTH;
                    return;
                }
            }
            getnexttoken();             /* step past string */
            token = (char *) gettoken();
            if (dout && DEBUG) fprintf(dout, "\t---/TEST/: token=%s\n", token);
        } else if (isalpha(*token)) {   /* SYMBOL */
            if (dout && DEBUG) fprintf(dout, "\t+++SYMBOL: token=%s\n", token);
            value = expression();       /* copy 8-bit value */
            string[strptr++] = value;
            if ((value & 0xFF00) != 0 && (value & 0xFF00) != 0xFF00)
                error |= TRUNCATE;
            inc_pc(1);
//            getnexttoken();
//            token = (char *) gettoken();
            if (dout && DEBUG) fprintf(dout, "\t---SYMBOL: token=%s value=%02X\n", token, value);
        } else if (isdigit(*token)) {   /* number */
            if (dout && DEBUG) fprintf(dout, "\t+++NUMBER: token=%s\n", token);
            value = expression();       /* copy 8-bit value */
            string[strptr++] = value;
            if ((value & 0xFF00) != 0 && (value & 0xFF00) != 0xFF00)
                error |= TRUNCATE;
            inc_pc(1);
            if (dout && DEBUG) fprintf(dout, "\t---NUMBER: token=%s value=%02X\n", token, value);
        }
        fprintf(dout, "\t   bottom of loop: token=%s\n", token);
        if (istoken(",")) {	        /* done? */
            getnexttoken();             /* step past COMMA */
            token = (char *) gettoken();
            if (dout && DEBUG) fprintf(dout, "\t   got comma: token=%s\n", token);
        } else {
            flag = 0;	                /* yes */
            fprintf(dout, "\t   out of loop: token=%s\n", token);
        }
    }
    operand_type = 33;
} /* end of do_fcc */

void do_fdb(void)
{
    word = expression();
    inc_pc(2);
    operand_type = 34;
    dwptr = 1;
    dwlist[0] = word;
    while (tokencmp(",")) {
        if (dwptr >= DWMAX) {
            error |= LENGTH;
            return;
        }
        rflag = 0;
        getnexttoken();                 /* step past "," */
        dwlist[dwptr++] = expression();
        inc_pc(2);
    }
} /* end of do_fdb */

void do_rmb(void)
{
    word = expression();
    inc_pc(word);
//    brkout(word);
    operand_type = 11;
} /* end of do_rmb */

void do_end(void)
{
    int flag = 0;

    if (dout && DEBUG) fprintf(dout, "\t+++do_end: curseg=%d, token=%s\n", curseg, printtoken(gettoken()));
    operand_type = 6;
    word = 0;
//    if (is_symf(*cptr) || is_sym(*cptr)) {
//        word = expression();
//        flag = 0xc0;
//        operand_type = 5;
//    }
    brkout(0);
    if (dout && DEBUG) fprintf(dout, "\t---do_end: flag=%02X, word=%04X\n", flag, word);
    endrcd(flag, word);
} /* end of do_end */

void do_equate(void)
{
    word = expression();
    set_addr(label,word);
    if (dout && DEBUG) fprintf(dout, "\t+++do_equate: label=%s addr=%04X \n", label, word);
        set_flag(label,~RELOCATE, 2);
    operand_type = 10;
} /* end of do_equate */

void do_extern(void)
{
    if (dout && DEBUG) fprintf(dout,"do_extern:\n");
    if (rout == NULL)                   /* must be relocatable file */
        error = ILLOP;
    else {
        do_extern1();
        while (tokencmp(",")) {         /* while more labels */
            getnexttoken();             /* step past COMMA */
            do_extern1();
        }
    }
} /* end of do_extern */

void do_extern1(void)
{
    char *token;

    token = (char *) gettoken();        /* get next label */
    if (is_symf(*token)) {
        if (dout && DEBUG) fprintf(dout, "do_extern1: token=%s\n", printtoken(token));
        if (pass == 1) {
            if (find_sym(token) == NULL)
            enter_sym(token);
            set_flag(token,EXTERN,1);
            set_addr(token,++extern_cnt);
            set_seg(token, curseg);
        } else
            extdef(token);
        getnexttoken();                 /* step past LABEL */
    } 
} /* end of do_extern1 */

/* do_include	set up to open the specified file
*/

void do_include(void)
{
    char fname[40], *ptr = fname;
    char *str;

    eatws();                            /* eat whitespace */
    str = (char *) gettoken();          /* get FNAME */
    strcpy(fname, str);
    getnexttoken();                     /* step past FNAME */
    if (tokencmp(".")) {                /* got a FTYPE */
        getnexttoken();                 /* step past '.' */
        str = (char *) gettoken();      /* get FTYPE */
        strcat(fname,".");
        strcat(fname, str);
        getnexttoken();                 /* step past FTYPE */
    }
    if (dout && DEBUG) fprintf(dout, "\t+++do_include: fname=%s\n", fname);
    curlin[level] = linenum;
    if (++level >= LEVEL)
        fatal("Files nested too deeply","");
    strcpy(fn[level], fname);
    in[level] = NULL;
} /* end of do_include */

void do_origin(void)
{
    word = expression();
    set_pc(word);
    brkout(0);
    operand_type = 4;
} /* end of do_origin */

void do_page(void)
{
    if (dout && DEBUG) fprintf(dout, "\t+++do_page: token=%s\n", printtoken(gettoken()));
    word = expression();
    if (word) {
        linemax = word;
        operand_type = 4;
    } else
        operand_type = 45;
    if (dout && DEBUG) fprintf(dout, "\t---do_page: word=%d\n", word);
} /* end of do_page */

void do_public(void)
{
    if (dout && DEBUG) fprintf(dout,"do_public:\n");
    if (rout == NULL)                   /* only relocatable file allowed */
        error = ILLOP;
    else {
        do_public1();
        while (tokencmp(",")) {         /* while more labels */
            getnexttoken();             /* step past COMMA */
            do_public1();
        }
    }
} /* end of do_public */

void do_public1(void)
{
    char *token;

    token = (char *) gettoken();        /* get next label */
    if (is_symf(*token)) {              /* valid label? */
        if (dout && DEBUG) fprintf(dout, "do_public1: label=%s\n", printtoken(token));
        if (pass == 2) {
            enter_sym(token);
            set_flag(token,PUBLIC,1);
            set_seg(token, curseg);
            pubdef(token, curseg, get_addr(token));
        }
        getnexttoken();                 /* step past LABEL */
    }
} /* end of do_public1 */

void do_set(void)
{
    if (pass == 1)
        set_flag(label, SET, 1);
    else if ((get_flag(label) & SET) == SET) {
        word = expression();
        set_addr(label,word);
        operand_type = 10;
    } else
        error |= ILLOP;
} /* end of do_set */

void do_space(void)
{
    byte = expression();                /* get line count */
    operand_type = 44;
    if (dout && DEBUG) fprintf(dout, "\t---do_space: byte=%d\n", byte);
} /* end of do_space */

/* do_title	enter title for listing
*/

void do_title(void)
{
    char *token;

    token = (char *) gettoken();        /* get local copy */
    strncpy(title, token, 40); 
    getnexttoken();                     /* step past TITLE */
    operand_type = 0;
    if (dout && DEBUG) 
        fprintf(dout, "\t    do_title: title=%s\n", title);
} /* end of do_name */

void do_define(void)
{
    error |= ILLOP;
} /* end of do_define */

void do_option(void)
{
//    error |= ILLOP;
} /* end of do_option */

void do_mon(void)
{
//    error |= ILLOP;
} /* end of do_mon */

/* end of ipseudo.c */
