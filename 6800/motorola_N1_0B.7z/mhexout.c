/*	mhexout.c	output routines for .hex files for generic assembler
			by bill beech, 1991
DESCRIPTION
    This file outputs a Intel or Motorola family hexadecimal file image.

MODIFICATIONS
    01 Jan 91 -- Original
    29 Jun 11 -- Modified for token-based assembler

*/

#include "asm.h"

#define DEBUG   0

/*      external globals */

extern  unsigned apc2;
extern	int	pass;
extern  FILE	*hout;
extern  FILE    *dout;

/*	prototypes */

void h_init(void);
void h_wrdout(unsigned word);
void h_bytout(unsigned char byte);
void h_brkout(int cnt);
void h_endrcd(unsigned short start);
void h_putrcd(void);

/*      locally defined globals */

int	bytcnt;
unsigned char	record[OBJLEN+11];
int	pcrcd;
unsigned opc;

/*      program code */

void h_init(void)
{
    bytcnt = 0;
    pcrcd = 0;
}

void h_wrdout(unsigned word)
    {
    if (dout && DEBUG) fprintf(dout,"\t+++h_wrdout: word=%04X\n", word);
    h_bytout(word >> 8);
    h_bytout(word);
    } /* end of wrdout */

void h_bytout(unsigned char byte)
    {
    if (dout && DEBUG) fprintf(dout,"\t+++h_bytout: byte=%02X\n", byte);
    record[bytcnt++] = byte & 0xff;
    opc++;
    if (bytcnt > OBJLEN)
        h_putrcd();
    } /* end of bytout */

void h_brkout(int cnt)
    {
        int i;

    if (dout && DEBUG) fprintf(dout,"\t+++h_brkout: apc2=%04X opc=%04X\n", apc2, opc);
    if (apc2 == opc)
        return;
    if (bytcnt)
        h_putrcd();
    pcrcd = opc = apc2;
    } /* end of brkout */

void h_endrcd(unsigned short start)
    {
    if (dout && DEBUG) fprintf(dout,"\t+++h_endrcd:\n");
    if (pass == 2) {
        if (bytcnt)
            h_putrcd();
        bytcnt = 0;
        pcrcd = start;
        fprintf(hout,"S9\n");
        }
    } /* end of endrcd */

void h_putrcd(void)
    {
    int i;
    unsigned char chksum;

    if (pass == 2) {
        bytcnt &= 0xff;
        pcrcd &= 0xffff;
        bytcnt += 3;
        chksum = -1 - bytcnt - (pcrcd>>8) - pcrcd;
        if (dout && DEBUG) fprintf(dout,"\t+++h_putrcd: pcrcd=%04X bytcnt=%02X\n", pcrcd, bytcnt);
        fprintf(hout,"S1%02X%04X", bytcnt, pcrcd);
        for (i=0; i<bytcnt-3; i++) {
              fprintf(hout,"%02X", record[i]);
              chksum -= record[i];
        }
        fprintf(hout,"%02X\n",chksum & 0xff);
    }
    bytcnt = 0;
    pcrcd = opc;
    } /* end of h_putrcd */

/* end of mhexout.c */
