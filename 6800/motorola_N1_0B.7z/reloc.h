/*	reloc.h		Header file for relocatable object definitions
				by bill beech, february 2010

*/

#define	MODHDR	0x02
#define	MODEND	0x04
#define	MODDAT	0x06
#define	LINNUM	0x08
#define	MODEOF	0x0E
#define DEBUGA  0x12
#define	PUBDEF	0x16
#define	EXTDEF	0x18
#define	FIXUP1	0x20
#define	FIXUP2	0x22
#define	FIXUP3	0x24
#define	LIBHDR	0x2C
#define	LIBNAM	0x28
#define	LIBLOC	0x26
#define	LIBDIC	0x2A
//#define COMENT  0xF0    /* not part of 8085 OMF */
//#define LNAMES  0xF1    /* not part of 8085 OMF */
//#define SEGDEF  0xF2    /* not part of 8085 OMF */
//#define FIXUPP  0xF3    /* not part of 8085 OMF */

/* end of reloc.h */
