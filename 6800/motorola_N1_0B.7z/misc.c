/*	misc.c	a generic 8-bit microprocessor assembler token parser
		by bill beech

6.0A    24 Jun 11 - original
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	0

/*      external globals */

extern  char	*cptr;
extern  FILE    *dout;

/*	prototypes */

void    fatal(char *msg, char *msg1);
char    getchr(int off);
char    getUchr(int off);
void    whitespace(void);
void    whitespacec(void);
void    eol(void);
void    eatws(void);
void    eatwsc(void);

/*      locally defined globals */

/*      program code */

void fatal(char *msg, char *msg1)
{
    fprintf(stderr,"%s%s\n", msg, msg1);
    exit(1);
} /* end of fatal */

void whitespace(void)
{
    while (*cptr == '\t' || *cptr == ' ')
        cptr++;
} 

void whitespacec(void)
{
    while (*cptr == '\t' || *cptr == ' ' || *cptr == ',')
        cptr++;
} 

void eol(void)
{
    while (*cptr != '\n')
        cptr++;
} 
/* these routines work on tokens */
char getchr(int off)
{
    char *token;

    token = (char *) gettoken();
    if (DEBUG && dout) fprintf(dout, "\t   getchr: returns=%c [%08X]\n", *(token+off), *(token+off));
    return *(token+off);
} /* end of getchr */

char getUchr(int off)
{
    char *token;

    token = (char *) gettoken();
    if (DEBUG && dout) fprintf(dout, "\t   getUchr: returns=%c [%08X]\n",
        toupper(*(token+off)), toupper(*(token+off)));
    return toupper(*(token+off));
} /* end of getUchr */

void eatws(void)
{
    while (tokencmp(" "))                  /* WS? */
        getnexttoken();                 /* step past WS */
}

void eatwsc(void)
{
    while (tokencmp(" ") || tokencmp(",")) /* WS or ','? */
        getnexttoken();                 /* step past WS */
}

/* end of misc.c */
