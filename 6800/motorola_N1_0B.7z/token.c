/*	token.c	a generic 8-bit microprocessor assembler token parser
                by bill beech

6.0A    24 Jun 11 -- original
6.0B    01 Jul 11 -- only token WS at beginning of line
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	        0
#define TOKLEN		128		/* maximum length of a token */
#define	TSSIZE		50		/* size of token stack */

/*      external globals */

extern  char	fn[LEVEL][FNLEN];
extern  char	*cptr;
extern  FILE	*in[LEVEL], *dout, *lout;
extern  int	pass;
extern  int     vflag;
extern  int     curlin[];

/*	prototypes */

void    tokeninit(void);
void    parseline(void);
char    *getline(void);
void    dumpts(FILE *fp);
char    *printtoken(char *ptr);
char    *parsetoken(void);
char    *gettoken(void);
char    *getnexttoken(void);
char    *getUtoken(void);
char    *getnextUtoken(void);
int     tokencmp(char *str);
int     nexttokencmp(char *str);
int     istoken(char *str);
int     isnexttoken(char *str);
int     isnottoken(char *str);
char    *looknexttoken(void);

/*      locally defined globals */

char 	txtbuf[LINLEN];
char 	buf[LINLEN];
char	token[TOKLEN+1];
char    *cptr;
char	tokenstack[TSSIZE][TOKLEN+1];
int	spi, spo;
int     linenum;
int	level;
int     EOFflag;
int     SOLflag;
int     strflg = 0;

/*      program code */

void tokeninit(void)
{
    spi = 0;
    spo = 0;
    cptr = NULL;
    linenum = 0;
    level = 0;
    EOFflag  = 0;
}

/*	parseline - parse next line into token buffer */
void parseline(void)
{
    int i, flag = 1;
    char *ptr;

    if (dout && DEBUG) 
        fprintf(dout, "\t+++Enter parseline()\n");
    cptr = getline();                   /* read in a new line */
    if (cptr == NULL) {                 /* end of file */
        tokenstack[spi][0] = '\0';      /* set end of file */
        if (dout && DEBUG) 
            fprintf(dout, "\t+++Exit parseline() - EOF\n");
        return;
    }
    strncpy(txtbuf, cptr, LINLEN);      /* save line */
    txtbuf[strlen(txtbuf) - 1] = '\0';  /* remove CR LF */
    if (dout) 
        fprintf(dout, "%05d  \"%s\"\n", linenum, txtbuf);
    SOLflag = 1;
    while (flag) {                      /* parse all the tokens on the line */
        ptr = parsetoken();             /* get next token */
        if (dout && DEBUG) 
            fprintf(dout, "\t   token=\"%s\"\n", printtoken(ptr));
        if (*ptr == ' ' && SOLflag == 0) { /* whitespace not at start of line */
            ptr = parsetoken();         /* another token */
        }
        if (dout && DEBUG) 
            fprintf(dout, "\t   token=\"%s\"\n", printtoken(ptr));
        strncpy(tokenstack[spi], ptr, TOKLEN);
        if (dout && DEBUG) 
            fprintf(dout, "\t   token=\"%s\"\n", printtoken(tokenstack[spi]));
        spi++;
        if (spi == TSSIZE)              /* wrap input pointer if necessary */
            spi = 0;
        if (*ptr == '\n')               /* done */
            flag = 0;
        SOLflag = 0;                    /* first token parsed */
        if (dout && DEBUG) 
            fprintf(dout, "\t   flag=%d SOLflag=%d\n", flag, SOLflag);
    }
    if (dout && DEBUG)
        fprintf(dout, "\t---Exit parseline() - More tokens\n");
    if (dout && DEBUG) 
        fflush(dout);
}

/*      getline - get the next logical line from the source files and
                handle included files */
char *getline()
{
    char *ptr;

    if (dout && DEBUG) 
        fprintf(dout,"\t+++Getline: entered EOFflag=%d\n", EOFflag);
    if (EOFflag)
        return NULL;
    if (in[level] == NULL) {            /* need to open initial file */
        linenum = 0;
        if ((in[level] = fopen(fn[level],"r")) == NULL)
            fatal("File not found - ", fn[level]);
        //if (pass == 2 && vflag)
        if (lout && pass == 2 && level) fprintf(lout,"Opened file %s\n", fn[level]);
        if (dout && DEBUG) 
            fprintf(dout,"\t   Opened file %s level=%d\n", fn[level], level);
    }
    SOLflag = 1;                        /* new line */
    if ((ptr = fgets(buf, LINLEN, in[level])) == NULL) { /* end of file */
        //if (pass == 2 && vflag)
        if (lout && pass == 2 && level) fprintf(lout ,"Closed file %s\n", fn[level]);
        if (dout && DEBUG) 
            fprintf(dout ,"\t   Closed file %s level=%d\n", fn[level],level);
        fclose(in[level]);
        if (level) {
            level--;
            //if (pass == 2 && vflag)
                if (lout && pass == 2) fprintf(lout ,"Continued in file %s\n", fn[level]);
                if (dout && DEBUG) 
                    fprintf(dout ,"\t   Continued in file %s level=%d\n", fn[level], level);
            ptr = getline();
            linenum = curlin[level];
        } else
            EOFflag = 1;
    }
    linenum++;
    if (dout && DEBUG) { 
        fprintf(dout,"\t---Getline: exit linenum=%d EOFflag=%d\n", linenum, EOFflag);
        fflush(dout);
    }
    return ptr;
} /* end of getline */

/*      dumpts - dump the token stack */
void dumpts(FILE *fp)
{
    int i;
 
    if (fp) fprintf(fp, "spi=%d, spo=%d\n", spi, spo);
    if (fp) fprintf(fp, "tokenstack holds:\n");
    for (i=0; i<TSSIZE; i++)
        if (fp) fprintf(fp, "tokenstack[%d]=`%s`\n", i, printtoken(tokenstack[i]));
}

/*      printtoken - print the token expanding some */
char *printtoken(char *ptr)
{
    static char temp[TOKLEN+1];

    if (*ptr == '\r')
        strcpy(temp, "<CR>");
    else if (*ptr == '\n')
        strcpy(temp, "<LF>");
    else if (*ptr == '\0')
        strcpy(temp, "<EOF>");
    else if (*ptr == ' ')
        strcpy(temp, "<WS>");
    else
        sprintf(temp, "%s", ptr);
    return temp;
}

/*	parsetoken - parse the next token from the buffer */
char *parsetoken(void)
{
    int i;
    char *mptr, delim;

//    if (dout && DEBUG) 
        fprintf(dout, "\t+++Enter parsetoken() SOLflag=%d\n", SOLflag);
//        fprintf(dout, "\t   remaining string: %s\n", cptr);
//        fprintf(dout, "\t   *cptr=%02X\n", *cptr);
    if (strflg == 2 && ispunct(*cptr) && *cptr != ',' && *cptr != '$' && *cptr != '\n') { /* mnemonic = DB or FCC */
//        if (dout && DEBUG) 
            fprintf(dout, "\t+++strflg handler /xxx/\n");
        delim = *cptr;                  /* get DELIM */
        cptr++;                         /* step past DELIM */
        token[0] = delim;               /* save DELIM at token start */
        i = 1; 
        while(*cptr != delim) {         /* copy text */
            token[i] = *cptr;
            i++; cptr++;
        }
        token[i] = delim;               /* save DELIM at token end */
        i++; cptr++;
        token[i] = '\0';                /* end of token */
//        if (dout && DEBUG) 
            fprintf(dout, "\t---strflg handler /xxx/: token=%s *cptr=%c\n", token, *cptr);
    } else if (strflg == 2 && *cptr != ',' && *cptr != '\n' && 
            *cptr != ' ' && *cptr != '\t' && *cptr != '$' &&
            !isdigit(*cptr)) {
//        if (dout && DEBUG) 
            fprintf(dout, "\t+++strflg handler str\n");
        i = 0;
        while (*cptr != ',' && *cptr != '\n' /*|| *cptr != '\r'*/) {         /* copy text */
            token[i] = *cptr;
            fprintf(dout, "\t   strflg handler str token[%d]=%c *cptr=%c\n", i, token[i], *cptr);
            i++; cptr++;
        }
        token[i] = '\0';                /* end of token */
//        if (dout && DEBUG) 
            fprintf(dout, "\t---strflg handler str: token=%s *cptr=%02X\n", token, *cptr);
    } else if (ispunct(*cptr)) {        /* special character ? */
//        if (dout && DEBUG) 
            fprintf(dout, "\t   Special character\n");
        /* handle compound delimiters */
        if ((*cptr == '<' && *(cptr+1) == '>') || /* <> */
            (*cptr == '<' && *(cptr+1) == '=') || /* <= */
            (*cptr == '>' && *(cptr+1) == '=') || /* >= */
            (*cptr == '=' && *(cptr+1) == '=')) { /* == */
//            if (dout && DEBUG) 
                fprintf(dout, "\t   Multiple Punctuation\n");
            token[0] = *cptr;
            token[1] = *(cptr+1);
            token[2] = '\0';            /* end of token */
            cptr += 2;
        } else if (*cptr == '*') {      /* comment or PC*/
//            if (dout && DEBUG) 
                fprintf(dout, "\t   Comment or PC\n");
            token[0] = '*';
            token[1] = '\0';            /* end of token */
            cptr++;
            if (SOLflag)
                eol();
        } else if (*cptr == ',') {      /* COMMA */
            token[0] = ',';
            token[1] = '\0';            /* end of token */
            cptr++;
        } else if (*cptr == '"') {      /* string */
//            if (dout && DEBUG) 
                fprintf(dout, "\t   String\n");
                token[0] = '"';
                cptr++; i = 1;
                while(*cptr != '"') {
                    token[i++] = *cptr;
                    cptr++;
                }
                cptr++;                 /* step past last " */
                token[i] = '\0';        /* end of token */
        } else if (*cptr == '\'') {     /* character constant */
//            if (dout && DEBUG) 
                fprintf(dout, "\t   Character constant\n");
            token[0] = '\'';
            cptr++;
            token[1] = *cptr;
            cptr++;
            token[2] = '\0';            /* end of token */
        } else {
//            if (dout && DEBUG) 
                fprintf(dout, "\t   Single Punctuation\n");
            token[0] = *cptr;           /* other punctuation */
            token[1] = '\0';            /* end of token */
            cptr++;
        }
    } else if (is_symf(*cptr)) {        /* Identifiers */
//        if (dout && DEBUG) 
            fprintf(dout, "\t   Identifier\n");
        parse_sym(token);
//	if ((mptr = get_mac(token)) != NULL) {	/* macro expansion */
//	    if (dout && DEBUG) fprintf(dout, "Found macro expansion for %s with %s\n", token, mptr);
//	    strcpy(token, mptr);
//	}
    } else if (*cptr == ' ' || *cptr == '\t') { /* whitespace */
//        if (dout && DEBUG) 
            fprintf(dout, "\t   Whitespace\n");
        token[0] = ' ';
        token[1] = '\0';                /* end of token */
        whitespace();
        if (strflg == 1) {
            strflg = 2;
//        if (dout && DEBUG) 
            fprintf(dout, "\t   strflg = 2\n");
        }
    } else if (*cptr == '\r' || *cptr == '\n') { /* CR and/or LF */
//        if (dout && DEBUG) 
            fprintf(dout, "\t   CR or LF\n");
        token[0] = '\n';
        token[1] = '\0';                /* end of token */
        cptr++;
        strflg = 0;                     /* EOL, reset flag */
    } else if (isdigit(*cptr)) {        /* number */
//        if (dout && DEBUG) 
            fprintf(dout, "\t   Number\n");
        i = 0;
        while (isxdigit(*cptr)) {
            token[i++] = *cptr;
            cptr++;
        }
        token[i] = '\0';                /* end of token */
    }
    if (!strncmp(token,"FCC",3) ||
        !strncmp(token,"NAM",3) ||
        !strncmp(token,"TTL",3)
        ) {       /* set strflg for next token */
        strflg = 1;
//        if (dout && DEBUG) 
            fprintf(dout, "\t   strflg = 1\n");
    }
//    if (dout && DEBUG)
        fprintf(dout, "\t---Exit parsetoken() with token=`%s`, spi=%d, spo=%d\n",
            printtoken(token), spi, spo);
    fflush(dout);
    fflush(lout);
    return token;
}

/*	gettoken - return the current token */
char *gettoken(void)
{
    char *ptr;

    if (dout && DEBUG) 
        fprintf(dout, "\t+++gettoken: spi=%d spo=%d\n", spi, spo);
    if (spi == spo)
        parseline();
    ptr = tokenstack[spo];
    if (dout && DEBUG) 
        fprintf(dout, "\t---gettoken: token=%s\n", printtoken(ptr));
    return ptr;
}

/*	getnexttoken - return the next token */
char *getnexttoken(void)
{
    char *ptr;

    if (dout && DEBUG) 
        fprintf(dout, "\t+++getnexttoken: spi=%d spo=%d\n", spi, spo);
    spo++;
    if (spo == TSSIZE)
        spo = 0;
    if (spi == spo)
        parseline();
    ptr = tokenstack[spo];
    if (dout && DEBUG) 
        fprintf(dout, "\t---getnexttoken: token=%s\n", printtoken(ptr));
    if (dout && DEBUG) 
        fflush(dout);
    return ptr;
}

/*	getUtoken - return the current token */
char *getUtoken(void)
{
    int i = 0;
    char *ptr;
    static char token[TOKLEN+1];

    if (dout && DEBUG) 
        fprintf(dout, "\t+++getUtoken: spi=%d spo=%d\n", spi, spo);
    if (spi == spo)
        parseline();
    ptr = tokenstack[spo];
    while (*(ptr + i)) {
        token[i] = toupper(*(ptr + i));
        i++;
    }
    token[i] = '\0';
    if (dout && DEBUG) 
        fprintf(dout, "\t---getUtoken: token=%s\n", printtoken(token));
    return token;
}

/*	getnextUtoken - return the next token */
char *getnextUtoken(void)
{
    int i = 0;
    char *ptr;
    static char token[TOKLEN+1];

    if (dout && DEBUG) 
        fprintf(dout, "\t+++getnextUtoken: spi=%d spo=%d\n", spi, spo);
    spo++;
    if (spo == TSSIZE)
        spo = 0;
    if (spi == spo)
        parseline();
    ptr = tokenstack[spo];
    while (*(ptr + i)) {
        token[i] = toupper(*(ptr + i));
        i++;
    }
    token[i] = '\0';
    if (dout && DEBUG) 
        fprintf(dout, "\t---getnextUtoken: token=%s\n", printtoken(token));
    return token;
}

/*      looknexttoken - return next token without incrementing pointers */
char *looknexttoken(void)
{
    char *ptr;
    int sp;

    if (dout && DEBUG) 
        fprintf(dout, "\t+++looknexttoken: spi=%d spo=%d\n", spi, spo);
    sp = spo + 1;
    if (sp == TSSIZE)
        sp = 0;
    ptr = tokenstack[sp];
    if (dout && DEBUG) 
        fprintf(dout, "\t---looknexttoken: token=%s\n", printtoken(ptr));
    return ptr;
}

/*      tokencmp - compare str to current token */
int tokencmp(char *str)
{
    int len, i;
    char *ptr;

    if (dout && DEBUG) fprintf(dout, "\t+++tokencmp: token=%s\n", printtoken(str));
    ptr = gettoken();                   /* get the current token */
    len = strlen(str);                  /* length to compare */
    i = strlen(ptr);                    /* are they same length */
    if (i != len) {
        if (dout && DEBUG) fprintf(dout, "\t---tokencmp - Not equal length\n");
        return 0;
    }
    for (i=0; i<len; i++)               /* compare strings as uppers */
        if (toupper(str[i]) != toupper(ptr[i])) {
            if (dout && DEBUG) fprintf(dout, "\t---tokencmp - character mismatch\n");
            return 0;
        }
    if (dout && DEBUG) fprintf(dout, "\t---tokencmp - matched\n");
    return 1;
}

/*      nexttokencmp - compare str to next token */
int nexttokencmp(char *str)
{
    int len, i;
    char *ptr;

    if (dout && DEBUG) fprintf(dout, "\t+++nexttokencmp: token=%s\n", printtoken(str));
    ptr = looknexttoken();              /* get the next token */
    len = strlen(str);                  /* length to compare */
    i = strlen(ptr);                    /* are they same length */
    if (i != len) {
        if (dout && DEBUG) fprintf(dout, "\t---nexttokencmp - Not equal length\n");
        return 0;
    }
    for (i=0; i<len; i++)               /* compare strings as uppers */
        if (toupper(str[i]) != toupper(ptr[i])) {
            if (dout && DEBUG) fprintf(dout, "\t---nexttokencmp - character mismatch\n");
            return 0;
        }
    if (dout && DEBUG) fprintf(dout, "\t---nexttokencmp - matched\n");
    return 1;
}

/*      istoken - returns nonzero if matches, 0 otherwise */
int istoken(char *str)
{
    return tokencmp(str);
}

/*      isnexttoken - returns nonzero if matches next token, not current, 0 otherwise */
int isnexttoken(char *str)
{
    return nexttokencmp(str);
}

/*      isnottoken - returns nonzero if does not match, 0 otherwise */
int isnottoken(char *str)
{
    return !tokencmp(str);
}

/* end of token.c */
