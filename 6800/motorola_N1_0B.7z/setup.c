/*	setup.c	configure the generic assembler
                by bill beech

6.0A    24 Jun 11 - Original
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "asm.h"
#include "reloc.h"

#define	DEBUG	0

/*      external globals */
extern  char	fn[LEVEL][FNLEN];
extern  int	aseg, cseg;
extern  FILE	*in[LEVEL];
extern  FILE	*dout, *lout, *rout, *bout, *hout, *sout, *xout;
extern  int     vflag;

/*	prototypes */

/*      locally defined globals */

char    invoke[128];

/*      program code */

void setup(int argc, char **argv)
{
    int bflag = 0, dflag = 0, hflag = 0, lflag = 0, rflag = 0, sflag = 0, xflag = 0; 
    char str[SYMLEN], str1[128];

    strcpy(invoke, argv[0]);
    argv++;
    while (--argc) {			/* parse options */
        if (**argv == '-') {
            switch(toupper(*(*argv+1))) {
                case 'B':		/* binary file output */
                    if (hflag || rflag)
                        fatal("Cannot select more than one object format -r -h -b", "");
                    bflag = 1;
                    aseg = 1;
                    argv++;
                    break;
                case 'D':		/* debug file output */
                    dflag = 1;
                    argv++;
                    break;
                case 'H':		/* hex file output */
                    if (bflag || rflag)
                        fatal("Cannot select more than one object format -r -h -b", "");
                    hflag = 1;
                    aseg = 1;
                    argv++;
                    break;
                 case 'L':		/* list file output */
                    lflag = 1;
                    argv++;
                    break;
                case 'R':		/* relocatable file output */
                    if (bflag || hflag)
                        fatal("Cannot select more than one object format -r -h -b", "");
                    rflag = 1;
                    cseg = 1;
                    argv++;
                    break;
                case 'S':		/* symbol file output */
                    sflag = 1;
                    argv++;
                    break;
                case 'V':		/* verbose output */
                    vflag = 1;
                    argv++;
                    break;
                case 'X':		/* hex file output */
                    xflag = 1;
                    argv++;
                    break;
                default:		/* undefined option */
                    sprintf(str, "Unknown Option: %c", toupper(*(*argv+1)));
                    fatal(str,"");
                    break;
                }
        }
        else
            break;
    }
    if (argc != 1) {			/* only file name should remain */
        printf("%s: %s\n", invoke, VERSION);	/* signon */
        sprintf(str1, "%s: Usage [-b][-h][-l][-r][-s][-v] filename", invoke);
        fatal(str1,"");
    }
    if (bflag) {			/* open binary output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],BIN);
        if ((bout = fopen(fn[0],"wb")) == NULL)
            fatal("Unable to create binary file ", fn[0]);
    }
    if (dflag) {			/* open debug output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],DBG);
        if ((dout = fopen(fn[0],"wb")) == NULL)
            fatal("Unable to create debug file ", fn[0]);
    }
    if (hflag) {		        /* open hex output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],HEX);
        if ((hout = fopen(fn[0],"w")) == NULL)
            fatal("Unable to create hex file ", fn[0]);
    }
    if (rflag) {		        /* open relocatable output file */
//        strcpy(modnam,*argv);		/* set module name */
//        for (i=0; i<strlen(modnam); i++)
//            modnam[i] = toupper(modnam[i]);
        strcpy(fn[0],*argv);
        strcat(fn[0],REL);
        if ((rout = fopen(fn[0],"wb")) == NULL)
            fatal("Unable to create object file ", fn[0]);
    }
    if (sflag){			        /* open symbol output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],SYMBOL);
        if ((sout = fopen(fn[0],"w")) == NULL)
            fatal("Unable to create symbol file ", fn[0]);
    }
    if (xflag){			        /* open xref output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],XREF1);
        if ((xout = fopen(fn[0],"w")) == NULL)
            fatal("Unable to create xref file ", fn[0]);
    }
    if (lflag) {			/* open listing output file */
        strcpy(fn[0],*argv);
        strcat(fn[0],LIST);
        if ((lout = fopen(fn[0],"w")) == NULL)
            fatal("Unable to create listing file ", fn[0]);
    }
    strcpy(fn[0],*argv);		/* base assembler file */
    strcat(fn[0],SOURCE);
    in[0] = NULL;
}

/* end of setup.c */
