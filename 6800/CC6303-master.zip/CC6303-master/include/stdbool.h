#ifndef __STDBOOL_H
#define __STDBOOL_H

typedef unsigned char bool;

#define true 1
#define false 0
#endif
