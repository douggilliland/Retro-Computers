/*
 *      eval --- evaluate expression
 */

#ifndef _EVAL_H_
#define _EVAL_H_

int eval(void);
int is_op(char c);
int get_term(void);

#endif // _EVAL_H_

