/*
 *      file I/O version of forward ref handler
 */

#ifndef _FF2D_H_
#define _FF2D_H_

void fwdinit(void);
void fwdreinit(void);
void fwdmark(void);
void fwdnext(void);

#endif // _FF2D_H_

