
#ifndef _TABLE_H_
#define _TABLE_H_

#include "as.h"

extern struct oper table[];

int sizeof_table(void);

#endif // _TABLE_H_

