/*
	output header file
*/

#ifndef _OUTPUT_H_
#define _OUTPUT_H_

#include "globals.h"
#include "as.h"

void stable(struct nlist *ptr);
void cross(struct nlist *point);

#endif // _OUTPUT_H_

