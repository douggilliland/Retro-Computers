=============================================================================
-  Retro Assembler V2020.12                    Release Date: June 16, 2020  -
=============================================================================

Crafted by Peter Tihanyi with 8-Bit Love

(C) 2017-2020 Engine Designs in West Virginia, USA


Website: https://enginedesigns.net/retroassembler


Requires .Net Core 3.1 -- https://dotnet.microsoft.com/download 

Runs on Windows, macOS and Linux, on X86, X64 and ARM architectures.
