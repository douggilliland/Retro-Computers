OSIALod converts a 6502 binary object file to an OSI loadable format

V1.05 Usage:

OSIALOD [-l<hex address>][-g<hex address>][-t][-f][-p<nn>]
        [-a|-v|-i<hex addr>|-c|-q] [InFile] [OutFile]

-a  Convert binary data to OSI 65A Serial Monitor Load Format
-v  Convert binary data to OSI 65V ROM Monitor Load Format
-c  Convert binary data to MOS/OSI Checksum Load Format
-i[addr]  Convert data to hybrid 65V / Checksum load format
        (optional address specifies loader location. Defaults to load addr-256)
-q  Convert binary data to OSI QSave Binary Load Format
-p<nn> nn=number of bytes of nul padding at end of line in hex) defaults to 5
-l<addr>  load/target address of file
-g<addr>  go/execute address; Defaults to load address.
-f  Force overwrite of target file
-t  Use CR/LF End of Line. Normally just CR (not compatible with OSI)
 Infile can be redirected console input (stdin), Outfile defaults to (stdout)

 ex: OSIAlod -i -l0300 6502.bin file.lod


 
Reference:

65A monitor commands
 R - reset
 L - load mode followed by <2 Byte Address in hex><data as hex> R to exit
 P - print mode followed by <2 Byte Address in hex> dump data at address, Any key to exit
 G - go with $012D=K, $012A=X, $0129=Y, $012B=A, addr=($012F,$012E) 
     via RTI Note that unlike RTS, RTI does NOT add one to the destination before placing 
     it in the Program Counter (PC)
 0-9,A-F hex digit


65V monitor commands
 . switch to address mode
 / switch to data mode
 <CR> increment address (in data mdoe)
 L set input to serial port. To transfer back, set $00FD to $00 via serial
  or press reset
 G execute at current address
 0-9,A-F hex digit


The MOS Technology format 
Each line consists of 5 fields. These are the length field, address field, data field, 
and the checksum. The lines always start with a semicolon (;) character.

The Fields
    ___ ________ _________ ______ __________ ______
   |_;_|_Length_|_Address_|_Data_|_Checksum_|_CRLF_|
	
Length
The record length field is a 2 character (1 byte) field that specifies the number of 
data bytes in the record. Typically this is 24 ($18) or less.

Address
This is a 2-byte address that specifies where the data in the record is to be loaded 
into memory, big-endian.

Data
The data field contains the executable code, memory-loadable data or descriptive 
information to be transferred.

Checksum
The checksum is an 2-byte field that represents the least significant two bytes of 
the the sum of the values represented by the pairs of characters making up the record�s 
length, address, and data fields, big-endian.

End of File	(optional)
The final line should have a data length of zero, and the count of data lines in 
the address field. The checksum is not the usual checksum, it is instead a repeat 
of the data line count.

OSI specific
The final line consists of a $ character followed by a 2 byte address to start execution

The QSave format is the same as MOS checksum format except the data is sent as binary
instead of hexadecimal format, and the line length is increase to $38
