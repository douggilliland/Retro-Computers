Monster Maze for C1
PacMan clone by Dave Edson

To load this file:
At the C/W/M? prompt, press 'M' then 'L' to begin the load process


The keyboard controls are: 2=UP, 1=Down, 3=Left, 4=Right  R- to restart game
The game can be restarted from the C/W/M? prompt by entering "M.DD2G"
