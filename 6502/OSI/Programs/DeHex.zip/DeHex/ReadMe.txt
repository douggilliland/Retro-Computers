========================================================================
       WIN32 CONSOLE APPLICATION : DeHex
========================================================================

This is a simple tool to convert hexadecimal text files into binary using
supplied filename arguments or stdin & stdout

Usage: dehex [infile] [outfile]
  or   dehex < infile > outfile
       dehex -h (prints usage)
       dehex -o force overwrite of output file

Converts a file of hex pairs into binary, ignores ;comment lines (beginning with ';')

Allows for single character hex input "AA 00 FE B"  -> AA00FE0B

When presented with a single file input file, it will automatically convert it to the same filename 
with .bin extension

Use it to easily convert raw hexadecimal OSI disk image dumps to binary just drag your raw file 
onto dehex in Windows Explorer to generate the corresponding .bin file!