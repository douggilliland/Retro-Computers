========================================================================
       WIN32 CONSOLE APPLICATION : DeHex
========================================================================

This is a simple tool to convert hexadecimal text files into binary using
supplied filename arguments or stdin & stdout

Usage: dehex [infile] [outfile]
  or   dehex < infile > outfile
       dehex -h (prints usage)

Converts a file of hex pairs into binary, ignores ;comment lines (beginning with ';')

Allows for single character hex input "AA 00 FE B"  -> AA00FE0B