// DeHex.cpp : Defines the entry point for the console application.
// Mark Spankus 2005
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>
#include <tchar.h>
#include <ctype.h>
#include <fcntl.h>
#include <io.h>

int _tmain(int argc, TCHAR* argv[])
{
	
	FILE* inpfile = stdin;
	FILE* outfile = stdout;
	int nPos = 0;

	if (argc == 2 )
	{	
		if (!_tcsicmp(argv[1], _T("/?")) || !_tcsicmp(argv[1], _T("-h")) )
		{
			fputs( "Usage: dehex [infile] [outfile]\r\n  or   dehex < infile > outfile\r\nConverts a file of hex pairs into binary, ignores ;comment lines", stdout);
			return 0;
		}
	}
	if (argc > 1)
	{
	    int i = 1;

		if ( (inpfile = _tfopen(argv[i], _T("rb"))) == NULL)
		{
			_ftprintf(stderr, _T("dehex: Can't open '%s' for input.\n"), argv[i]);
			return -1;
		}

		if ( ++i < argc && (outfile = _tfopen(argv[i], _T("wb"))) == NULL)
		{
			_ftprintf(stderr, _T("dehex: Can't open '%s' for output.\n"), argv[i]);
			return -1;
		}
	}
	if (outfile == stdout) //ensure our binary \n's don't convert to \r\n!!!!!
	{
		_setmode(fileno(stdout), _O_BINARY);
	}


	bool bnewline = true, bnextline = false;

	while ( feof( inpfile ) == 0 )
	{
		unsigned char c1, c2;

		c1 = fgetc(inpfile);
		if ( bnextline || (c1 < '0' || c1 > '9') && (toupper(c1) < 'A' || toupper(c1) > 'F') )
		{
			
			if (c1 == '\r' || c1 == '\n')
			{
				if (bnextline)
					bnextline = false;
				if (!bnewline)
				{
					bnewline = true;
					if (bnextline)
						bnextline = false;
				}
			}

			if (bnewline && c1 == ';')
				bnextline = true;
			continue;
		}
		else
		{
			bnewline = false;
			if (bnextline)
				continue;
		} 
		c2 = fgetc(inpfile);
		if ( (c2 < '0' || c2 > '9') && (toupper(c2) < 'A' || toupper(c2) > 'F') )
		{
			
			c1 = toupper(c1);
			c1 -= '0';
			if (c1 > 9)
				c1 -= 7;
			fputc(c1, outfile );
			nPos++;
			continue;				
		}

		c1 = toupper(c1);
		c1 -= '0';
		if (c1 > 9)
			c1 -= 7;

		c2 = toupper(c2);
		c2 -= '0';
		if (c2 > 9)
			c2 -=7;
		fputc( ( (c1<<4) | c2), outfile );
		nPos++;

	}

	if (outfile != stdout)
		fclose(outfile);
	return 0;
}

