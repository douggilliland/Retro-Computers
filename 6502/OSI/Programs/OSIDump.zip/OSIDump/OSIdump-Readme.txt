This is an OSI dump utility for all OSI disk systems.
For video systems OSIDUMP.LOD is loaded via the OSI 65V ROM monitor.
For serial systems OSIDUMP.SER is loaded through the OSI 65A ROM monitor.
Transfer can be as ASCII HEX dump or XMODEM-CRC binary dump.
Requires 8K of working RAM and a serial connection to transfer data.


Basic Operation:
Connect the OSI system to a PC via a serial cable.  Ensure
you have the correct baud rate for your system (9600 baud?) and 8bit
no parity, 1 stop bit, no flow control.  (This assumes your OSI has
been modified to use RS-232.)

Reset the OSI system.
========================  
For Video Systems (C1/C2/C4/C8 Superboard):
You should see the C/W/M? prompt.   Choose 'M' (remember all OSI commands 
are upper case) then press 'L' to begin input from serial port.
Begin sending the osidump.lod file using a RAW ASCII send from the PC.

The osidump program begins loading at $0400 which is also the entry point for
the program.  When the osidump.lod file ends, it should automatically start,
and display the message "OSI DUMP ON SERIAL NOW" on screen. If it does not start,
RESET the OSI, at the C/W/M? prompt enter 'M' then type 0400G.
========================
For Serial Systems (OSI 400, C3)
You should see the H/D/M? prompt.   Choose 'M' (remember all OSI commands 
are upper case) then press 'L' to begin input from serial port.
Begin sending the osidump.ser file using a RAW ASCII send from the PC.

The osidump program begins loading at $0400 which is also the entry point for
the program.  When the osidump.ser file ends, it should automatically start,
and display main menu. If it does not start, press G or RESET the OSI, and at the 
H/D/M? prompt enter 'M' then type G.
==========================

Once running, the terminal should show the disk program's menu below:

 OSI Serial Disk Dump
----------------------
1. Dump Raw Image
3. Select Drive
4. Set Drive Type
5. Set Serial Divisor
6. Set Xmodem/Hex xfer
7. Exit

Drv=A/8  Baud@1x  Hex
--->



OSIDump usage:
The options are as follows:
1 - dumps the selected disk image in HEX or as XMODEM/CRC as selected

3 - select disk drive A - D (1 - 4)

4 - select either 8" (79 track) or 5.25" (40 track) disk drive type 

5 - program the ACIA clock divisor, either normal (/16) or fast (/1)
    divide by 1 allows you to transfer a disk image at 4800baud on a machine
    wired for 300 baud (300x16).

6 - Set desired transfer mode XMODEM or HEXADECIMAL.  When using HEX you will
    need to convert the resulting data into binary using a program like deHex.
    Xmodem transfers binary images, no additional processing is needed.

7 - Exit to reset vector.

8- hidden menu - force OS65D or OS65U reading (for 8" drives) otherwise autodetects

Once you have selected the appropriate options for your setup, enter '1' and begin
receiving data with your terminal program.

    












OSI 65A Rom Monitor command summary

R - reset (exits load mode)
L - load mode followed by <2 Byte Address in hex><data as hex>, R to exit
P - print mode followed by <2 Byte Address in hex> dump data at address, Any key to exit
G - go with $012D=K, $012A=X, $0129=Y, $012B=A, addr=($012F lo,$012E hi) 
    via RTI Note that unlike RTS, RTI does NOT add one to the destination before placing 
    it in the Program Counter (PC)
0-9,A-F hex digit
