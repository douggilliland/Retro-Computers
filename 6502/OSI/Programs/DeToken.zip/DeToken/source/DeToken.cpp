// DeToken.cpp : Defines the entry point for the console application.
//
// This program converts OSI tokenized basic to text and back
// It is similar to the PetCat tokenizer from the Commodore 64 emulator 
// but has been almost completely rewritten, part of its original header is below
// Mark Spankus 2007
/*
 * This file is part of Commodore 64 emulator
 *      and Program Development System.
 *
 *   Copyright (C) 1993-1995,1996, Jouko Valta
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
*/
#include <ctype.h>  
#include <stdio.h>  
#include <stdlib.h> 
#include <string.h>
#include <SHARE.H> //windows file sharing access
#include <fcntl.h> 
#include <io.h>	   //binary stdin


//OSI BASIC format:
//00 pl ph ll lh <data> 00 pl ph ll lh <data> 00 00
//
// pl = pointer to start of next line lo
// ph = pointer to start of next line hi
// ll = line number lo
// lh = line number hi
// <data> = tokenized basic statement (tokens are >= 0x80)
// 00 = null at end of line	(last char of this line)


//OSI basic-In-rom starts at $0300 = 00, PL, PH, LL, LH <data><00><end null>
//OSI OS65DV3.3 basic starts @ $3A7E 
//OSI OS65DV3.2 PlotBasic starts @ $3A7E
//OSI OS65DV3.2 basic starts @ $327E same token set as 3.1
//OSI OS65DV3.1 basic starts @ $327E 
//OSI OS65DV3.2 8" basic starts $317E
//OSI OS65U1.44 Basic starts @ $6000 				 
//OSI OS65U1.42 HD Basic starts @ $6000 



//OS65U V1.44 floppy version
const char *keyword65U[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "WAIT", "LOAD",  "SAVE",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR", "OPEN", "CLOSE",  "FIND", "DEV",   "FLAG",
	"NEW",  "TAB(", "TO",   "FN",    "SPC(",   "THEN", "NOT",   "STEP",
	"+",    "-",    "*",    "/",     "^",      "AND",  "OR",    ">",
	"=",    "<",    "SGN",  "INT",   "ABS",    "USR",  "FRE",   "POS",
	"SQR",  "RND",  "LOG",  "EXP",   "COS",    "SIN",  "TAN",   "ATN",
	"PEEK", "LEN",  "STR$", "VAL",   "ASC",    "CHR$", "INDEX", "LEFT$",
	"RIGHT$", "MID$", 

};

//keywords for OS65U 1.42 Basic found on Hard Drive 
const char *keyword65UHD[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "WAIT", "LOAD",  "SAVE",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR", "INDEX<", "OPEN", "CLOSE",  "FIND", "DEV",
	"FLAG",	"NEW",  "TAB(", "TO",   "FN",    "SPC(",   "THEN", "NOT", 
	"STEP",	"+",    "-",    "*",    "/",     "^",      "AND",  "OR",
	">",	"=",    "<",    "SGN",  "INT",   "ABS",    "USR",  "FRE",   
	"POS",	"SQR",  "RND",  "LOG",  "EXP",   "COS",    "SIN",  "TAN",   
	"ATN",	"PEEK", "LEN",  "STR$", "VAL",   "ASC",    "CHR$", "INDEX", 
	"LEFT$", "RIGHT$", "MID$", 

};

//OS65D V3.3 5.25" dunno why ATN is xxx'd out in this version
//NULL, WAIT replaced with EDIT and TRAP
const char *keywordV33[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "EDIT", "TRAP", "EXIT",  "DISK",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR","NEW",   "TAB(",   "TO",   "FN",    "SPC(",   
	"THEN", "NOT",  "STEP", "+",     "-",      "*",    "/",     "^",  
	"AND",  "OR",    ">",   "=",    "<",       "SGN",  "INT",   "ABS",
	"USR",  "FRE",   "POS",	"SQR",  "RND",     "LOG",  "EXP",   "COS",
	"SIN",  "TAN",   "xxx", "PEEK", "LEN",     "STR$", "VAL",   "ASC",
	"CHR$", "LEFT$", "RIGHT$", "MID$"

};

//OS65D V3.2 5.25" same as OS65D V3.1
const char *keywordV32[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "WAIT", "EXIT",  "DISK",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR","NEW",   "TAB(",   "TO",   "FN",    "SPC(",   
	"THEN", "NOT",  "STEP", "+",     "-",      "*",    "/",     "^",  
	"AND",  "OR",    ">",   "=",    "<",       "SGN",  "INT",   "ABS",
	"USR",  "FRE",   "POS",	"SQR",  "RND",     "LOG",  "EXP",   "COS",
	"SIN",  "TAN",   "ATN", "PEEK", "LEN",     "STR$", "VAL",   "ASC",
	"CHR$", "LEFT$", "RIGHT$", "MID$"

};

//OS65D V3.1 5.25"
const char *keywordV31[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "WAIT", "EXIT",  "DISK",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR","NEW",   "TAB(",   "TO",   "FN",    "SPC(",   
	"THEN", "NOT",  "STEP", "+",     "-",      "*",    "/",     "^",  
	"AND",  "OR",    ">",   "=",    "<",       "SGN",  "INT",   "ABS",
	"USR",  "FRE",   "POS",	"SQR",  "RND",     "LOG",  "EXP",   "COS",
	"SIN",  "TAN",   "ATN", "PEEK", "LEN",     "STR$", "VAL",   "ASC",
	"CHR$", "LEFT$", "RIGHT$", "MID$"

};

// OSI BASIC in ROM
const char *keywordROM[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "WAIT", "LOAD",  "SAVE",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR","NEW",   "TAB(",   "TO",   "FN",    "SPC(",   
	"THEN", "NOT",  "STEP", "+",     "-",      "*",    "/",     "^",  
	"AND",  "OR",    ">",   "=",    "<",       "SGN",  "INT",   "ABS",
	"USR",  "FRE",   "POS",	"SQR",  "RND",     "LOG",  "EXP",   "COS",
	"SIN",  "TAN",   "ATN", "PEEK", "LEN",     "STR$", "VAL",   "ASC",
	"CHR$", "LEFT$", "RIGHT$", "MID$"

};

//OSI PLOT Basic
const char *keywordPLOT[] = 
{
	"END",  "FOR",  "NEXT", "DATA",  "INPUT",  "DIM",  "READ",  "LET",
	"GOTO", "RUN",  "IF",   "RESTORE","GOSUB", "RETURN", "REM", "STOP",
	"ON",   "NULL", "PLOT", "EXIT",  "DISK",   "DEF",   "POKE", "PRINT",
	"CONT", "LIST", "CLEAR","NEW",   "TAB(",   "TO",   "FN",    "SPC(",   
	"THEN", "NOT",  "STEP", "+",     "-",      "*",    "/",     "^",  
	"AND",  "OR",    ">",   "=",    "<",       "SGN",  "INT",   "ABS",
	"USR",  "FRE",   "POS",	"SQR",  "RND",     "LOG",  "EXP",   "COS",
	"SIN",  "TAN",   "ATN", "PEEK", "LEN",     "STR$", "VAL",   "ASC",
	"CHR$", "LEFT$", "RIGHT$", "MID$"

};

//list of known versions
enum eOSIVersion 
{ 
	verROM = 0,
	ver65D33d5,
	ver65D32Plotd5,
	ver65D31d5,
	ver65DV31d8,
	verOS65UHD,
	verOS65U144,
	MAXVERSION /* must be last entry */
};

//structure to hold each BASIC version's data
typedef struct tagBASICData 
{ 
	const char **Keywords;	//pointer to list of pointers to keyword strings
	int    nCount;			//number of keyword strings
	short  sLoadAddr;		//BASIC version start address
	eOSIVersion eVer;		//BASIC version
	const char *szName;		//Name of BASIC version
} BASICDATA; 


//data table of BASIC versions
static BASICDATA kBasicData[MAXVERSION] = 
{

	{ keywordROM, sizeof(keywordROM) / sizeof(keywordROM[0]), 0x0300, verROM, "OSI BASIC In ROM (C1/C2/C4)"},
	{ keywordPLOT, sizeof(keywordPLOT) / sizeof(keywordPLOT[0]), 0x3A7E, ver65D32Plotd5, "OSI OS65D v3.2 Plot BASIC 5.25\" disk"},
	{ keywordV33, sizeof(keywordV33) / sizeof(keywordV33[0]), 0x3A7E, ver65D33d5, "OSI OS65D v3.3 BASIC 5.25\" disk"},
	{ keywordV31, sizeof(keywordV31) / sizeof(keywordV31[0]), 0x327E, ver65D31d5, "OSI OS65D v3.1 BASIC 5.25\" disk"},
	{ keywordV31, sizeof(keywordV31) / sizeof(keywordV31[0]), 0x317E, ver65DV31d8, "OSI OS65D V3.2 BASIC 8\" disk"},
	{ keyword65UHD, sizeof(keyword65UHD) / sizeof(keyword65UHD[0]), 0x6000, verOS65UHD, "OSI OS65U V1.42 Hard disk BASIC"},
	{ keyword65U, sizeof(keyword65U) / sizeof(keyword65U[0]), 0x6000, verOS65U144, "OSI OS65U V1.44 BASIC 8\" disk"},

};

#define VERSION 1.0

//forward declarations
static void list_keywords(int version);
static int expand(int nVer);
static void tokenize(int version, unsigned int addr);
static unsigned char sstrcmp(unsigned char *line, int version, int *pkwlen);

//globals
static FILE *source, *dest;


int main(int argc, char **argv)
{
	int nVer = -1;
	short nLoadAddr = kBasicData[verROM].sLoadAddr; //default to basic in rom addr
	short nCurAddr = 0;
	short nLine = 0;
	short overwrt = 0;
	short textmode = 0;
	short nOffset = 0;
	short fil = 0;
	short flg = 0;
    char *progname, *outfilename = NULL;
    int c = 0;

    /* Parse arguments */
    progname = argv[0];
	if (strrchr(progname, '\\') )
		progname = strrchr(progname, '\\')+1;

    while (--argc && ((*++argv)[0] == '-')) 
	{
        if (!strcmp(argv[0], "--")) 
		{
            --argc;
            ++argv;
            break;
        }

        if (!strcmp(argv[0], "-l")) 
		{           // load address 
            if (argc > 1 && sscanf(argv[1], "%x", &nLoadAddr) == 1) 
			{
                --argc; ++argv;
				continue;
            }
            //Fall to error */
        }


        if (!strcmp(argv[0], "-f")) 
		{      /* force overwrite */
            ++overwrt;
            continue;
        }
        else if (!strcmp(argv[0], "-o")) 
		{
            if (argc > 1) 
			{
                outfilename = argv[1];
                --argc; ++argv;
                continue;
            }
            fprintf (stderr, "\r\nOutput filename missing\r\n");
            /* Fall to error */
        }

        /* reading offset */
        if (!strcmp(argv[0], "-skip") || !strcmp(argv[0], "-offset")) 
		{
            if (argc > 1 && sscanf(argv[1], "%lx", &nOffset) == 1)
            {
                --argc; ++argv;
                continue;
            }
            /* Fall to error */

        } 
		else if (!strcmp(argv[0], "-text") || !strcmp(argv[0], "-t")) 
		{   /* force text mode */
            ++textmode;
            continue;

        } 
		else if (!strnicmp(argv[0], "-h", 2)) 
		{  /* version ID */
            fprintf(stderr,"\r\nOSI BASIC (De)Tokenizer.\r\n");

            /* Fall to error for Usage */

        /* Basic version */

        }
		else if (!strncmp(argv[0], "-w", 2) )
		{
			nVer = atoi( ( (char *) argv[0])+2);
			if (nVer < 0 || nVer >= MAXVERSION)
			{
				fprintf(stderr, "Invalid version specified\r\n");
			}
			else
			{
				continue;
			}
			
		} 
		else if (!strncmp(argv[0], "-k", 2) ) 
		{
            
			char * p = 	((char *) argv[0])+2;
			if (*p)
				list_keywords( atoi( p));
			else
				list_keywords( -1);
			return 0;
			


        }
		else
		{
			fprintf(stderr, "Unknown command %s\r\n", argv[0]);	
		} 

        fprintf(stderr,
                "\r\nOSI DeToken V1.1\r\nUsage: %7s\t[-text | -w<version>]"
                "\r\n\t\t[-skip <bytes>] [-l <hex>]  [--] [file list]\r\n\t\t[-k[<version>]]\r\n",
                progname);

        fprintf(stderr, "\r\n"
            "   -h -help\tOutput this help screen here\r\n"
            "   -skip <n>\tSkip <n> HEX bytes in the beginning of input file.\r\n"
            "   -t -text\tForce text mode\r\n"
            "   -w<version>\ttokenize/detokenize using keywords of specified BASIC version.\r\n"
            "   -k<version>\tlist all keywords for the specified BASIC version\r\n"
            "   -k\t\tlist all BASIC versions available.\r\n"
            "   -l\t\tSpecify load address for program (in hex, no loading chars!).\r\n"
            "   -o<name>\tSpecify the output file name\r\n"
            "   -f\t\tForce overwrite output file\r\n");

        fprintf(stderr, "\r\n\tVersions:\r\n"
                "\t0  OSI BASIC In ROM (Basic starts $ $0300)\r\n"
                "\t1  OSI OS65D V3.3  disk BASIC for 5.25 inch (Basic starts @ $3A7E)\r\n"
				"\t2  OSI OS65D V3.2  disk PlotBASIC 5.25 inch (Basic starts @ $3A7E)\r\n"
                "\t3  OSI OS65D V3.1  disk BASIC for 5.25 inch (Basic starts @ $327E)\r\n"
                "\t4  OSI OS65D V3.1  disk BASIC for 8 inch    (Basic starts @ $317E)\r\n"
                "\t5  OSI OS65U V1.42 disk BASIC for 8 inch    (Basic starts @ $6000)\r\n"
				"\t6  OSI OS65U V1.44 disk BASIC for 8 inch    (Basic starts @ $6000)\r\n"
                "\r\n");
        fprintf(stderr, "\tUsage examples:\r\n"
            "\tdetoken  -o outputfile.bas inputfile.tok\r\n"
            "\t\tConvert inputfile.tok to a text file in outputfile.bas,\r\n"
            "\tdetoken  -t -o outputfile.tok  inputfile.bas\r\n"
            "\t\tConvert inputfile.bas to a tokenized file in outputfile.tok\r\n"
            "\r\n");
        exit(1);
    }




	if (nVer >= 0 && nLoadAddr == 0)
	{
		nLoadAddr = kBasicData[	nVer ].sLoadAddr;
	}

    if (argc)
        fil++;


    /*
     * Loop all files
     */

    do 
	{
        int  plen = 0;
        flg = 0;        /* stdin loop flag */


        /*
         * Try to figure out format of input file
         * This is particularly difficult on <stdin>, as only _one_ character
         * of pushback is guaranteed on all cases.
         */

        if (!fil) 
		{
            source = stdin;
			//ensure binary data is not translated by OS
			_setmode(fileno(stdin), _O_BINARY);
        } 
		else 
		{	
			//use windows sharing flag to allow others to read file in use -doesn't work
			if ((source =_fsopen( argv[0], "rb",  _SH_DENYNO )) == NULL)
//			if ((source = fopen(argv[0], "rb")) == NULL) 
			{
                fprintf(stderr,
                        "\r\n%s: Can't open file %s\r\n", progname, argv[0]);
                exit(1);
            }


        }
		while (nOffset > 0)
		{
			getc(source);
			nOffset--;	
		}



        if (!outfilename)
            dest = stdout;
        else 
		{

			if ((dest = fopen(outfilename, "rb")) != NULL)
			{
				fclose(dest);
				
				if (!overwrt)
				{
					fprintf(stderr, "Output file %s exists! Use -f to force overwrite.\r\n", outfilename);
					exit(1);
				}
					
			}

            if ((dest = fopen(outfilename, "wb")) == NULL) 
			{
                fprintf(stderr,
                        "\r\n%s: Can't open output file %s\r\n", progname, outfilename);
                exit(1);
            }
        }

		if ( !textmode )
		{
			c = getc(source);
			ungetc(c,source);
			if (c == 0)
				textmode = 0;
		}
        if ( !textmode ) 
		{     
			expand(nVer);

        } 
		else 
		{
            
			tokenize(nVer, nLoadAddr);

        }


        if (fil)
            fclose(source);
        if (outfilename)
            fclose(dest);

    } while (flg || (fil && --argc && ++argv));         /* next file */



	return 0;
}


static void list_keywords(int version)
{
    int n;

    if (version < 0 || version >= MAXVERSION) 
	{
        fprintf (stderr, "\r\n  The following versions are supported on OSI %s V%4.2f\r\n\r\n",
                "Detoken", (float)VERSION );

			for (int n = 0; n < MAXVERSION; n++)
			{
				fprintf(stderr, "Version %d, Load Address $%04lX, %s\r\n", 
					kBasicData[n].eVer,
					kBasicData[n].sLoadAddr,
					kBasicData[n].szName);
			}
        fprintf (stderr, "\r\n");
        return;
    }

    printf("\r\n  Available Keywords on %s\r\n", kBasicData[version].szName);


    for (n = 0; n < kBasicData[version].nCount; n++) 
	{
		printf("%s\t", kBasicData[version].Keywords[n]);
    }
    printf("\r\n");
}


// Convert tokenized basic program to text
int expand(int nVer)
{
	
	int state = 0;
	short c;
	unsigned short nLink = 0;
	unsigned short nLine = 0;
	unsigned short nOffset = 0;
	
	if (nVer > 0)
		nOffset = kBasicData[nVer].sLoadAddr;
	
	//skip leading null
	while ( (c = getc(source)) != EOF && !c)
		nOffset++;
	ungetc(c, source); nOffset--;
	

	while ( (c = getc(source)) != EOF )
	{
		
		//00 pl ph ll lh <data> 00

		switch (state)
		{
			case 0:
				nLink = c ;
				state++;
				break;
			case 1:
				nLink = nLink + (c << 8);
				state++;
				if (nVer < 0)
				{
					int nChosen = -1;
					int base = nOffset;
					for (int i = 0; i < MAXVERSION; i++)
					{
						if (nLink > kBasicData[i].sLoadAddr && 	nLink < kBasicData[i].sLoadAddr + 255)
						{
							
							nChosen = i;
							nOffset = base + kBasicData[i].sLoadAddr;
							break; //choose 1st match
						}
					}
					if (nChosen >= 0)
					{
						nVer = nChosen;
						fprintf(stderr, "BASIC version not specified, so I chose %s\r\n",
							kBasicData[nVer].szName);
					}
					if (nVer < 0)
						return -1;
				}
				if (nLink == 0)
				{
					//end of BASIC
					return 0;
				}
				if (nLink < nOffset || nLink > nOffset + 255)
				{
					//invalid basic offset encountered, max length FF
						fprintf(stderr, "invalid basic offset encountered $%04X\r\n",
							nLink);
						return -1;

				}
				break;
			case 2:
				nLine = c ;
				state++;
				break;
			case 3:
				nLine = nLine + (c << 8);
				fprintf(dest, "%d ", nLine);
				state++;
				break;
			case 4:
				if (c & 0x80)
				{
					if ( (c & 0x7f) < kBasicData[nVer].nCount)
						fputs(kBasicData[nVer].Keywords[(c & 0x7f)], dest);

				}
				else if (c)
				{
					fputc( c, dest);
				}
				else
				{
					//read a null, only expected at end of current line, 

					if (nOffset+2 < nLink)
					{
						//Error in data? NULL encountered

						//well the next characters aren't expected to be start of line
						//BASIC ignores them & starts next line
						fprintf (stderr, "\r\nUnexpected NULL encountered in line %d (offset %d)\r\n", nLine, nOffset);
						fputc(' ', dest);

					}
					else
					{
						state = 0;
						fputs("\r\n", dest);
					}

				}
				break;
				 
		}
		nOffset++;
		if (nOffset+1 == nLink && state != 0)
		{
			//start of line
			state = 0;
			//if NULL then we're at end of BASIC
		}



	}

	return 0;

}

// Convert Text file to tokenized basic program
static void tokenize(int version, unsigned int addr)
{
    static char line[257];
    unsigned char *p1, *p2, quote, c;
    unsigned char rem_data_mode, rem_data_endchar = '\0';
    int len = 0, match;
    unsigned int linum = 10;
	int kwlen;

    //fprintf(dest, "%c%c", (addr & 255), ((addr >> 8) & 255));

    /* Copies from p2 to p1 */
	*line = 0;

	fprintf(dest, "%c", 0);
	addr++;

    while((p1 = p2 = (unsigned char *)fgets(line, 255, source)) != NULL) 
	{

        if (sscanf(line, "%d%n", &linum, &len) == 1)
            p2 += len;

        quote = 0;
        rem_data_mode = 0;
        while (isspace(*p2)) p2++;

        while (*p2) 
		{
            if (*p2 == 0x22) 
			{
                quote ^= *p2;
            }
            if (*p2 == 0x0a || *p2 == 0x0d)
                break;

            match = 0;
            if (quote || rem_data_mode) 
			{
				/* Do nothing */

            }
            else if (isalpha(*p2) || strchr("+-*/^>=<", *p2)) 
			{

                if ((c = sstrcmp(p2, version, &kwlen)) != 0) 
				{
                    *p1++ = c;
                    p2 += kwlen;
                    match++;

					if ( !strcmp(kBasicData[version].Keywords[c&0x7F], "REM") ||
						 !strcmp(kBasicData[version].Keywords[c&0x7F], "DATA" ))
						rem_data_mode = 1;
                }

            } /* !quote */

            if (!match) 
			{
                *p1++ = *p2;

                /* check if the REM/DATA mode has to be stopped: */
                if (*p2 == rem_data_endchar)
                    rem_data_mode = 0;

                ++p2;
            } /* match */
        } /* while */

        *p1 = 0;
        if ((len = strlen(line) ) > 0) 
		{
            addr += len + 5;  //incl starting null
            fprintf(dest, "%c%c%c%c%s%c", addr & 255, (addr>>8) & 255,
                   linum & 255, (linum>>8) & 255, line, '\0');

            linum += 2; /* auto line numbering by default */
        }
    } /* while */

    fprintf(dest, "%c%c", 0, 0);        /* program end marker */
}

//match basic keyword with token table
static unsigned char sstrcmp(unsigned char *line, int version, int *pkwlen)
{
    int j;
    const char *p, *q;

	if (version < 0 || version >= MAXVERSION)
		return 0;
		 


    /* search for keyword */
    for (int token = 0; token < kBasicData[version].nCount ; token++) 
	{
        for (p = kBasicData[version].Keywords[token], q = (char *)line, j = 0;
             *p && *q && *p == *q; p++, q++, j++)
		{

        //fprintf (stderr,"compare %s %s - %d\r\n", kBasicData[version].Keywords[token], line, j);
		}
        // found an exact or abbreviated keyword
        if (j && (!*p || (*p && (*p ^ *q) == 0x20 && j++)) ) 
		{
            *pkwlen = j;
            //fprintf (stderr, "found %s %2x\r\n", kBasicData[version].Keywords[token], token);
            return (token | 0x80);
        }
    } /* for */

    return 0;
}


