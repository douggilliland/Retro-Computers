=============================================================================
-  Retro Assembler V2020.12                    Release Date: June 16, 2020  -
=============================================================================

Crafted by Peter Tihanyi with 8-Bit Love

(C) 2017-2020 Engine Designs in West Virginia, USA


Website: https://enginedesigns.net/retroassembler


Requires .Net Framework 4.8 on Windows, Mono on macOS and Linux

Runs on Windows, macOS and Linux, on X86, X64 and ARM architectures.
